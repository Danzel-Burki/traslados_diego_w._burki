// js/modo_pre_osc.js
// Script para el modo oscuro/claro con animación

document.addEventListener('DOMContentLoaded', function() {
    const themeToggle = document.getElementById('themeToggle');
    
    // Verificar si el botón existe en la página
    if (!themeToggle) return;
    
    const toggleIcon = themeToggle.querySelector('.toggle-icon');
    
    // Verificar si hay un tema guardado en localStorage
    const savedTheme = localStorage.getItem('theme');
    
    if (savedTheme) {
        // Aplicar el tema guardado
        document.documentElement.setAttribute('data-theme', savedTheme);
        toggleIcon.textContent = savedTheme === 'dark' ? '☀️' : '🌙';
        
        // Actualizar el meta theme-color para móviles
        updateThemeColor(savedTheme);
    } else {
        // Verificar preferencia del sistema
        const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        if (prefersDark) {
            document.documentElement.setAttribute('data-theme', 'dark');
            toggleIcon.textContent = '☀️';
            localStorage.setItem('theme', 'dark');
            updateThemeColor('dark');
        }
    }
    
    // Función para actualizar el color de la barra de navegación en móviles
    function updateThemeColor(theme) {
        let metaThemeColor = document.querySelector('meta[name="theme-color"]');
        if (!metaThemeColor) {
            metaThemeColor = document.createElement('meta');
            metaThemeColor.name = 'theme-color';
            document.head.appendChild(metaThemeColor);
        }
        metaThemeColor.content = theme === 'dark' ? '#1a1a1a' : '#eef1f5';
    }
    
    // Función para cambiar el tema con animación
    function toggleTheme() {
        // Agregar clase de animación al botón
        themeToggle.classList.add('rotating');
        
        // Obtener tema actual
        const currentTheme = document.documentElement.getAttribute('data-theme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        
        // Pequeño delay para mejor animación
        setTimeout(() => {
            // Aplicar el nuevo tema
            document.documentElement.setAttribute('data-theme', newTheme);
            toggleIcon.textContent = newTheme === 'dark' ? '☀️' : '🌙';
            
            // Guardar preferencia
            localStorage.setItem('theme', newTheme);
            
            // Actualizar theme-color
            updateThemeColor(newTheme);
            
            // Disparar evento personalizado para otros scripts
            document.dispatchEvent(new CustomEvent('themeChanged', { 
                detail: { theme: newTheme } 
            }));
        }, 50);
        
        // Quitar la clase de animación después de que termine
        setTimeout(() => {
            themeToggle.classList.remove('rotating');
        }, 500);
    }
    
    // Agregar evento click
    themeToggle.addEventListener('click', toggleTheme);
    
    // Efectos hover
    themeToggle.addEventListener('mouseenter', () => {
        if (toggleIcon) {
            toggleIcon.style.transform = 'scale(1.1)';
        }
    });
    
    themeToggle.addEventListener('mouseleave', () => {
        if (toggleIcon) {
            toggleIcon.style.transform = 'scale(1)';
        }
    });
    
    // Escuchar cambios en la preferencia del sistema
    const darkModeMediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    darkModeMediaQuery.addEventListener('change', (e) => {
        // Solo cambiar automáticamente si el usuario no ha establecido una preferencia manual
        if (!localStorage.getItem('theme')) {
            const newTheme = e.matches ? 'dark' : 'light';
            document.documentElement.setAttribute('data-theme', newTheme);
            toggleIcon.textContent = newTheme === 'dark' ? '☀️' : '🌙';
            updateThemeColor(newTheme);
        }
    });
    
    // Función para forzar un tema específico (útil para debugging)
    window.setTheme = function(theme) {
        if (theme === 'dark' || theme === 'light') {
            document.documentElement.setAttribute('data-theme', theme);
            toggleIcon.textContent = theme === 'dark' ? '☀️' : '🌙';
            localStorage.setItem('theme', theme);
            updateThemeColor(theme);
        }
    };
});

// Soporte para páginas que se cargan via AJAX
document.addEventListener('ajaxComplete', function() {
    // Re-inicializar el botón si se carga nuevo contenido
    const themeToggle = document.getElementById('themeToggle');
    if (themeToggle && !themeToggle.hasAttribute('data-initialized')) {
        themeToggle.setAttribute('data-initialized', 'true');
        
        // Actualizar icono según tema actual
        const currentTheme = document.documentElement.getAttribute('data-theme');
        const toggleIcon = themeToggle.querySelector('.toggle-icon');
        if (toggleIcon) {
            toggleIcon.textContent = currentTheme === 'dark' ? '☀️' : '🌙';
        }
    }
});