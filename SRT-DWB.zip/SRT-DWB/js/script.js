function actualizar(id, campo, valor) {
    fetch("php/actualizar_estado.php", {
        method: "POST",
        headers: {"Content-Type": "application/x-www-form-urlencoded"},
        body: `id=${id}&campo=${campo}&valor=${valor ? 1 : 0}`
    });
}
