<?php
require_once __DIR__ . "/../includes/conexion.php";
date_default_timezone_set("America/Argentina/Buenos_Aires");

$titulo = "Viajes Completados";

/* =========================
   GUARDAR EDICIÓN
========================= */
if (isset($_POST['guardar_edicion'])) {
    $id = (int)$_POST['id'];

    $stmt = $conn->prepare("
        UPDATE reservas_completadas 
        SET cliente=?, fecha=?, destino=?, precio=?
        WHERE id=?
    ");
    $stmt->bind_param(
        "sssdi",
        $_POST['cliente'],
        $_POST['fecha'],
        $_POST['destino'],
        $_POST['precio'],
        $id
    );
    $stmt->execute();
    $stmt->close();

    header("Location: viajes_completados.php?anio=$_POST[anio]&mes=$_POST[mes]");
    exit;
}

/* =========================
   ELIMINAR
========================= */
if (isset($_GET['eliminar_id'])) {
    $id = (int)$_GET['eliminar_id'];
    $conn->query("DELETE FROM reservas_completadas WHERE id=$id");
    header("Location: viajes_completados.php?anio=$_GET[anio]&mes=$_GET[mes]");
    exit;
}

/* =========================
   SELECCIÓN
========================= */
$anio_sel = $_GET['anio'] ?? null;
$mes_sel  = $_GET['mes'] ?? null;
$editar_id = $_GET['editar_id'] ?? null;

/* =========================
   AÑOS
========================= */
$anos = [];
$res = $conn->query("SELECT DISTINCT anio FROM reservas_completadas ORDER BY anio DESC");
while ($r = $res->fetch_assoc()) $anos[] = $r['anio'];

/* =========================
   MESES
========================= */
$meses = [];
if ($anio_sel) {
    $res = $conn->query("SELECT DISTINCT mes FROM reservas_completadas WHERE anio=$anio_sel ORDER BY mes");
    while ($r = $res->fetch_assoc()) $meses[] = $r['mes'];
}

/* =========================
   RESERVAS
========================= */
$reservas = [];
$total_mes = 0;

if ($anio_sel && $mes_sel) {
    $res = $conn->query("
        SELECT * FROM reservas_completadas
        WHERE anio=$anio_sel AND mes=$mes_sel
        ORDER BY fecha
    ");
    while ($r = $res->fetch_assoc()) {
        $reservas[] = $r;
        $total_mes += $r['precio'];
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title><?= $titulo ?></title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>

<h1><?= $titulo ?></h1>

<?php if (!$anio_sel): ?>

<h2>Seleccionar Año</h2>
<div class="cuadro-container">
<?php foreach ($anos as $a): ?>
<a class="cuadro" href="?anio=<?= $a ?>"><?= $a ?></a>
<?php endforeach; ?>
</div>

<?php elseif (!$mes_sel): ?>

<h2>Año <?= $anio_sel ?> – Mes</h2>
<div class="cuadro-container">
<?php foreach ($meses as $m): ?>
<a class="cuadro" href="?anio=<?= $anio_sel ?>&mes=<?= $m ?>">
<?= ucfirst(DateTime::createFromFormat('!m', $m)->format('F')) ?>
</a>
<?php endforeach; ?>
</div>

<?php else: ?>

<h2><?= ucfirst(DateTime::createFromFormat('!m', $mes_sel)->format('F')) ?> <?= $anio_sel ?></h2>
<h3>Total del mes: $<?= number_format($total_mes,0,',','.') ?></h3>

<table class="tabla-reservas">
<tr>
<th>ID</th>
<th>Cliente</th>
<th>Fecha</th>
<th>Destino</th>
<th>Precio</th>
<th>Acción</th>
</tr>

<?php foreach ($reservas as $r): ?>

<?php if ($editar_id == $r['id']): ?>
<tr>
<form method="post">
<td><?= $r['id'] ?></td>
<td><input type="text" name="cliente" value="<?= $r['cliente'] ?>" required></td>
<td><input type="date" name="fecha" value="<?= $r['fecha'] ?>" required></td>
<td><input type="text" name="destino" value="<?= $r['destino'] ?>" required></td>
<td><input type="number" name="precio" value="<?= $r['precio'] ?>" required></td>
<td>
<input type="hidden" name="id" value="<?= $r['id'] ?>">
<input type="hidden" name="anio" value="<?= $anio_sel ?>">
<input type="hidden" name="mes" value="<?= $mes_sel ?>">
<button name="guardar_edicion">💾</button>
<a href="?anio=<?= $anio_sel ?>&mes=<?= $mes_sel ?>">✖</a>
</td>
</form>
</tr>

<?php else: ?>
<tr>
<td><?= $r['id'] ?></td>
<td><?= $r['cliente'] ?></td>
<td><?= date("d/m/Y", strtotime($r['fecha'])) ?></td>
<td><?= $r['destino'] ?></td>
<td>$<?= number_format($r['precio'],0,',','.') ?></td>
<td>
<a href="?anio=<?= $anio_sel ?>&mes=<?= $mes_sel ?>&editar_id=<?= $r['id'] ?>">✏️</a>
<a href="?anio=<?= $anio_sel ?>&mes=<?= $mes_sel ?>&eliminar_id=<?= $r['id'] ?>"
onclick="return confirm('¿Eliminar?')">🗑</a>
</td>
</tr>
<?php endif; ?>

<?php endforeach; ?>
</table>

<?php endif; ?>

<div class="volver-container">
<?php if ($mes_sel): ?>
<a href="viajes_completados.php?anio=<?= $anio_sel ?>">⬅ Volver</a>
<?php elseif ($anio_sel): ?>
<a href="viajes_completados.php">⬅ Volver</a>
<?php endif; ?>
<a href="../index.php">🏠 Inicio</a>
</div>

</body>
</html>
