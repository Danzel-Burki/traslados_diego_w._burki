<?php
require_once __DIR__ . "/../includes/conexion.php";
$fecha = $_GET['fecha'] ?? date('Y-m-d');

// Traer reservas del día
$res = $conn->query("SELECT * FROM reservas WHERE fecha='$fecha' ORDER BY hora ASC");
?>
<!DOCTYPE html>
<html lang="es">

<!DOCTYPE html>
<html lang="es">
<?php
include("../includes/conexion.php");
$titulo = "Viajes Completados";
?>
<!DOCTYPE html>
<html lang="es">
<?php include("../includes/header.php"); ?>

<body>

    <h2>Reservas del <?= date("d/m/Y", strtotime($fecha)) ?></h2>

    <div class="tabla-wrapper">
        <table>
            <tr>
                <th>Cliente</th>
                <th>Hora</th>
                <th>Origen</th>
                <th>Destino</th>
                <th>Prioridad</th>
            </tr>

            <?php while ($r = $res->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($r['cliente']) ?></td>
                    <td><?= substr($r['hora'], 0, 5) ?></td>
                    <td><?= htmlspecialchars($r['origen']) ?></td>
                    <td><?= htmlspecialchars($r['destino']) ?></td>
                    <td class="center prioridad <?= $r['prioridad'] ?>">
                        <a href="actualizar_estado.php?id=<?= $r['id'] ?>&campo=prioridad">
                            <?= $r['prioridad'] == 'confirmada' ? 'Confirmada' : 'No conf.' ?>
                        </a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </table>
    </div>

    <div class="volver-container">
        <a href="calendario.php" class="btn-volver">⬅ Volver</a>
    </div>

</body>

</html>