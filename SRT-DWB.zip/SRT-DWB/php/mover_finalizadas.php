<?php
include("../includes/conexion.php");

date_default_timezone_set("America/Argentina/Buenos_Aires");
$ahora = date("Y-m-d H:i:s");

$conn->query("UPDATE reservas SET estado='finalizado' WHERE CONCAT(fecha,' ',hora) < '$ahora'");

$resFinalizadas = $conn->query("SELECT * FROM reservas WHERE estado = 'finalizado'");
while ($r = $resFinalizadas->fetch_assoc()) {
    $mes  = date('m', strtotime($r['fecha']));
    $anio = date('Y', strtotime($r['fecha']));

    $conn->query("
        INSERT INTO reservas_completadas
        (id, cliente, integrantes, fecha, hora, origen, destino, vuelo,
         info_completa, prioridad, equipaje, contacto, precio, obtenido, mes, anio)
        VALUES (
            {$r['id']}, '{$r['cliente']}', {$r['integrantes']}, '{$r['fecha']}',
            '{$r['hora']}', '{$r['origen']}', '{$r['destino']}', '{$r['vuelo']}',
            {$r['info_completa']}, '{$r['prioridad']}', {$r['equipaje']}, '{$r['contacto']}',
            {$r['precio']}, {$r['obtenido']}, $mes, $anio
        )
    ");
    $conn->query("DELETE FROM reservas WHERE id = {$r['id']}");
}
?>
