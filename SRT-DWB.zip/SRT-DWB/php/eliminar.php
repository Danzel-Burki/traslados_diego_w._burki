<?php
require_once __DIR__ . "/../includes/conexion.php";

$id = (int)$_GET['id'];
$stmt = $conn->prepare("DELETE FROM reservas WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$stmt->close();

header("Location: ../index.php");
exit;
?>