<?php
require_once __DIR__ . "/../includes/conexion.php";

$equipaje = isset($_POST['equipaje']) ? 1 : 0;

$cliente   = $conn->real_escape_string($_POST['cliente']);
$origen    = $conn->real_escape_string($_POST['origen']);
$destino   = $conn->real_escape_string($_POST['destino']);
$vuelo     = $conn->real_escape_string($_POST['vuelo']);
$contacto  = $conn->real_escape_string($_POST['contacto']);
$precio    = !empty($_POST['precio']) ? $_POST['precio'] : 0;

$stmt = $conn->prepare("
    UPDATE reservas SET
        cliente=?, integrantes=?, fecha=?, hora=?, origen=?, destino=?, vuelo=?, equipaje=?, contacto=?, precio=?
    WHERE id=?
");

$stmt->bind_param(
    "sisssssissi",
    $cliente,
    $_POST['integrantes'],
    $_POST['fecha'],
    $_POST['hora'],
    $origen,
    $destino,
    $vuelo,
    $equipaje,
    $contacto,
    $precio,
    $_POST['id']
);

$stmt->execute();
$stmt->close();

header("Location: ../index.php");
exit;
?>