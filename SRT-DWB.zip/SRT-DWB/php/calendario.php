<?php
require_once __DIR__ . "/../includes/conexion.php";

date_default_timezone_set("America/Argentina/Buenos_Aires");

/* =========================
   MES Y AÑO
========================= */
$mes  = $_GET['mes'] ?? date('m');
$anio = $_GET['anio'] ?? date('Y');

/* =========================
   DATOS DEL MES
========================= */
$inicio      = strtotime("$anio-$mes-01");
$diasMes     = date('t', $inicio);
$diaSemana   = date('N', $inicio); // 1 (Lunes) - 7 (Domingo)

/* =========================
   DÍAS CON RESERVAS
   (activas + completadas)
========================= */
$res = $conn->query("
    SELECT DISTINCT DAY(fecha) AS dia
    FROM (
        SELECT fecha FROM reservas
        UNION ALL
        SELECT fecha FROM reservas_completadas
    ) AS todas
    WHERE MONTH(fecha) = $mes
      AND YEAR(fecha) = $anio
");

$dias = [];
while ($r = $res->fetch_assoc()) {
    $dias[] = (int)$r['dia'];
}
?>
<!DOCTYPE html>
<html lang="es">
<?php
$titulo = "Calendario de Reservas";
include("../includes/header.php");
?>

<body>

<h2>
    Calendario –
    <?= ucfirst(DateTime::createFromFormat('!m', $mes)->format('F')) ?>
    <?= $anio ?>
</h2>

<div class="tabla-wrapper">
    <table class="calendario">
        <thead>
        <tr>
            <th>L</th>
            <th>M</th>
            <th>M</th>
            <th>J</th>
            <th>V</th>
            <th>S</th>
            <th>D</th>
        </tr>
        </thead>

        <tbody>
        <tr>
            <?php
            // Celdas vacías iniciales
            for ($i = 1; $i < $diaSemana; $i++) {
                echo "<td></td>";
            }

            $col = $diaSemana;

            for ($d = 1; $d <= $diasMes; $d++) {

                $clase = in_array($d, $dias) ? "con-reserva" : "";
                $fecha = sprintf("%04d-%02d-%02d", $anio, $mes, $d);

                echo "<td class='$clase'>
                        <a href='reservas_dia.php?fecha=$fecha'>$d</a>
                      </td>";

                if ($col % 7 == 0) {
                    echo "</tr><tr>";
                }

                $col++;
            }
            ?>
        </tr>
        </tbody>
    </table>
</div>

<div class="volver-container">
    <a href="../index.php" class="btn-volver">🏠 Volver al Inicio</a>
</div>

</body>
</html>
