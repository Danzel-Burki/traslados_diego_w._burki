<?php
require_once __DIR__ . "/../includes/conexion.php";
$id = (int)$_GET['id'];
$r = $conn->query("SELECT * FROM reservas WHERE id=$id")->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<link rel="stylesheet" href="../css/style.css">
<title>Editar Reserva</title>
</head>
<body>

<h1>Editar Reserva</h1>

<form action="guardar_edicion.php" method="POST" class="form-reserva">
    <input type="hidden" name="id" value="<?= $r['id'] ?>">
    <input name="cliente" value="<?= $r['cliente'] ?>" required>
    <input type="number" name="integrantes" value="<?= $r['integrantes'] ?>" required>
    <input type="date" name="fecha" value="<?= $r['fecha'] ?>" required>
    <input type="time" name="hora" value="<?= substr($r['hora'],0,5) ?>" required>
    <input name="origen" value="<?= $r['origen'] ?>">
    <input name="destino" value="<?= $r['destino'] ?>">
    <input name="vuelo" value="<?= $r['vuelo'] ?>">
    <label>
        <input type="checkbox" name="equipaje" <?= $r['equipaje'] ? 'checked' : '' ?>> Equipaje
    </label>
    <select name="contacto" required>
        <option value="web" <?= $r['contacto']=='web' ? 'selected' : '' ?>>Web</option>
        <option value="whatsapp" <?= $r['contacto']=='whatsapp' ? 'selected' : '' ?>>WhatsApp</option>
        <option value="recomendacion" <?= $r['contacto']=='recomendacion' ? 'selected' : '' ?>>Recomendación</option>
    </select>
    <input type="number" name="precio" value="<?= $r['precio'] ?>" required>
    <button>Guardar</button>
</form>

<div class="volver-container">
    <a href="../index.php" class="btn-volver">🏠 Volver al Inicio</a>
</div>
</body>
</html>