<?php
require_once __DIR__ . "/../includes/conexion.php";

$id = (int)$_GET['id'];
$campo = $_GET['campo'];

if ($campo === "info_completa") {
    $conn->query("UPDATE reservas SET info_completa = CASE WHEN info_completa=1 THEN 0 ELSE 1 END WHERE id = $id");
}

if ($campo === "prioridad") {
    $conn->query("
        UPDATE reservas
        SET prioridad = CASE WHEN prioridad='confirmada' THEN 'no_confirmada' ELSE 'confirmada' END
        WHERE id = $id
    ");
}

header("Location: ../index.php");
exit;
?>
