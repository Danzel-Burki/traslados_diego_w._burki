<?php
require_once __DIR__ . "/../includes/conexion.php";

// Obtener y sanitizar los parámetros
$id = (int)$_GET['id'];
$campo = $_GET['campo'];

// Validar que el campo sea válido
if (!in_array($campo, ['info_completa', 'prioridad'])) {
    die("Campo no válido");
}

// Iniciar transacción para mantener integridad
$conn->begin_transaction();

try {
    if ($campo === "info_completa") {
        // Cambiar el estado de info_completa (0/1)
        $conn->query("
            UPDATE reservas
            SET info_completa = IF(info_completa = 1, 0, 1)
            WHERE id = $id
        ");
    }

    if ($campo === "prioridad") {
        // Cambiar el estado de prioridad (confirmada/no_confirmada)
        // Importante: usar no_confirmada con guión bajo para consistencia
        $conn->query("
            UPDATE reservas
            SET prioridad = IF(prioridad = 'confirmada', 'no_confirmada', 'confirmada')
            WHERE id = $id
        ");
    }

    // Verificar que se actualizó alguna fila
    if ($conn->affected_rows === 0) {
        throw new Exception("No se encontró la reserva con ID: $id");
    }

    $conn->commit();

} catch (Exception $e) {
    $conn->rollback();
    // Registrar error (opcional)
    error_log("Error en toggle.php: " . $e->getMessage());
    // Podrías redirigir con un mensaje de error
    header("Location: ../index.php?error=1");
    exit;
}

// Redirigir de vuelta al index
header("Location: ../index.php");
exit;
?>