<?php
require_once __DIR__ . "/../includes/conexion.php";

// Convertir checkbox en 1 o 0
$equipaje = isset($_POST['equipaje']) ? 1 : 0;

// Escapar strings
$cliente   = $conn->real_escape_string($_POST['cliente']);
$origen    = $conn->real_escape_string($_POST['origen']);
$destino   = $conn->real_escape_string($_POST['destino']);
$vuelo     = $conn->real_escape_string($_POST['vuelo']);
$contacto  = $conn->real_escape_string($_POST['contacto']);
$precio    = !empty($_POST['precio']) ? $_POST['precio'] : 0;

// Insert con prepared statement - IMPORTANTE: estado debe ser 'pendiente', NO 'activa'
$stmt = $conn->prepare("
    INSERT INTO reservas
    (cliente, integrantes, fecha, hora, origen, destino, vuelo, equipaje, contacto, precio, estado, info_completa, prioridad, obtenido)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pendiente', 0, 'no_confirmada', 0)
");
$stmt->bind_param(
    "sisssssisi",
    $cliente,
    $_POST['integrantes'],
    $_POST['fecha'],
    $_POST['hora'],
    $origen,
    $destino,
    $vuelo,
    $equipaje,
    $contacto,
    $precio
);

$stmt->execute();
$stmt->close();

header("Location: ../index.php");
exit;
?>