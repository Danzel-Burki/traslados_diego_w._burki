<?php
include("includes/conexion.php");
date_default_timezone_set("America/Argentina/Buenos_Aires");

/* =========================
   MOVER RESERVAS COMPLETADAS
========================= */
$conn->begin_transaction();

try {

    $res = $conn->query("
        SELECT *
        FROM reservas
        WHERE fecha < CURDATE()
           OR (fecha = CURDATE() AND hora <= CURTIME())
    ");

    if ($res && $res->num_rows > 0) {

        $insert = $conn->prepare("
            INSERT INTO reservas_completadas
            (cliente, integrantes, fecha, hora, origen, destino, vuelo,
             info_completa, prioridad, equipaje, contacto, precio, mes, anio)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");

        while ($r = $res->fetch_assoc()) {

            $mes  = (int)date('m', strtotime($r['fecha']));
            $anio = (int)date('Y', strtotime($r['fecha']));

            $insert->bind_param(
                "sisssssiisidii",
                $r['cliente'],
                $r['integrantes'],
                $r['fecha'],
                $r['hora'],
                $r['origen'],
                $r['destino'],
                $r['vuelo'],
                $r['info_completa'],
                $r['prioridad'],
                $r['equipaje'],
                $r['contacto'],
                $r['precio'],
                $mes,
                $anio
            );

            if (!$insert->execute()) {
                throw new Exception("Error al insertar reserva ID {$r['id']}");
            }

            if (!$conn->query("DELETE FROM reservas WHERE id = {$r['id']}")) {
                throw new Exception("Error al eliminar reserva ID {$r['id']}");
            }
        }

        $insert->close();
    }

    $conn->commit();
} catch (Exception $e) {
    $conn->rollback();
    die("ERROR CRÍTICO: " . $e->getMessage());
}

/* =========================
   RESERVAS ACTIVAS
========================= */
$reservas = $conn->query("
    SELECT *
    FROM reservas
    WHERE fecha > CURDATE()
       OR (fecha = CURDATE() AND hora > CURTIME())
    ORDER BY fecha, hora
");
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>SRT-DWB | Administrador</title>
    <link rel="icon" type="image/png" href="./images/asd.png">
    <link rel="stylesheet" href="css/style.css">
</head>

<body>

    <div class="logo">
        <img src="images/logo_oficial.png" alt="SRT-DWB Logo">
    </div>

    <h1>Sistema de Reservas para Traslados DWB <br> – SRT –</h1>

    <div class="acciones-top">
        <div class="botones-principales">
            <a href="./php/calendario.php" class="btn btn-calendario">📅 Calendario</a>
            <a href="php/viajes_completados.php" class="btn btn-historico">📦 Viajes Completados</a>
        </div>

        <?php if (!isset($_GET['nueva'])): ?>
            <a href="?nueva=1" class="btn btn-nueva">➕ Agregar reserva</a>
        <?php endif; ?>
    </div>

    <?php if (isset($_GET['nueva'])): ?>
        <form class="form-reserva" action="php/nueva.php" method="POST">
            <h2>Nueva Reserva</h2>

            <input name="cliente" placeholder="Cliente" required>
            <input type="number" name="integrantes" placeholder="Integrantes" required>
            <input type="date" name="fecha" required>
            <input type="time" name="hora" required>
            <input name="origen" placeholder="Origen">
            <input name="destino" placeholder="Destino">
            <input name="vuelo" placeholder="N° Vuelo">

            <label class="check">
                <input type="checkbox" name="equipaje"> Lleva equipaje
            </label>

            <select name="contacto" required>
                <option value="">Contacto</option>
                <option value="web">Web</option>
                <option value="whatsapp">WhatsApp</option>
                <option value="recomendacion">Recomendación</option>
            </select>

            <input type="number" name="precio" placeholder="Precio">
            <button>Guardar</button>
        </form>
    <?php endif; ?>

    <div class="tabla-wrapper">
        <table class="tabla-reservas">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Info</th>
                    <th>Cliente</th>
                    <th>Int.</th>
                    <th>Fecha</th>
                    <th>Hora</th>
                    <th>Origen</th>
                    <th>Destino</th>
                    <th>Vuelo</th>
                    <th>Prioridad</th>
                    <th>Equipaje</th>
                    <th>Contacto</th>
                    <th>Precio</th>
                    <th>Acción</th>
                </tr>
            </thead>
            <tbody>

                <?php if ($reservas && $reservas->num_rows > 0): ?>
                    <?php while ($r = $reservas->fetch_assoc()): ?>
                        <tr>

                            <td class="center"><?= $r['id'] ?></td>

                            <td class="center">
                                <a href="php/toggle.php?id=<?= $r['id'] ?>&campo=info_completa"
                                    class="check-toggle <?= $r['info_completa'] ? 'ok' : 'no' ?>">
                                    <?= $r['info_completa'] ? '✔' : '✖' ?>
                                </a>
                            </td>

                            <td><?= $r['cliente'] ?></td>
                            <td class="center"><?= $r['integrantes'] ?></td>
                            <td class="center"><?= date("d/m/Y", strtotime($r['fecha'])) ?></td>
                            <td class="center"><?= substr($r['hora'], 0, 5) ?></td>
                            <td><?= $r['origen'] ?></td>
                            <td><?= $r['destino'] ?></td>
                            <td><?= $r['vuelo'] ?></td>

                            <td class="center">
                                <a href="php/toggle.php?id=<?= $r['id'] ?>&campo=prioridad"
                                    class="badge <?= $r['prioridad'] === 'confirmada' ? 'confirmada' : 'no-confirmada' ?>">
                                    <?= $r['prioridad'] === 'confirmada' ? 'Confirmada' : 'No confirmada' ?>
                                </a>
                            </td>

                            <td class="center"><?= $r['equipaje'] ? '✔' : '✖' ?></td>
                            <td class="center"><?= ucfirst($r['contacto']) ?></td>
                            <td class="right">$<?= number_format($r['precio'], 0, ',', '.') ?></td>

                            <td class="center">
                                <a href="php/editar.php?id=<?= $r['id'] ?>" class="btn-editar">✏️</a>
                                <a href="php/eliminar.php?id=<?= $r['id'] ?>"
                                    onclick="return confirm('¿Eliminar reserva?')" class="btn-eliminar">🗑</a>
                            </td>

                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="14" class="center">No hay reservas activas</td>
                    </tr>
                <?php endif; ?>

            </tbody>
        </table>
    </div>
    <script src="js/modo_pre_osc.js"></script>
</body>

<!-- Botón de modo oscuro/claro -->
<div class="theme-toggle-container">
    <button id="themeToggle" class="theme-toggle-btn" aria-label="Cambiar tema">
        <span class="toggle-icon">🌙</span>
    </button>
</div>



</html>