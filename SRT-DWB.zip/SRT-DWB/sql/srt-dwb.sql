-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 10-02-2026 a las 15:21:17
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `srt-dwb`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reservas`
--

CREATE TABLE `reservas` (
  `id` int(11) NOT NULL,
  `cliente` varchar(100) NOT NULL,
  `integrantes` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL,
  `origen` varchar(100) DEFAULT NULL,
  `destino` varchar(100) DEFAULT NULL,
  `vuelo` varchar(50) DEFAULT NULL,
  `info_completa` tinyint(1) DEFAULT 0,
  `estado` enum('pendiente','finalizado') DEFAULT 'pendiente',
  `prioridad` enum('confirmada','no_confirmada') DEFAULT 'no_confirmada',
  `equipaje` tinyint(1) DEFAULT 0,
  `contacto` enum('web','whatsapp','recomendacion') DEFAULT NULL,
  `precio` decimal(10,2) DEFAULT NULL,
  `obtenido` decimal(10,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `reservas`
--

INSERT INTO `reservas` (`id`, `cliente`, `integrantes`, `fecha`, `hora`, `origen`, `destino`, `vuelo`, `info_completa`, `estado`, `prioridad`, `equipaje`, `contacto`, `precio`, `obtenido`) VALUES
(22, 'Yamila', 2, '2026-04-17', '08:00:00', 'Aeropuerto IGR', 'Hospedaje', 'FBZ5100', 1, 'pendiente', 'confirmada', 1, 'web', 160000.00, 0.00),
(23, 'Sabrinha', 3, '2026-05-31', '08:00:00', 'Cataratas Brasileras', 'Ciudad del Este', '...', 0, 'pendiente', 'confirmada', 1, 'web', 200000.00, 0.00),
(24, '...', 2, '2026-02-14', '00:00:00', '...', '...', '...', 0, 'pendiente', 'no_confirmada', 0, 'web', 0.00, 0.00),
(25, 'Gutierrez Andres', 4, '2026-02-17', '08:00:00', 'Aeropuerto IGR', 'Hostel Mirantes ', 'F05470', 0, 'pendiente', 'no_confirmada', 1, 'web', 0.00, 0.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reservas_completadas`
--

CREATE TABLE `reservas_completadas` (
  `id` int(11) NOT NULL,
  `cliente` varchar(100) DEFAULT NULL,
  `integrantes` int(11) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `hora` time DEFAULT NULL,
  `origen` varchar(100) DEFAULT NULL,
  `destino` varchar(100) DEFAULT NULL,
  `vuelo` varchar(50) DEFAULT NULL,
  `info_completa` tinyint(1) DEFAULT NULL,
  `prioridad` enum('confirmada','no_confirmada') DEFAULT NULL,
  `equipaje` tinyint(1) DEFAULT NULL,
  `contacto` enum('web','whatsapp','recomendacion') DEFAULT NULL,
  `precio` decimal(10,2) DEFAULT NULL,
  `mes` int(11) DEFAULT NULL,
  `anio` int(11) DEFAULT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `reservas_completadas`
--

INSERT INTO `reservas_completadas` (`id`, `cliente`, `integrantes`, `fecha`, `hora`, `origen`, `destino`, `vuelo`, `info_completa`, `prioridad`, `equipaje`, `contacto`, `precio`, `mes`, `anio`, `fecha_registro`) VALUES
(1, 'Gowon', 2, '2026-02-07', '09:30:00', 'Aeropuerto IGR', 'Cataratas Brasileñas', 'AR1774', 1, 'confirmada', 1, 'recomendacion', 65000.00, 2, 2026, '2026-02-07 14:11:00'),
(6, 'Gil Ashkenazi', 3, '2026-02-02', '09:00:00', 'Hotel Esturion', 'Cataratas Brasileñas', '...', 0, '', 1, '', 90000.00, 2, 2026, '2026-02-07 14:25:19'),
(9, 'Ilene Resnick', 2, '2026-02-04', '08:30:00', 'Hotel Esturion', 'Cataratas Argentinas', '...', 0, '', 1, '', 100000.00, 2, 2026, '2026-02-07 14:53:44'),
(10, 'Mica tello', 3, '2026-02-08', '08:30:00', 'Estacionamiento', 'Hotel Gran Crucero', '...', 0, '', 1, '', 180000.00, 2, 2026, '2026-02-08 20:31:03');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `reservas`
--
ALTER TABLE `reservas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `reservas_completadas`
--
ALTER TABLE `reservas_completadas`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `reservas`
--
ALTER TABLE `reservas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT de la tabla `reservas_completadas`
--
ALTER TABLE `reservas_completadas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
