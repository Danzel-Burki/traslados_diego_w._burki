<!-- includes/header.php -->
<head>
    <meta charset="UTF-8">
    <title><?php echo $titulo ?? 'Mi Sistema'; ?></title>
    <link rel="icon" type="image/png" href="../images/asd.png">

    <!-- Estilos internos -->
    <style>
        /* ===================== BASE ===================== */
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: "Segoe UI", sans-serif; background: #eef1f5; color: #2c3e50; padding: 20px; }

        /* ===================== TITULOS ===================== */
        h1, h2, h3 { text-align: center; margin-bottom: 20px; }
        h1 { font-size: 2.1rem; margin-bottom: 25px; border-bottom: 4px solid #2980b9; padding-bottom: 12px; }

        /* ===================== BOTONES ===================== */
        .btn { display: inline-block; padding: 12px 20px; border-radius: 10px; font-weight: 600; text-decoration: none; transition: all 0.2s ease-in-out; color: #fff; box-shadow: 0 4px 8px rgba(0,0,0,0.15); text-align: center; cursor: pointer; }
        .btn-calendario { background: #1e90ff; }
        .btn-calendario:hover { background: #187bcd; transform: translateY(-2px); }
        .btn-historico { background: #3498db; }
        .btn-historico:hover { background: #2a7bbd; transform: translateY(-2px); }
        .btn-nueva { background: #27ae60; }
        .btn-nueva:hover { background: #1e8449; transform: translateY(-2px); }
        .btn-volver { background: #7f8c8d; padding: 12px 25px; font-weight: 600; border-radius: 10px; box-shadow: 0 5px 12px rgba(0,0,0,0.2); transition: all 0.2s ease-in-out; display: inline-block; text-align: center; cursor: pointer; }
        .btn-volver:hover { background: #636e72; transform: translateY(-2px); }

        /* ===================== CONTENEDORES ===================== */
        .acciones-top { display: flex; gap: 10px; justify-content: center; margin-bottom: 20px; flex-wrap: wrap; }

        /* ===================== TABLAS ===================== */
        .tabla-wrapper { overflow-x: auto; margin-top: 20px; }
        table { width: 100%; border-collapse: collapse; background: #fff; border-radius: 12px; box-shadow: 0 8px 20px rgba(0,0,0,0.15); }
        th, td { border: 1px solid #ccc; padding: 10px; text-align: center; }
        th { background: #2c3e50; color: #fff; }
        tbody tr:hover { background: #e8f0ff; }
        .ellipsis { max-width: 160px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

        /* ===================== FORMULARIOS ===================== */
        .form-reserva { max-width: 900px; background: #fff; margin: 30px auto; padding: 30px; border-radius: 18px; display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px; }
        .form-reserva h2 { grid-column: 1 / -1; text-align: center; }
        .form-reserva input, .form-reserva select { padding: 12px; border-radius: 8px; border: 2px solid #ccc; }
        .form-reserva button { grid-column: 1 / -1; padding: 14px; background: #27ae60; border: none; color: #fff; font-weight: bold; border-radius: 10px; cursor: pointer; }

        /* ===================== ACCIONES ===================== */
        .acciones a { display: inline-flex; justify-content: center; align-items: center; width: 34px; height: 34px; margin: 0 2px; border-radius: 8px; text-decoration: none; font-size: 1.1rem; }
        .acciones a:first-child { background: #d6eaff; }
        .acciones a:last-child { background: #fdecea; }

        /* ===================== ESTADOS DE RESERVAS ===================== */
        tr.finalizado { opacity: 0.55; }
        .estado { font-weight: bold; }

        /* ===================== CALENDARIO ===================== */
        .calendario { width: 100%; max-width: 700px; margin: 20px auto; border-collapse: collapse; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
        .calendario th, .calendario td { border: 1px solid #ccc; width: 14.28%; height: 60px; text-align: center; vertical-align: middle; }
        .calendario th { background: #2980b9; color: #fff; }
        .calendario td a { display: block; width: 100%; height: 100%; line-height: 60px; text-decoration: none; color: inherit; }
        .con-reserva { background: #9be7a5; font-weight: bold; }
        .calendario td:hover { background: #d0e6ff; }

        /* ===================== CUADROS ===================== */
        .cuadro-container { display: grid; grid-template-columns: repeat(auto-fit, minmax(120px, 1fr)); justify-items: center; gap: 12px; margin-bottom: 20px; }
        .cuadro { padding: 12px 20px; border: 1px solid #333; cursor: pointer; background: #3498db; color: #fff; border-radius: 8px; text-decoration: none; font-weight: bold; text-align: center; transition: all 0.2s ease-in-out; }
        .cuadro:hover { background: #2874a6; transform: translateY(-2px); }

        /* ===================== BOTONES VOLVER ===================== */
        .volver-container { display: flex; justify-content: center; gap: 15px; margin: 25px 0; flex-wrap: wrap; }
        .volver-container a { text-decoration: none; padding: 12px 25px; background: #7f8c8d; color: #fff; border-radius: 10px; font-weight: 600; box-shadow: 0 5px 12px rgba(0,0,0,0.2); transition: all 0.2s ease-in-out; display: inline-block; text-align: center; cursor: pointer; }
        .volver-container a:hover { background: #636e72; transform: translateY(-2px); }

        /* ===================== UTILIDADES ===================== */
        .center { text-align: center; }
        .right { text-align: right; }
        .text { text-align: left; }

        /* ===================== RESPONSIVE ===================== */
        @media (max-width: 900px) {
            .form-reserva { grid-template-columns: 1fr; }
            .acciones-top { flex-direction: column; gap: 10px; }
            .cuadro-container { grid-template-columns: repeat(auto-fit, minmax(100px, 1fr)); }
            .volver-container { flex-direction: column; gap: 10px; }
        }
    </style>
</head>
