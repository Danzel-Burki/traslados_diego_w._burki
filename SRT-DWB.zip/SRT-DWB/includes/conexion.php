<?php
$conn = new mysqli(
    "127.0.0.1",
    "root",
    "",
    "srt-dwb",
    3306
);

if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");
