<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Traslados Diego W. Burki</title>

  <!-- Estilos -->
  <link rel="stylesheet" href="./css/estilos.css" />

  <!-- FONT AWESOME 6 Free -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">

  <!-- Favicon -->
  <link rel="icon" href="./images/logos/tuqui.png" type="image/png" />

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet" />

  <!-- AOS Animations -->
  <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet" />

  <style>
    html {
      scroll-behavior: smooth;
    }
  </style>
</head>

<body>
  <!-- ==================== FONDO DINÁMICO ==================== -->
  <div id="background-carousel" aria-hidden="true"></div>

  <!-- ==================== HEADER CON MENÚ HAMBURGUESA ==================== -->
  <header>
    <div class="logo-social">
      <div class="logo">
        <img src="./images/logos/logo_oficial.png" alt="Logo" />
      </div>
      <div class="social-icons">
        <a href="https://www.facebook.com/profile.php?id=61579024276825" target="_blank" class="facebook" rel="noopener noreferrer">
          <img src="https://img.icons8.com/color/48/000000/facebook-new.png" alt="Facebook" />
        </a>
        <a href="https://www.instagram.com/traslados_diego_w._burki/" target="_blank" class="instagram" rel="noopener noreferrer">
          <img src="https://img.icons8.com/color/48/000000/instagram-new.png" alt="Instagram" />
        </a>
        <a href="https://wa.me/3757681414" target="_blank" class="whatsapp" rel="noopener noreferrer">
          <img src="https://img.icons8.com/color/48/000000/whatsapp.png" alt="WhatsApp" />
        </a>
      </div>

      <!-- Botón hamburguesa -->
      <div class="hamburger" id="hamburger">
        <span></span>
        <span></span>
        <span></span>
      </div>
    </div>

    <!-- Menú de navegación -->
<nav id="nav-menu" class="nav-menu">
  <ul>
    <li><a href="#inicio" data-translate="inicio">Inicio</a></li>
    <li><a href="#servicios-de-turismo" data-translate="servicios-de-turismo">Servicios de turismo</a></li>
    <li><a href="#viajes" data-translate="viajes">Viajes Realizados</a></li>
    <li><a href="#nosotros-modern" data-translate="nosotros-modern">Nosotros</a></li>
    <li><a href="#contactos" data-translate="contactos">Contactos</a></li>
  </ul>
</nav>

    <div class="header-curva">
      <svg viewBox="0 0 1440 120" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M0,60 C300,120 300,0 600,60 C900,120 900,0 1200,60 C1300,90 1400,80 1440,60 L1440,0 L0,0 Z" fill="#fff" />
      </svg>
    </div>
  </header>
 
<!-- ==================== SELECTOR DE IDIOMA ==================== -->
<div id="language-selector" class="language-selector">
  <button id="language-toggle" class="language-toggle" aria-label="Cambiar idioma">
    <i class="fas fa-globe"></i>
    <span id="current-language">ES</span>
  </button>

  <div id="language-options" class="language-options">

    <!-- Español -->
    <button class="language-option" data-lang="es">
      <img 
        src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA5IDYiPjxyZWN0IHdpZHRoPSI5IiBoZWlnaHQ9IjYiIGZpbGw9IiNBQTE1MUIiLz48cmVjdCB3aWR0aD0iOSIgaGVpZ2h0PSIyIiB5PSIyIiBmaWxsPSIjRjFCRjAwIi8+PC9zdmc+"
        alt="Español" class="lang-flag"
      >
      Español
    </button>

    <!-- English -->
    <button class="language-option" data-lang="en">
      <img 
        src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA2MCAzMCI+PGNsaXBQYXRoIGlkPSJ0Ij48cGF0aCBkPSJNM CwwIHYzMCBoNjAgdi0zMCB6Ii8+PC9jbGlwUGF0aD48cGF0aCBkPSJNM CwwIHYzMCBoNjAgdi0zMCB6IiBmaWxsPSIjMDEyMTY5Ii8+PHBhdGggZD0iTTAsMC BMNjAsMzAgTTYwLDAgTDAsMzAiIHN0cm9rZT0iI2ZmZiIgc3Ryb2tlLXdpZHRoPSI2Ii8+PHBhdGggZD0iTTAsMC BMNjAsMzAgTTYwLDAgTDAsMzAiIHN0cm9rZT0iI0M4MTAyRSIgc3Ryb2tlLXdpZHRoPSI0Ii8+PHBhdGggZD0iTTMwLDA gdjMw IE0wLDE1IGg2MCIgc3Ryb2tlPSIjZmZmIiBzdHJva2Utd2lkdGg9IjEwIi8+PHBhdGggZD0iTTMwLDA gdjMw IE0wLDE1IGg2MCIgc3Ryb2tlPSIjQzgxMDJFIiBzdHJva2Utd2lkdGg9IjYiLz48L3N2Zz4="
        alt="English" class="lang-flag"
      >
      English
    </button>

    <!-- Português -->
    <button class="language-option" data-lang="pt">
      <img 
        src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA3IDUiPjxyZWN0IHdpZHRoPSI3IiBoZWlnaHQ9IjUiIGZpbGw9IiMwMDlDM0IiLz48cG9seWdvbiBwb2ludHM9IjMuNSwwLjYgNiw yLjUgMy41LDQuNCAxLDIuNSIgZmlsbD0iI0ZGREYwMCIvPjxjaXJjbGUgY3g9IjMuNSIgY3k9IjIuNSIgcj0iMSIgZmlsbD0iIzAwMjc3NiIvPjwvc3ZnPg=="
        alt="Português" class="lang-flag"
      >
      Português
    </button>

  </div>
</div>


<!-- ==================== NOTIFICACIÓN DE IDIOMA ==================== -->
<div id="language-notification" class="language-notification">
  <div class="notification-content">
    <span class="notification-icon">🌐</span>
    <div class="notification-text">
      <strong data-translate="language-notice-title">¿Hablas otro idioma?</strong>
      <span data-translate="language-notice-message">Puedes cambiar el idioma del sitio en cualquier momento</span>
    </div>
    <button id="close-language-notification" class="notification-close" aria-label="Cerrar notificación">
      <i class="fas fa-times"></i>
    </button>
  </div>
</div>

  

  <!-- ==================== SECCIÓN HERO ==================== -->
  <section id="inicio" class="hero" data-aos="fade-up">
    <div class="hero-background" id="heroBackground" aria-hidden="true">
      <div class="capa capa1"></div>
      <div class="capa capa2"></div>
    </div>

    <div class="hero-content">
      <h1>
        <span class="bienvenidos" data-translate="bienvenidos">Bienvenidos a </span> <br>
        <span class="nombre" data-translate="nombre">Traslados Diego<span class="rojo">W.</span> Burki</span>
      </h1>
      <p data-translate="slogan">"Servicio profesional de transporte turístico en todo el país"</p>
    </div>

    <!-- Imagen del tucán dentro del hero -->
    <img src="./images/logos/asd.png" alt="Tucán" class="tucan-flotante">

    <button class="arrow left" onclick="cambiarFondo(-1)" aria-label="Fondo anterior">&#10094;</button>
    <button class="arrow right" onclick="cambiarFondo(1)" aria-label="Fondo siguiente">&#10095;</button>
  </section>

  <!-- ==================== SECCIÓN SERVICIOS ==================== -->
  <section id="servicios-de-turismo" class="section servicios" data-aos="fade-left">
    <div class="container">
      <div class="contenido-servicios">
        <h2 data-translate="servicio-turismo">SERVICIO DE TURISMO</h2>

        <div class="servicios-lista">
          <!-- SERVICIO 1 - Turismo Provincial -->
          <div class="servicio-card" data-aos="zoom-in">
            <img src="https://cdn-icons-png.flaticon.com/512/854/854878.png" alt="Turismo Provincial" class="icono-servicio">
            <h3 data-translate="turismo-provincial">Turismo <br> Provincial</h3>
            <div class="baraja">
              <div class="carta" data-service="provincial" data-index="0">
                <img src="./images/servicios/servicio_10.jpg" alt="Saltos Del Moconá">
              </div>
              <div class="carta" data-service="provincial" data-index="4">
                <img src="./images/servicios/servicio_1.jpg" alt="Cataratas Iguazú">
              </div>
              <div class="carta" data-service="provincial" data-index="1">
                <img src="./images/servicios/servicio_3.jpg" alt="Güirá Oga">
              </div>
              <div class="carta" data-service="provincial" data-index="2">
                <img src="./images/servicios/servicio_5.jpg" alt="Gruta India">
              </div>
              <div class="carta" data-service="provincial" data-index="3">
                <img src="./images/servicios/servicio_7.jpg" alt="Minas de Wanda">
              </div>
            </div>

            <!-- Lista de lugares turísticos provinciales con íconos -->
            <ul class="lista-turismo" data-service="provincial">
              <li data-index="4"><i class="fas fa-water"></i> <span data-translate="cataratas-iguazu">Cataratas del Iguazú</span></li>
              <li data-index="1"><i class="fas fa-map-marked-alt"></i> <span data-translate="lugares-turisticos-iguazu">Güirá Oga</span></li>
              <li data-index="2"><i class="fas fa-mountain"></i> <span data-translate="gruta-india">Gruta India</span></li>
              <li data-index="3"><i class="fas fa-gem"></i> <span data-translate="minas-wanda">Minas de Wanda</span></li>
              <li data-index="0"><i class="fas fa-bus"></i> <span data-translate="tour-dia">Saltos Del Moconá</span></li>
            </ul>
          </div>

          <!-- SERVICIO 2 - Traslados Internacionales -->
          <div class="servicio-card" data-aos="zoom-in" data-aos-delay="100">
            <img src="https://cdn-icons-png.flaticon.com/512/201/201623.png" alt="Turismo Internacional" class="icono-servicio">
            <h3 data-translate="turismo-internacional">Turismo Internacional</h3>
            <div class="baraja">
              <div class="carta" data-service="internacional" data-index="0">
                <img src="./images/servicios/servicio_2.jpg" alt="Cataratas Brasileras">
              </div>
              <div class="carta" data-service="internacional" data-index="1">
                <img src="./images/servicios/servicio_4.jpg" alt="Tour de compras, Ciudad del Este">
              </div>
              <div class="carta" data-service="internacional" data-index="2">
                <img src="./images/servicios/servicio_6.jpg" alt="Aeropuerto Brasileño (Foz Iguazú)">
              </div>
              <div class="carta" data-service="internacional" data-index="3">
                <img src="./images/servicios/servicio_8.jpg" alt="Parque Das Aves">
              </div>
              <div class="carta" data-service="internacional" data-index="4">
                <img src="./images/servicios/servicio_9.jpg" alt="Yup Star">
              </div>
            </div>

            <!-- Lista de lugares turísticos internacionales con íconos -->
            <ul class="lista-turismo" data-service="internacional">
              <li data-index="0"><i class="fas fa-water"></i> <span data-translate="cataratas-brasileras">Cataratas Brasileras</span></li>
              <li data-index="1"><i class="fas fa-shopping-bag"></i> <span data-translate="tour-compras">Tour de compras, Ciudad del Este</span></li>
              <li data-index="2"><i class="fas fa-plane-departure"></i> <span data-translate="aeropuerto-internacional">Aeropuerto Brasileño (Foz Iguazú)</span></li>
              <li data-index="3"><i class="fas fa-dove"></i> <span data-translate="parque-aves">Parque Das Aves</span></li>
              <li data-index="4"><i class="fas fa-bus"></i> <span data-translate="yup-star">Yup Star</span></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- ==================== MODAL SERVICIOS ==================== -->
  <div id="modalServicios" class="modal">
    <span class="cerrar">&times;</span>
    <div class="modal-contenido">
      <button class="anterior">&#10094;</button>
      <div id="modalMediaServicios"></div>
      <button class="siguiente">&#10095;</button>
    </div>
    <div id="modalDescripcionServicios"></div>
  </div>

  <!-- ==================== SECCIÓN GALERIA DE VIAJES ==================== -->
  <section id="viajes" class="section viajes" data-aos="fade-up">
    <div class="container">
      <div class="viajes-header">
        <h2 class="titulo-viajes" data-translate="viajes-realizados">VIAJES REALIZADOS</h2>
        <p data-translate="viajes-descripcion">"Explorá algunos de los destinos en los que hemos brindado nuestros servicios. A lo largo de nuestra trayectoria hemos trasladado personas provenientes de países como Brasil, Austria, Costa Rica, Inglaterra, Francia, Argentina, Puerto Rico, Australia, Perú, Colombia y Chile."</p>
        <a href="https://www.trustpilot.com/review/traslados-dwb-iguazu.com.ar" class="btn-reseñas" target="_blank" rel="noopener" data-translate="ver-resenas">Ver Reseñas</a>
      </div>

      <!-- Grid principal con las primeras 6 fotos/videos -->
      <div class="viajes-grid" id="viajes-principales">
        <!-- 6 primeros viajes -->
        <div class="viaje" data-aos="zoom-in" data-title="Helisul">
          <video src="./images/galeria_viajes_clientes/client_1.mp4" muted></video>
          <div class="descripcion" data-translate="helisul-brasil">Helisul (Brasil)</div>
        </div>
        <div class="viaje" data-aos="zoom-in" data-aos-delay="100">
          <img src="./images/galeria_viajes_clientes/client_2.jpg" />
          <div class="descripcion" data-translate="gruta-india-misiones">Gruta India (Misiones ARG)</div>
        </div>
        <div class="viaje" data-aos="zoom-in" data-aos-delay="200">
          <img src="./images/galeria_viajes_clientes/client_3.jpg" />
          <div class="descripcion" data-translate="gruta-india-misiones">Gruta India (Misiones ARG)</div>
        </div>
        <div class="viaje" data-aos="zoom-in" data-aos-delay="300">
          <img src="./images/galeria_viajes_clientes/client_4.jpg" />
          <div class="descripcion" data-translate="cell-shop-paraguay">Cell Shop (Paraguay)</div>
        </div>
        <div class="viaje" data-aos="zoom-in" data-aos-delay="400">
          <img src="./images/galeria_viajes_clientes/client_5.jpg" />
          <div class="descripcion" data-translate="iguazu-misiones">Iguazú (Misiones ARG)</div>
        </div>
        <div class="viaje" data-aos="zoom-in" data-aos-delay="400">
          <img src="./images/galeria_viajes_clientes/client_6.jpg" />
          <div class="descripcion" data-translate="iguazu-misiones">Iguazú (Misiones ARG)</div>
        </div>
      </div>

      <!-- Botón centrado debajo del grid principal -->
      <div class="contenedor-boton">
        <button id="btn-mostrar-mas" class="btn-mostrar-mas" data-translate="ver-mas-viajes">Ver más viajes</button>
      </div>

      <!-- Grid oculto debajo del botón -->
      <div id="viajes-ocultos" class="viajes-grid oculto">
        <!-- viajes ocultos -->
        <div class="viaje" data-title="Cataratas del Iguazú (Misiones ARG)">
          <img src="./images/galeria_viajes_clientes/client_32.jpg" />
          <div class="descripcion">David, familia y amigos desde Bueno Aires.</div>
        </div>
        <div class="viaje" data-title="Ciudad del este Paraguay">
          <img src="./images/galeria_viajes_clientes/client_31.jpg" />
          <div class="descripcion">Hotel Marambaia</div>
        </div>
        <div class="viaje" data-title="Cataratas del Iguazú (Misiones ARG)">
          <img src="./images/galeria_viajes_clientes/client_7.jpg" />
          <div class="descripcion">Alejo y familia desde Buenos Aires.</div>
        </div>
        <div class="viaje" data-title="Cell Shop (Paraguay)">
          <img src="./images/galeria_viajes_clientes/client_8.jpg" />
          <div class="descripcion" data-translate="cell-shop-paraguay">Cell Shop (Paraguay)</div>
        </div>
        <div class="viaje" data-title="Parque Das Aves (Brasil)">
          <img src="./images/galeria_viajes_clientes/client_9.jpg" />
          <div class="descripcion" data-translate="parque-aves">Parque Das Aves (Brasil)</div>
        </div>
        <div class="viaje" data-title="Iguazú (Misiones ARG)">
          <img src="./images/galeria_viajes_clientes/client_10.jpg" />
          <div class="descripcion" data-translate="iguazu-misiones">Iguazú (Misiones ARG)</div>
        </div>
        <div class="viaje" data-title="Cataratas del Iguazú (Misiones ARG)">
          <img src="./images/galeria_viajes_clientes/client_11.jpg" />
          <div class="descripcion" data-translate="cataratas-iguazu">Cataratas del Iguazú (Misiones ARG)</div>
        </div>
        <div class="viaje" data-title="Cataratas del Iguazú (Misiones ARG)">
          <img src="./images/galeria_viajes_clientes/client_12.jpg" />
          <div class="descripcion" data-translate="cataratas-iguazu">Cataratas del Iguazú (Misiones ARG)</div>
        </div>
        <div class="viaje" data-title="Minas de Wanda (Misiones ARG)">
          <img src="./images/galeria_viajes_clientes/client_13.jpg" />
          <div class="descripcion" data-translate="minas-wanda">Minas de Wanda (Misiones ARG)</div>
        </div>
        <div class="viaje" data-title="Minas de Wanda">
          <img src="./images/galeria_viajes_clientes/client_14.jpg" />
          <div class="descripcion" data-translate="minas-wanda">Minas de Wanda (Misiones ARG)</div>
        </div>
        <div class="viaje" data-title="Cell Shop (Paraguay)">
          <img src="./images/galeria_viajes_clientes/client_15.jpg" />
          <div class="descripcion" data-translate="cell-shop-paraguay">Cell Shop (Paraguay)</div>
        </div>
        <div class="viaje" data-title="Cataratas del Iguazú (Misiones ARG)">
          <img src="./images/galeria_viajes_clientes/client_16.jpg" />
          <div class="descripcion" data-translate="cataratas-iguazu">Cataratas del Iguazú (Misiones ARG)</div>
        </div>
        <div class="viaje" data-title="Cataratas del Iguazú (Misiones ARG)">
          <img src="./images/galeria_viajes_clientes/client_17.jpg" />
          <div class="descripcion" data-translate="cataratas-iguazu">Cataratas del Iguazú (Misiones ARG)</div>
        </div>
        <div class="viaje" data-title="Cataratas del Iguazú (Misiones ARG)">
          <img src="./images/galeria_viajes_clientes/client_18.jpg" />
          <div class="descripcion" data-translate="cataratas-iguazu">Cataratas del Iguazú (Misiones ARG)</div>
        </div>
        <div class="viaje" data-title="">
          <img src="./images/galeria_viajes_clientes/client_19.jpg" />
          <div class="descripcion">Aeropuerto ARG (Misiones ARG)</div>
        </div>
        <div class="viaje" data-title="Minas de Wanda">
          <img src="./images/galeria_viajes_clientes/client_20.jpg" />
          <div class="descripcion" data-translate="cataratas-iguazu">Cataratas del Iguazú (Misiones ARG)</div>
        </div>
        <div class="viaje" data-title="Cataratas del Iguazú (Misiones ARG)">
          <img src="./images/galeria_viajes_clientes/client_21.jpg" />
          <div class="descripcion">Jorge, Marcos y Rodrigo de Montevideo Uruguay</div>
        </div>
        <div class="viaje" data-title="Cataratas del Iguazú (Misiones ARG)">
          <img src="./images/galeria_viajes_clientes/client_22.jpg" />
          <div class="descripcion" data-translate="cataratas-iguazu">Cataratas del Iguazú (Misiones ARG)</div>
        </div>
        <div class="viaje" data-title="Ciudad del Este (Paraguay)">
          <img src="./images/galeria_viajes_clientes/client_23.jpg" />
          <div class="descripcion">Jorge de Montevideo Uruguay</div>
        </div>
        <div class="viaje" data-title="Minas de Wanda">
          <img src="./images/galeria_viajes_clientes/client_24.jpg" />
          <div class="descripcion" data-translate="minas-wanda">Minas de Wanda (Misiones ARG)</div>
        </div>
        <div class="viaje" data-title="Cataratas del Iguazú (Misiones ARG)">
          <img src="./images/galeria_viajes_clientes/client_25.jpg" />
          <div class="descripcion" data-translate="cataratas-iguazu">Cataratas del Iguazú (Misiones ARG)</div>
        </div>
        <div class="viaje" data-title="Minas de Wanda">
          <video src="./images/galeria_viajes_clientes/client_26.mp4" muted></video>
          <div class="descripcion">Güirá Oga Iguazú (Misiones ARG)</div>
        </div>
        <div class="viaje" data-title="Minas de Wanda">
          <video src="./images/galeria_viajes_clientes/client_27.mp4" muted></video>
          <div class="descripcion">Camino al aeropuerto de Iguazú (Misiones ARG)</div>
        </div>
        <div class="viaje" data-title="Cell Shop (Paraguay)">
          <video src="./images/galeria_viajes_clientes/client_28.mp4" muted></video>
          <div class="descripcion" data-translate="cell-shop-paraguay">Cell Shop (Paraguay)</div>
        </div>
        <div class="viaje" data-title="Minas de Wanda">
          <video src="./images/galeria_viajes_clientes/client_29.mp4" muted></video>
          <div class="descripcion">Restarante "Tatu carreta" (Misiones ARG)</div>
        </div>
        <div class="viaje" data-title="Minas de Wanda">
          <video src="./images/galeria_viajes_clientes/client_30.mp4" muted></video>
          <div class="descripcion">Camino a cataratas Argentinas (Misiones ARG) </div>
        </div>
        <div class="viaje" data-title="Aripuca, Iguazú (Misiones ARG)">
          <img src="./images/galeria_viajes_clientes/client_33.jpg" />
          <div class="descripcion">José, Ana y familia desde las Sierras de Córdoba </div>
        </div>
        <div class="viaje" data-title="Yup Star rueda gigante (Foz do Iguaçu Brasil)">
          <img src="./images/galeria_viajes_clientes/client_34.jpg" />
          <div class="descripcion">Yup Star Rueda Gigante, Familia Sagrera</div>
        </div>
        <div class="viaje" data-title="(De Foz do Iguazú a Ciudad de Iguazú)">
          <img src="./images/galeria_viajes_clientes/client_35.jpg" />
          <div class="descripcion">De Foz do Iguazú a Ciudad de Iguazú, Nati y Shelly desde Escocia </div>
        </div>
        <div class="viaje" data-title="(Foz do Iguaçu Brasil a Cataratas Argentinas)">
          <img src="./images/galeria_viajes_clientes/client_36.jpg" />
          <div class="descripcion">Phil y Felix de Alemania, de Foz a Cataratas Argentinas (Falls Galli Hotel Foz do Iguazú Brasil)</div>
        </div>
        <div class="viaje" data-title="(Cataratas Argentinas)">
          <img src="./images/galeria_viajes_clientes/client_37.jpg" />
          <div class="descripcion">Pamela, Ezequiel y su familia desde Capital Federal, (Cataratas Argentinas, Güira Oga y Paseo en el barco)</div>
        </div>
        <div class="viaje" data-title="(Cataratas Argentinas)">
          <img src="./images/galeria_viajes_clientes/client_38.jpg" />
          <div class="descripcion"> Marcelo Esteban, Verónica, Camila y Karen de Mar Del Plata Argentina, (Cataratas Argentinas)</div>
        </div>
      </div>
    </div>
  </section>

  <!-- ==================== MODAL VIAJES ==================== -->
  <div id="modalViajes" class="modal">
    <span class="cerrar">&times;</span>
    <div class="modal-contenido">
      <button class="anterior">&#10094;</button>
      <div id="modalMediaViajes"></div>
      <button class="siguiente">&#10095;</button>
    </div>
    <div id="modalDescripcionViajes"></div>
  </div>

  <!-- ==================== SECCIÓN NOSOTROS ==================== -->
  <section id="nosotros-modern" data-aos="fade-up">
    <div class="nosotros-modern">
      <div class="nosotros-imagen">
        <img src="./images/logos/pefil_oficial.png" alt="Imagen del equipo de Traslados" />
      </div>
      <div class="nosotros-texto">
        <h2 data-translate="quienes-somos">¿QUIÉNES SOMOS?</h2>
        <p data-translate="nosotros-descripcion">
          <span class="rojo"> S</span>    omos un servicio de traslados confiable y seguro de ciudad de Puerto Iguazú, Misiones. Nos especializamos en brindar transporte cómodo, puntual y personalizado para turistas que desean conocer la región, como las Cataratas del Iguazú, el Hito Tres Fronteras, y mucho más.
          ¡Tu viaje comienza con nosotros!
        </p>
      </div>
    </div>
  </section>

  <!-- ==================== FOOTER - CONTACTO ==================== -->
  <footer id="contactos" class="contactos" data-aos="fade-up">
    <div class="footer-container">
      <div class="footer-contacto">
        <h4 data-translate="contactos-titulo">Contactos</h4>
        <p>📞 <a href="https://wa.me/3757681414" target="_blank">+54 9 3757 68 1414</a></p>
        <p>✉️ traslados.dwb.iguazu@gmail.com</p>
        <p>📍 Iguazú, Misiones, Argentina</p>
      </div>

      <div class="footer-redes">
        <h4 data-translate="redes-sociales">Redes Sociales</h4><br>

        <!-- Facebook -->
        <a href="https://www.facebook.com/profile.php?id=61579024276825"
          aria-label="Facebook"
          target="_blank"
          rel="noopener noreferrer">
          <img src="https://img.icons8.com/color/48/000000/facebook-new.png" alt="Facebook" />
        </a>

        <!-- Instagram -->
        <a href="https://www.instagram.com/traslados_diego_w._burki/"
          aria-label="Instagram"
          target="_blank"
          rel="noopener noreferrer">
          <img src="https://img.icons8.com/color/48/000000/instagram-new.png" alt="Instagram" />
        </a>

        <!-- WhatsApp -->
        <a href="https://wa.me/3757681414"
          aria-label="WhatsApp"
          target="_blank"
          rel="noopener noreferrer">
          <img src="https://img.icons8.com/color/48/000000/whatsapp.png" alt="WhatsApp" />
        </a>
      </div>

      <div class="footer-pagos">
        <h4 data-translate="medios-pago">Medios de Pago</h4>
        <div class="pagos-iconos">
          <img src="https://img.icons8.com/color/48/000000/visa.png" alt="Visa" />
          <img src="https://img.icons8.com/color/48/000000/mastercard-logo.png" alt="MasterCard" />
          <img src="https://img.icons8.com/color/48/000000/cash-in-hand.png" alt="Efectivo" />
          <img src="https://img.icons8.com/color/48/000000/qr-code.png" alt="QR" />
        </div>
      </div>
    </div>

    <div class="footer-content">
      <div class="footer-logo">
        <img src="./images/logos/logo_oficial_reducido.jpg" alt="Logo Diego W. Burki">
      </div>

      <div class="footer-creditos">
        <p>&copy; 2025 Traslados Diego W. Burki. <span data-translate="derechos-reservados">Todos los derechos reservados.</span>
          <span data-translate="desarrollado-por">Desarrollado por Danzel Blotz Burki</span>
        </p>
      </div>
    </div>
  </footer>

  <!-- ==================== CHATBOT TUCÁN (floater) ==================== -->
  <button id="tucanChatBtn" aria-label="Chat de ayuda" title="Ayuda">
    <img src="./images/logos/tuqui.png" alt="TUQUI" />
  </button>


<!-- ==================== CHATBOT TUCÁN ==================== -->
<div id="tucanChatOverlay" class="chat-overlay hidden" role="dialog" aria-modal="true" aria-label="Chat de ayuda">
    <div class="chat-container">
        <!-- Header -->
        <div class="chat-header">
            <span class="chat-title">
                <img src="./images/logos/tuqui.png" alt="TUQUI" class="tucan-avatar">
                Asistente TUQUI
            </span>
            <button id="closeChatOverlay" class="chat-close-btn" aria-label="Cerrar chat">&times;</button>
        </div>

        <!-- Body -->
        <div class="chat-body" id="chatOverlayBody" role="log" aria-live="polite">
            <!-- Los mensajes del chat se insertarán aquí -->
        </div>

        <!-- Footer -->
        <div class="chat-footer">
            <div class="chat-input-container">
                <input type="text" id="chatOverlayInput" placeholder="How can we help you?" aria-label="Escribe tu pregunta" autocomplete="off">
                <!-- Icono de cambio de idioma -->
                <button id="chatLanguageToggle" class="chat-language-toggle" aria-label="Cambiar idioma">
                    <i class="fas fa-language"></i>
                </button>
            </div>
            <button id="chatOverlaySend" aria-label="Enviar mensaje">Enviar</button>
        </div>
    </div>
</div>

  <!-- ==================== WHATSAPP FLOTANTE ==================== -->
  <a href="https://wa.me/3757681414" target="_blank" id="whatsappBtn" aria-label="Contactar por WhatsApp">
    <img src="https://cdn-icons-png.flaticon.com/512/733/733585.png" alt="WhatsApp">
  </a>

  <!-- ==================== BOTÓN VOLVER ARRIBA ==================== -->
  <button id="scrollTopBtn" title="Volver arriba" aria-label="Volver arriba">
    &#11014;
  </button>

  <!-- ==================== SCRIPTS ==================== -->
  <script src="./js/background.js"></script>
  <script src="./js/hero_fondo.js"></script>
  <script src="./js/scroll_menu.js"></script>
  <script src="./js/scroll_top.js"></script>
  <script src="./js/servicios.js"></script>
  <script src="./js/observador.js"></script>
  <script src="./js/bt_ver_mas-menos.js"></script>
  <script src="./js/scroll_center.js"></script>
  <script src="./js/header_compressed.js"></script>
  <script src="./js/scroll_spy.js"></script>
  <script src="./js/modal_galeria.js"></script>
  <script src="./js/modal_servicios.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
  <script src="./js/modal_lista_servicios_pn.js"></script>
  <script src="./js/burger.js"></script>
  <script src="./js/chatbot.js"></script>
  <script src="./js/ocultar_aviso.js"></script>
  <script src="./js/burger_cerrar.js"></script>
  <script src="./js/chatbot-controls.js"></script>
  <script src="./js/translations.js"></script>
  <script src="./js/chatbot-floating-controls.js"></script>
  <script src="./js/chatbot-floating-buttons.js"></script>
  <script src="./js/chatbot-notice-fixed.js"></script>
  <script src="./js/scroll-simple.js"></script>


  <script>
    AOS.init();
  </script>

</body>

</html>