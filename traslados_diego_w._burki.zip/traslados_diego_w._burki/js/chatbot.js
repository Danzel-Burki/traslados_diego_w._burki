// chatbot.js - VERSIÓN COMPLETA CORREGIDA CON MANEJO DE RESERVAS
document.addEventListener('DOMContentLoaded', function () {
    // ==================== ELEMENTOS DEL DOM ====================
    const chatBtn = document.getElementById('tucanChatBtn');
    let chatOverlay = document.getElementById('tucanChatOverlay');
    const closeOverlayBtn = document.getElementById('closeChatOverlay');
    const sendBtn = document.getElementById('chatOverlaySend');
    const userInput = document.getElementById('chatOverlayInput');
    let chatBody = document.getElementById('chatOverlayBody');
    const typingIndicator = document.createElement('div');

    // ==================== INFORMACIÓN DE SERVICIOS (con precios AR) ====================
    const servicesInfo = {
        nacional: [  
            "Cataratas argentinas (Pto. Iguazú) → Hotel — 50.000 (AR)",
            "Ruinas San Ignacio (San Ignacio) → Hotel — 380.000 (AR)",
            "Duty Free (Pto. Iguazú) → Hotel — GRATIS",
            "Güira Oga (Pto. Iguazú) → Hotel — 15.000 (AR)",
            "Minas de Wanda (Wanda) → Hotel — 70.000 (AR)",
            "Saltos del Moconá (El Soberbio) → Hotel — 450.000 (AR)",
            "Aeropuerto Argentino → Hotel — 50.000 (AR)",
            "Hito Tres Fronteras (Pto. Iguazú) → Hotel — 15.000 (AR)",
            "Salto Encantado (Aristóbulo del Valle) → Hotel — 450.000 (AR)",
            "Gruta India + Cueva del Yaguareté (Garuhapé) → Hotel — 350.000 (AR)",
            "Salto Mbocay (Pto. Iguazú) → Hotel — 35.000 (AR)",
            "Salto Del Turista (Pto. Iguazú) → Hotel — 35.000 (AR)"
        ],
        international: [
            "Cataratas brasileras (Foz do Iguaçu) → Hotel — 90.000 (AR)",
            "Parque das Aves (Foz do Iguaçu) — 90.000 (AR)",
            "Aeropuerto Brasileño (Foz do Iguaçu) — 60.000 (AR)",
            "Yup Star (Foz do Iguaçu) — 50.000 (AR)",
            "Represa Itaipú (Paraguay) — 120.000 (AR)",
            "Rodoviaria (Foz do Iguaçu) — 50.000 (AR)",
            "Blue Park (Foz do Iguaçu) — 60.000 (AR)",
            "Cabecera de la amistad (Foz do Iguaçu) — 60.000 (AR)",
            "Aeropuerto Paraguayo (Ciudad del Este) — 120.000 (AR)"
        ],
        paquete_turistico: [
            "Pack turismo: Cataratas brasileras + Parque das Aves + AquaFoz (Foz do Iguaçu) → Hotel — 90.000 (AR)",
            "Pack turismo: Cena show Rafain (Foz do Iguaçu) → Hotel — 60.000 (AR)",
            "Pack turismo: Salto Mbocay + Salto Del Turista (Pto. Iguazú) → Hotel — 35.000 (AR)",
            "Pack turismo: Represa Itaipú + Templo Budista o Mezquita Islámica  (Foz do Iguaçu) — 120.000 (AR)",
            "Pack compras: Compras en Foz do Iguaçu en Oulet + Shopping Pladium — 60.000 (AR)",
            "Pack compras: Compras en Ciudad del Este  — 120.000 (AR)",
            "Pack compras y turismo: Compras en Ciudad del Este + Salto del Monday — 180.000 (AR)",
            "Pack compras y turismo: Marco de las Tres Fronteras + Yup Star — 60.000 (AR)"

        ]
    };

    // ==================== ESTADOS DEL CHATBOT ====================
    let errorCount = 0;
    const MAX_ERRORS = 2;
    let isTyping = false;
    let hasShownWelcome = false;
    let conversationContext = {
        lastTopic: null,
        userLanguage: 'es'
    };

    class CompoundQuestionDetector {
        constructor() {
            this.separatorPatterns = {
                'es': [
                    /\s+y\s+|\s+o\s+|\s+también\s+|\s+además\s+|\s+por\s+otro\s+lado\s+/i,
                    /\s*,\s*|\s*;\s*|\s*\.\s+/
                ],
                'en': [
                    /\s+and\s+|\s+or\s+|\s+also\s+|\s+additionally\s+|\s+plus\s+/i,
                    /\s*,\s*|\s*;\s*|\s*\.\s+/
                ],
                'pt': [
                    /\s+e\s+|\s+ou\s+|\s+também\s+|\s+além\s+disso\s+|\s+mais\s+/i,
                    /\s*,\s*|\s*;\s*|\s*\.\s+/
                ]
            };

            this.compoundIndicators = {
                'es': [
                    /(?:quiero|necesito|dime|información|sobre)\s+.+\s+(?:y|además|también)\s+.+/i,
                    /(?:precio|cuánto|cuesta)\s+.+\s+(?:y|también)\s+.+/i,
                    /(?:reserva|reservar)\s+.+\s+(?:y|además)\s+.+/i,
                    /(?:hola|buenas)\s*.+\s+(?:y|además)\s+.+/i,
                    /(?:hola|buenas)\s*.+\s+(?:quiero|necesito|deseo)\s+.+/i,
                    /(?:que tal|como estas)\s*.+\s+(?:quiero|necesito)\s+.+/i,
                    /(?:hola|buenas)[^]*?(servicios|precios|reservas|vehículos|contacto)/i,
                    /(?:que tal|como estas)[^]*?(servicios|precios|reservas|vehículos|contacto)/i
                ],
                'en': [
                    /(?:i want|i need|tell me|information|about)\s+.+\s+(?:and|also|additionally)\s+.+/i,
                    /(?:price|how much|cost)\s+.+\s+(?:and|also)\s+.+/i,
                    /(?:reservation|book)\s+.+\s+(?:and|also)\s+.+/i,
                    /(?:hello|hi)\s*.+\s+(?:and|also)\s+.+/i,
                    /(?:hello|hi)\s*.+\s+(?:i want|i need)\s+.+/i,
                    /(?:how are you|how's it going)\s*.+\s+(?:i want|i need)\s+.+/i
                ],
                'pt': [
                    /(?:quero|preciso|diga|informação|sobre)\s+.+\s+(?:e|também|além)\s+.+/i,
                    /(?:preço|quanto|custa)\s+.+\s+(?:e|tambiém)\s+.+/i,
                    /(?:reserva|reservar)\s+.+\s+(?:e|além)\s+.+/i,
                    /(?:olá|oi)\s*.+\s+(?:e|também)\s+.+/i,
                    /(?:olá|oi)\s*.+\s+(?:quero|preciso)\s+.+/i,
                    /(?:como vai|tudo bem)\s*.+\s+(?:quero|preciso)\s+.+/i
                ]
            };
        }

        normalize(message) {
            return message.toLowerCase()
                .normalize('NFD')
                .replace(/[\u0300-\u036f]/g, '')
                .replace(/[^\w\s?¿!¡àáâãçèéêìíîòóôõùúû]/g, '')
                .replace(/[^\w\s?¿!¡]/g, '');
        }

        isCompoundQuestion(message, language) {
            const normalizedMsg = this.normalize(message);
            const indicators = this.compoundIndicators[language] || this.compoundIndicators['es'];

            // Verificar patrones de preguntas compuestas
            return indicators.some(pattern => pattern.test(normalizedMsg));
        }

        splitCompoundQuestion(message, language) {
            const normalizedMsg = this.normalize(message);
            let parts = [message];

            // PRIMERO: Intentar dividir por cambio de contexto (saludo + consulta)
            const contextualParts = this.splitByContext(message, language);
            if (contextualParts && contextualParts.length > 1) {
                return contextualParts;
            }

            // SEGUNDO: Intentar dividir usando separadores tradicionales
            const separators = this.separatorPatterns[language] || this.separatorPatterns['es'];
            for (const separator of separators) {
                const newParts = [];
                let hasSplit = false;

                for (const part of parts) {
                    if (part.includes(',') || part.includes(' y ') || part.includes(' and ') || part.includes(' e ')) {
                        const splitParts = part.split(separator).filter(p => p.trim().length > 0);
                        if (splitParts.length > 1) {
                            newParts.push(...splitParts);
                            hasSplit = true;
                        } else {
                            newParts.push(part);
                        }
                    } else {
                        newParts.push(part);
                    }
                }

                if (hasSplit) {
                    parts = newParts.map(p => p.trim()).filter(p => p.length > 0);
                }
            }

            // Filtrar partes que sean muy cortas o solo conectores
            const filteredParts = parts.filter(part => {
                const cleanPart = part.replace(/[^a-zA-ZáéíóúñÁÉÍÓÚÑ]/g, '').trim();
                return cleanPart.length > 3 &&
                    !['y', 'and', 'e', 'o', 'or', 'ou', 'también', 'also', 'também'].includes(cleanPart.toLowerCase());
            });

            return filteredParts.length > 1 ? filteredParts : null;
        }

        splitByContext(message, language) {
            const normalizedMsg = this.normalize(message);
            const parts = [];

            // Patrones para dividir por cambio de contexto (saludo + consulta)
            const contextPatterns = {
                'es': [
                    /(hola|buenas|que tal|como estas)[^]*?(quiero|necesito|deseo|sobre|información|servicios|precios|reservas)/i,
                    /(hola|buenas)[^,]*?,[^]*?(quiero|necesito|deseo|sobre|información|servicios|precios|reservas)/i
                ],
                'en': [
                    /(hello|hi|how are you)[^]*?(i want|i need|about|information|services|prices|reservations)/i,
                    /(hello|hi)[^,]*?,[^]*?(i want|i need|about|information|services|prices|reservations)/i
                ],
                'pt': [
                    /(olá|oi|como vai|tudo bem)[^]*?(quero|preciso|sobre|informação|serviços|preços|reservas)/i,
                    /(olá|oi)[^,]*?,[^]*?(quero|preciso|sobre|informação|serviços|preços|reservas)/i
                ]
            };

            const patterns = contextPatterns[language] || contextPatterns['es'];

            for (const pattern of patterns) {
                const match = normalizedMsg.match(pattern);
                if (match) {
                    console.log('✅ Patrón de contexto encontrado:', match[0]);

                    // Encontrar la posición donde cambia el contexto
                    const greetingKeywords = {
                        'es': ['hola', 'buenas', 'que tal', 'como estas'],
                        'en': ['hello', 'hi', 'how are you'],
                        'pt': ['olá', 'oi', 'como vai', 'tudo bem']
                    };

                    const queryKeywords = {
                        'es': ['quiero', 'necesito', 'deseo', 'sobre', 'información', 'servicios', 'precios', 'reservas'],
                        'en': ['i want', 'i need', 'about', 'information', 'services', 'prices', 'reservations'],
                        'pt': ['quero', 'preciso', 'sobre', 'informação', 'serviços', 'preços', 'reservas']
                    };

                    const greetings = greetingKeywords[language] || greetingKeywords['es'];
                    const queries = queryKeywords[language] || queryKeywords['es'];

                    // Buscar la posición del primer keyword de consulta después del saludo
                    let queryStart = -1;
                    let queryKeyword = '';

                    for (const qKeyword of queries) {
                        const pos = normalizedMsg.indexOf(qKeyword);
                        if (pos > 0 && (queryStart === -1 || pos < queryStart)) {
                            queryStart = pos;
                            queryKeyword = qKeyword;
                        }
                    }

                    if (queryStart > 0) {
                        const greetingPart = message.substring(0, queryStart).trim();
                        const queryPart = message.substring(queryStart).trim();

                        if (greetingPart && queryPart) {
                            console.log('✅ Dividido por contexto:', { greetingPart, queryPart });
                            return [greetingPart, queryPart];
                        }
                    }
                }
            }

            return null;
        }

        detectQuestionTypes(parts, language) {
            const questionTypes = [];
            const greetingDetector = new GreetingDetector();
            const queryDetector = new QueryDetector();
            const travelDetector = new TravelDetector();
            const touristPlaceDetector = new TouristPlaceDetector();

            for (const part of parts) {
                let type = 'unknown';

                // Detectar tipo de cada parte
                if (greetingDetector.isGreeting(part, language)) {
                    type = 'greeting';
                } else if (touristPlaceDetector.isPlaceQuery(part, language)) {
                    type = 'place';
                } else if (travelDetector.isTravelQuery(part, language)) {
                    type = 'travel';
                } else {
                    const queryType = queryDetector.detectQueryType(part, language) ||
                        queryDetector.detectQuickQuery(part, language);
                    type = queryType || 'general';
                }

                questionTypes.push({
                    text: part,
                    type: type
                });
            }

            return questionTypes;
        }

        getCompoundResponse(questionTypes, language) {
            const responses = {
                'es': {
                    greeting_plus: "¡Hola! 😊 Veo que tienes varias consultas. Te ayudo con cada una:",
                    multiple_questions: "Perfecto, tienes varias preguntas. Te respondo cada una por separado:",
                    combined_response: "Entiendo que necesitas información sobre varios temas. Te ayudo:"
                },
                'en': {
                    greeting_plus: "Hello! 😊 I see you have multiple questions. Let me help you with each one:",
                    multiple_questions: "Great, you have several questions. Let me answer each one separately:",
                    combined_response: "I understand you need information about multiple topics. Let me help you:"
                },
                'pt': {
                    greeting_plus: "Olá! 😊 Vejo que você tem várias perguntas. Deixe-me ajudar com cada uma:",
                    multiple_questions: "Perfeito, você tem várias perguntas. Vou responder cada uma separadamente:",
                    combined_response: "Entendo que você precisa de informações sobre vários tópicos. Deixe-me ajudar:"
                }
            };

            const langResponses = responses[language] || responses['es'];

            // Determinar el tipo de respuesta compuesta
            let intro = langResponses.combined_response;
            if (questionTypes.some(qt => qt.type === 'greeting')) {
                intro = langResponses.greeting_plus;
            } else if (questionTypes.length > 1) {
                intro = langResponses.multiple_questions;
            }

            return {
                intro: intro,
                parts: questionTypes
            };
        }
    }

    // ==================== DETECTOR DE LUGARES TURÍSTICOS MEJORADO ====================
    class TouristPlaceDetector {
        constructor() {
            this.placesInfo = {
                // Lugares nacionales (argentinos) - CAMBIADO: provincial → nacional
                'cataratas argentinas': {
                    matches: ['cataratas argentinas', 'cataratas iguazu argentinas', 'cataratas del lado argentino', 'iguazu argentinas'],
                    info: "Cataratas argentinas (Pto. Iguazú) → Hotel — 50.000 (AR)",
                    description: "Las majestuosas Cataratas del Iguazú del lado argentino, una de las 7 Maravillas Naturales del Mundo. Incluye recorrido por pasarelas y miradores."
                },
                'ruinas san ignacio': {
                    matches: ['ruinas san ignacio', 'ruinas jesuíticas', 'misiones jesuíticas', 'san ignacio mini'],
                    info: "Ruinas San Ignacio (San Ignacio) → Hotel — 380.000 (AR)",
                    description: "Ruinas Jesuíticas de San Ignacio Miní, patrimonio histórico de la humanidad con arquitectura del siglo XVII."
                },
                'duty free': {
                    matches: ['duty free', 'free shop', 'tienda libre de impuestos'],
                    info: "Duty Free (Pto. Iguazú) → Hotel — GRATIS",
                    description: "Compras en tienda libre de impuestos con productos internacionales a precios especiales."
                },
                // GÜIRA OGA MEJORADO CON MÁS PATRONES
                'güira oga': {
                    matches: [
                        'güira oga',
                        'guira oga',
                        'guiraoga',
                        'guiraoga',
                        'parque güira oga',
                        'parque guira oga',
                        'centro güira oga',
                        'centro guira oga',
                        'aves güira oga',
                        'aves guira oga',
                        'parque de aves',
                        'aves nativas',
                        'centro de aves',
                        'bird park',
                        'parque aves',
                        'guira',
                        'oga'
                    ],
                    info: "Güira Oga (Pto. Iguazú) → Hotel — 15.000 (AR)",
                    description: "Centro de rescate y recuperación de aves nativas de la selva misionera. Un espacio dedicado a la conservación de la avifauna regional con visitas guiadas educativas."
                },
                'minas de wanda': {
                    matches: ['minas de wanda', 'mina wanda', 'piedras semipreciosas', 'wanda minas'],
                    info: "Minas de Wanda (Wanda) → Hotel — 70.000 (AR)",
                    description: "Minas de piedras semipreciosas donde podrás ver ágatas, amatistas y cuarzos en su estado natural."
                },
                // SALTOS DEL MOCONÁ MEJORADO CON MÁS PATRONES
                'saltos del moconá': {
                    matches: [
                        'saltos del moconá',
                        'saltos del mocona',
                        'moconá',
                        'mocona',
                        'saltos moconá',
                        'saltos mocona',
                        'cataratas longitudinales',
                        'cataratas moconá',
                        'cataratas mocona',
                        'mocona saltos',
                        'moconá saltos'
                    ],
                    info: "Saltos del Moconá (El Soberbio) → Hotel — 450.000 (AR)",
                    description: "Únicas cataratas longitudinales del mundo, donde el agua corre paralela al cauce del río. Un espectáculo natural único en la provincia de Misiones."
                },
                'hito tres fronteras': {
                    matches: ['hito tres fronteras', 'tres fronteras', 'hito 3 fronteras', 'mirador tres fronteras'],
                    info: "Hito Tres Fronteras (Pto. Iguazú) → Hotel — 15.000 (AR)",
                    description: "Punto de encuentro de Argentina, Brasil y Paraguay, con miradores panorámicos y espectáculos nocturnos."
                },
                'salto encantado': {
                    matches: ['salto encantado', 'parque salto encantado', 'encantado misiones'],
                    info: "Salto Encantado (Aristóbulo del Valle) → Hotel — 450.000 (AR)",
                    description: "Parque provincial con saltos de agua en medio de la selva misionera, ideal para trekking y avistaje de aves."
                },
                'gruta india': {
                    matches: ['gruta india', 'cueva del yaguareté', 'gruta india garuhapé'],
                    info: "Gruta India + Cueva del Yaguareté (Garuhapé) → Hotel — 350.000 (AR)",
                    description: "Sitio arqueológico con pinturas rupestres y formaciones naturales en la roca."
                },
                'salto mbocay': {
                    matches: ['salto mbocay', 'mbocay', 'salto del mbocay'],
                    info: "Salto Mbocay (Pto. Iguazú) → Hotel — 35.000 (AR)",
                    description: "Hermoso salto de agua en medio de la selva, menos concurrido que las cataratas principales."
                },
                'salto del turista': {
                    matches: ['salto del turista', 'salto turista'],
                    info: "Salto Del Turista (Pto. Iguazú) → Hotel — 35.000 (AR)",
                    description: "Mirador natural con vista panorámica de saltos menores en la selva misionera."
                },

                // Lugares internacionales
                'cataratas brasileras': {
                    matches: ['cataratas brasileras', 'cataratas brasil', 'cataratas do iguacu', 'cataratas lado brasileño', 'foz do iguacu'],
                    info: "Cataratas brasileras (Foz do Iguaçu) → Hotel — 90.000 (AR)",
                    description: "Vista panorámica de las cataratas desde el lado brasileño, con miradores espectaculares."
                },
                'parque das aves': {
                    matches: ['parque das aves', 'parque de aves foz', 'aves brasil'],
                    info: "Parque das Aves (Foz do Iguaçu) — 90.000 (AR)",
                    description: "Parque temático con más de 1.300 aves de 150 especies diferentes en recintos amplios."
                },
                'yup star': {
                    matches: ['yup star', 'yup', 'parque yup star'],
                    info: "Yup Star (Foz do Iguaçu) — 50.000 (AR)",
                    description: "Parque de diversiones con juegos mecánicos y atracciones para toda la familia."
                },
                'represa itaipú': {
                    matches: ['represa itaipú', 'itaipú', 'presa itaipú', 'hidroeléctrica itaipú'],
                    info: "Represa Itaipú (Paraguay) — 120.000 (AR)",
                    description: "Una de las mayores represas hidroeléctricas del mundo, con visitas guiadas técnicas."
                },
                'blue park': {
                    matches: ['blue park', 'parque acuático blue', 'blue park foz'],
                    info: "Blue Park (Foz do Iguaçu) — 60.000 (AR)",
                    description: "Parque acuático con piscinas de olas, toboganes y atracciones acuáticas."
                },
                'cabecera de la amistad': {
                    matches: ['cabecera de la amistad', 'puente de la amistad', 'amistad brasil paraguay'],
                    info: "Cabecera de la amistad (Foz do Iguaçu) — 60.000 (AR)",
                    description: "Puente internacional que conecta Brasil con Paraguay, con mirador panorámico."
                }
            };

            // Patrones para búsquedas parciales
            this.partialPatterns = {
                'es': [
                    /\b(quiero saber|información sobre|precio de|cuánto cuesta|dime sobre|hablame de|me interesa|quiero ir a|visitar|conocer)\s+(.+)/i,
                    /\b(cataratas|ruinas|duty free|güira|guira|minas|moconá|mocona|hito|salto|gruta|parque|represa|yup|blue)\s+(.+)/i
                ],
                'en': [
                    /\b(i want to know|information about|price of|how much is|tell me about|i'm interested in|i want to go to|visit|see)\s+(.+)/i,
                    /\b(waterfalls|ruins|duty free|bird park|mines|dam|park|bridge)\s+(.+)/i
                ],
                'pt': [
                    /\b(quero saber|informações sobre|preço de|quanto custa|fale sobre|estou interessado|quero ir para|visitar|conhecer)\s+(.+)/i,
                    /\b(cataratas|ruínas|duty free|parque|minas|represa|ponte)\s+(.+)/i
                ]
            };
        }

        normalize(message) {
            return message.toLowerCase()
                .normalize('NFD')
                .replace(/[\u0300-\u036f]/g, '')
                .replace(/[^\w\s]/g, ' ')
                .replace(/\s+/g, ' ')
                .trim();
        }

        extractPlaceName(message, language) {
            const normalizedMsg = this.normalize(message);

            console.log('🔍 Buscando lugar en mensaje:', normalizedMsg); // DEBUG

            // Búsqueda específica para Güira Oga primero
            if (normalizedMsg.includes('guira') || normalizedMsg.includes('oga')) {
                console.log('✅ Detectado posible Güira Oga'); // DEBUG
                // Verificar si es específicamente Güira Oga
                const guiraPatterns = ['guira oga', 'guiraoga', 'parque guira', 'aves guira', 'centro guira'];
                for (const pattern of guiraPatterns) {
                    if (normalizedMsg.includes(pattern)) {
                        console.log('✅ Confirmado: Güira Oga'); // DEBUG
                        return 'güira oga';
                    }
                }

                // Si solo contiene "guira" o "oga", sugerir Güira Oga
                if ((normalizedMsg.includes('guira') && !normalizedMsg.includes('minas')) ||
                    (normalizedMsg.includes('oga') && !normalizedMsg.includes('yoga'))) {
                    console.log('✅ Sugiriendo Güira Oga por palabra clave'); // DEBUG
                    return 'güira oga';
                }
            }

            // Búsqueda específica para Saltos del Moconá
            if (normalizedMsg.includes('mocona') || normalizedMsg.includes('moconá')) {
                console.log('✅ Detectado posible Saltos del Moconá'); // DEBUG
                // Verificar si es específicamente Moconá
                const moconaPatterns = ['saltos del mocona', 'saltos mocona', 'mocona', 'moconá', 'cataratas mocona'];
                for (const pattern of moconaPatterns) {
                    if (normalizedMsg.includes(pattern)) {
                        console.log('✅ Confirmado: Saltos del Moconá'); // DEBUG
                        return 'saltos del moconá';
                    }
                }

                // Si contiene "mocona" o "moconá", sugerir Saltos del Moconá
                if (normalizedMsg.includes('mocona') || normalizedMsg.includes('moconá')) {
                    console.log('✅ Sugiriendo Saltos del Moconá por palabra clave'); // DEBUG
                    return 'saltos del moconá';
                }
            }

            // Buscar coincidencias exactas primero
            for (const [placeName, placeData] of Object.entries(this.placesInfo)) {
                for (const match of placeData.matches) {
                    const normalizedMatch = this.normalize(match);
                    if (normalizedMsg.includes(normalizedMatch)) {
                        console.log('✅ Lugar encontrado:', placeName); // DEBUG
                        return placeName;
                    }
                }
            }

            // Buscar coincidencias parciales usando patrones
            const patterns = this.partialPatterns[language] || this.partialPatterns['es'];
            for (const pattern of patterns) {
                const match = normalizedMsg.match(pattern);
                if (match && match[2]) {
                    const possiblePlace = this.normalize(match[2]);
                    console.log('🔍 Buscando coincidencia parcial:', possiblePlace); // DEBUG

                    // Buscar el lugar más similar
                    for (const [placeName, placeData] of Object.entries(this.placesInfo)) {
                        for (const placeMatch of placeData.matches) {
                            const normalizedPlaceMatch = this.normalize(placeMatch);
                            if (normalizedPlaceMatch.includes(possiblePlace) ||
                                possiblePlace.includes(normalizedPlaceMatch)) {
                                console.log('✅ Coincidencia parcial encontrada:', placeName); // DEBUG
                                return placeName;
                            }
                        }
                    }
                }
            }

            console.log('❌ No se encontró lugar específico'); // DEBUG
            return null;
        }

        getPlaceInfo(placeName) {
            return this.placesInfo[placeName] || null;
        }

        getSimilarPlaces(partialName) {
            const normalizedPartial = this.normalize(partialName);
            const similar = [];

            for (const [placeName, placeData] of Object.entries(this.placesInfo)) {
                for (const match of placeData.matches) {
                    if (this.normalize(match).includes(normalizedPartial) ||
                        normalizedPartial.includes(this.normalize(match))) {
                        similar.push(placeName);
                        break;
                    }
                }
            }

            return similar;
        }

        getPlaceResponse(placeName, language) {
            const placeInfo = this.getPlaceInfo(placeName);
            if (!placeInfo) return null;

            const responses = {
                'es': `🏞️ **${placeName.charAt(0).toUpperCase() + placeName.slice(1)}**\n\n${placeInfo.info}\n\n📝 *${placeInfo.description}*`,
                'en': `🏞️ **${placeName.charAt(0).toUpperCase() + placeName.slice(1)}**\n\n${placeInfo.info}\n\n📝 *${placeInfo.description}*`,
                'pt': `🏞️ **${placeName.charAt(0).toUpperCase() + placeName.slice(1)}**\n\n${placeInfo.info}\n\n📝 *${placeInfo.description}*`
            };

            return responses[language] || responses['es'];
        }

        getMultiplePlacesResponse(placeNames, language) {
            let response = `🔍 **Encontré varias opciones relacionadas:**\n\n`;

            placeNames.forEach(placeName => {
                const placeInfo = this.getPlaceInfo(placeName);
                if (placeInfo) {
                    response += `• ${placeInfo.info}\n`;
                }
            });

            response += `\n💡 *Por favor, especifica cuál de estos lugares te interesa para darte más información detallada.*`;

            return response;
        }

        isPlaceQuery(message, language) {
            const normalizedMsg = this.normalize(message);

            // Patrones que indican consulta de lugar turístico
            const queryPatterns = {
                'es': [
                    /\b(cataratas|ruinas|duty free|güira|guira|minas|moconá|mocona|hito|salto|gruta|parque|represa|yup|blue)\b/i,
                    /\b(quiero saber|información sobre|precio de|cuánto cuesta|dime sobre|me interesa|quiero ir a)\b/i
                ],
                'en': [
                    /\b(waterfalls|ruins|duty free|bird park|mines|dam|park|bridge)\b/i,
                    /\b(i want to know|information about|price of|how much is|tell me about|i'm interested in|i want to go to)\b/i
                ],
                'pt': [
                    /\b(cataratas|ruínas|duty free|parque|minas|represa|ponte)\b/i,
                    /\b(quero saber|informações sobre|preço de|quanto custa|fale sobre|estou interessado|quero ir para)\b/i
                ]
            };

            const patterns = queryPatterns[language] || queryPatterns['es'];
            return patterns.some(pattern => pattern.test(normalizedMsg));
        }
    }

    // ==================== DETECTOR DE TURISMO Y VIAJES ====================
    class TravelDetector {
        constructor() {
            this.travelPatterns = {
                'es': [
                    /\b(turismo|viajes|viaje|travels|travel|tour|excursiones|excursión|paseos|paseo|destinos|destino|lugares|atracciones|actividades|que hacer|qué visitar|donde ir|dónde ir|circuitos|circuito|rutas|ruta)\b/i,
                    /\b(viajes disponibles|tours disponibles|excursiones disponibles|paseos disponibles|destinos turisticos|destinos turísticos|lugares turisticos|lugares turísticos|atracciones turisticas|atracciones turísticas)\b/i,
                    /\b(que puedo visitar|qué puedo visitar|lugares para conocer|sitios para visitar|puntos turisticos|puntos turísticos|zonas turisticas|zonas turísticas)\b/i
                ],
                'en': [
                    /\b(tourism|travels|travel|tours|tour|excursions|excursion|trips|trip|destinations|destination|places|attractions|activities|things to do|what to visit|where to go|circuits|circuit|routes|route)\b/i,
                    /\b(available travels|available tours|available excursions|available trips|tourist destinations|tourist places|tourist attractions|tourist spots)\b/i,
                    /\b(what can i visit|places to visit|sites to see|tourist points|tourist areas|tourist zones)\b/i
                ],
                'pt': [
                    /\b(turismo|viagens|viagem|travels|travel|passeios|passeio|excursões|excursão|destinos|destino|lugares|atrações|atividades|o que fazer|o que visitar|onde ir|circuitos|circuito|rotas|rota)\b/i,
                    /\b(viagens disponíveis|passeios disponíveis|excursões disponíveis|destinos turísticos|lugares turísticos|atrações turísticas|pontos turísticos)\b/i,
                    /\b(o que posso visitar|lugares para conhecer|sítios para visitar|pontos turísticos|zonas turísticas|áreas turísticas)\b/i
                ]
            };
        }

        normalize(message) {
            return message.toLowerCase()
                .normalize('NFD')
                .replace(/[\u0300-\u036f]/g, '')
                .replace(/[^\w\s?¿!¡àáâãçèéêìíîòóôõùúû]/g, '')
                .replace(/[^\w\s?¿!¡]/g, '');
        }

        isTravelQuery(message, language) {
            const msg = this.normalize(message);
            const patterns = this.travelPatterns[language] || this.travelPatterns['es'];
            return patterns.some(p => p.test(msg));
        }

        getTravelResponse(language) {
            // Obtener traducciones de paquetes turísticos
            const packTranslations = servicesInfo.paquete_turistico.map(key => {
                return window.translationManager ? window.translationManager.translate(key) : key;
            });

            const responses = {
                'es': `🏞️ **Servicios de Turismo y Viajes Disponibles**\n\nAquí tienes todos nuestros destinos y servicios turísticos:\n\n**🌍 Servicios Nacionales:**\n${servicesInfo.nacional.map(s => `• ${s}`).join('\n')}\n\n**🌎 Servicios Internacionales:**\n${servicesInfo.international.map(s => `• ${s}`).join('\n')}\n\n**🎯 Paquetes Turísticos:**\n${packTranslations.map(s => `• ${s}`).join('\n')}\n\n💡 *Todos los precios están en pesos argentinos (AR) e incluyen nuestro servicio de calidad.*\n\n¿Te interesa algún destino en particular?`,
                'en': `🏞️ **Tourism Services and Available Travels**\n\nHere are all our destinations and tourist services:\n\n**🌍 National Services:**\n${servicesInfo.nacional.map(s => `• ${s}`).join('\n')}\n\n**🌎 International Services:**\n${servicesInfo.international.map(s => `• ${s}`).join('\n')}\n\n**🎯 Tourist Packages:**\n${packTranslations.map(s => `• ${s}`).join('\n')}\n\n💡 *All prices are in Argentine pesos (AR) and include our quality service.*\n\nAre you interested in any particular destination?`,
                'pt': `🏞️ **Serviços de Turismo e Viagens Disponíveis**\n\nAqui estão todos os nossos destinos e serviços turísticos:\n\n**🌍 Serviços Nacionais:**\n${servicesInfo.nacional.map(s => `• ${s}`).join('\n')}\n\n**🌎 Serviços Internacionais:**\n${servicesInfo.international.map(s => `• ${s}`).join('\n')}\n\n**🎯 Pacotes Turísticos:**\n${packTranslations.map(s => `• ${s}`).join('\n')}\n\n💡 *Todos os preços estão em pesos argentinos (AR) e incluem nosso serviço de qualidade.*\n\nEstá interessado em algum destino em particular?`
            };
            return responses[language] || responses['es'];
        }
    }

    // ==================== DETECTOR DE SALUDOS MEJORADO ====================
    class GreetingDetector {
        constructor() {
            // --- Saludos simples ---
            this.simpleGreetings = {
                'es': [
                    /\b(hola|buenas|hey|buen dia|buenos dias|buenas tardes|buenas noches|holis|holiwis|hola\?|hola\!)\b/i
                ],
                'en': [
                    /\b(hello|hi|hey|good morning|good afternoon|good evening|hi\?|hi\!|hello\?|hello\!)\b/i
                ],
                'pt': [
                    /\b(olá|ola|oi|boa tarde|boa noite|bom dia|opa|e aí|olá\?|ola\?|oi\?|olá\!|ola\!|oi\!)\b/i
                ]
            };

            // --- Preguntas de bienestar ---
            this.wellbeingPatterns = {
                'es': [
                    /\b(como estas|como te va|que tal|todo bien|como estuvo tu dia|que tal tu dia|vos como estas|como andas|como va|estas bien|seguro estas bien|bien\?|estas\?)\b/i
                ],
                'en': [
                    /\b(how are you|how's it going|how are u|how do you do|how was your day|how's your day|are you ok|you ok|you good|how you doing|how are you\?)\b/i
                ],
                'pt': [
                    /\b(como vai|tudo bem|tudo bom|como foi seu dia|como voce esta|como está|esta bem|tudo bem\?|como vai\?|como você está)\b/i
                ]
            };

            // --- Expresiones de bienestar personal ---
            this.wellbeingExpressions = {
                'es': [
                    /\b(me encuentro bien|estoy bien|todo bien|muy bien|excelente|genial|perfecto|de maravilla|fenomenal)\b/i
                ],
                'en': [
                    /\b(i'm good|i am good|i'm fine|i am fine|i'm ok|i am ok|i'm great|i am great|i'm well|i am well)\b/i
                ],
                'pt': [
                    /\b(estou bem|me siento bem|tudo otimo|tudo ótimo|muito bem|excelente|perfeito|maravilhoso|estou ótimo)\b/i
                ]
            };
        }

        normalize(message) {
            return message.toLowerCase()
                .normalize('NFD')
                .replace(/[\u0300-\u036f]/g, '')
                .replace(/[^\w\s?¿!¡àáâãçèéêìíîòóôõùúû]/g, '')
                .replace(/[^\w\s?¿!¡]/g, '');
        }

        // --- Detecta si es saludo simple ---
        isSimpleGreeting(message, language) {
            const msg = this.normalize(message);
            const patterns = this.simpleGreetings[language] || this.simpleGreetings['es'];
            return patterns.some(p => p.test(msg));
        }

        // --- Detecta si es pregunta de bienestar ---
        isWellbeingGreeting(message, language) {
            const msg = this.normalize(message);
            const patterns = this.wellbeingPatterns[language] || this.wellbeingPatterns['es'];
            return patterns.some(p => p.test(msg));
        }

        // --- Detecta si es expresión de bienestar personal ---
        isWellbeingExpression(message, language) {
            const msg = this.normalize(message);
            const patterns = this.wellbeingExpressions[language] || this.wellbeingExpressions['es'];
            return patterns.some(p => p.test(msg));
        }

        // --- Detecta si es cualquier tipo de saludo ---
        isGreeting(message, language = 'es') {
            return this.isSimpleGreeting(message, language) ||
                this.isWellbeingGreeting(message, language) ||
                this.isWellbeingExpression(message, language);
        }

        // --- Detecta idioma ---
        detectGreetingLanguage(message) {
            const msg = this.normalize(message);

            // Primero verificar portugués específicamente
            const ptPatterns = [
                ...this.simpleGreetings['pt'],
                ...this.wellbeingPatterns['pt'],
                ...this.wellbeingExpressions['pt']
            ];

            for (const pattern of ptPatterns) {
                if (pattern.test(msg)) {
                    return 'pt';
                }
            }

            // Luego verificar otros idiomas
            for (const [lang, patterns] of Object.entries(this.simpleGreetings)) {
                if (lang !== 'pt' && patterns.some(p => p.test(msg))) return lang;
            }

            for (const [lang, patterns] of Object.entries(this.wellbeingPatterns)) {
                if (lang !== 'pt' && patterns.some(p => p.test(msg))) return lang;
            }

            for (const [lang, patterns] of Object.entries(this.wellbeingExpressions)) {
                if (lang !== 'pt' && patterns.some(p => p.test(msg))) return lang;
            }

            return 'es'; // por defecto
        }

        // --- Respuestas para saludos simples ---
        getSimpleGreetingResponse(language) {
            const responses = {
                'es': [
                    "¡Hola! 👋 ¿En qué puedo ayudarte hoy?",
                    "¡Hola! 😊 ¿Cómo puedo asistirte?",
                    "¡Hola! Soy TUQUI, ¿qué necesitas hoy?",
                    "¡Hola! 🌟 ¿En qué puedo ayudarte?"
                ],
                'en': [
                    "Hello! 👋 How can I help you today?",
                    "Hi! 😊 How can I assist you?",
                    "Hello! I'm TUQUI, how can I help you today?",
                    "Hi there! 🌟 What can I do for you?"
                ],
                'pt': [
                    "Olá! 👋 Como posso ajudá-lo hoje?",
                    "Oi! 😊 Como posso ajudar você?",
                    "Olá! Sou o TUQUI, como posso ajudar?",
                    "Oi! 🌟 Como posso ajudá-lo?"
                ]
            };
            const langResponses = responses[language] || responses['es'];
            return langResponses[Math.floor(Math.random() * langResponses.length)];
        }

        // --- Respuestas más humanas cuando preguntan '¿cómo estás?' ---
        getWellbeingResponse(language) {
            const responses = {
                'es': [
                    "¡Estoy muy bien, gracias por preguntar! 😊 ¿Y tú, en qué puedo ayudarte hoy?",
                    "¡Todo excelente por aquí! 🌟 ¿Cómo te puedo asistir?",
                    "¡Muy bien! Gracias por preguntar 🙌 ¿Qué necesitas hoy?",
                    "¡Perfecto! Me alegra que preguntes 😄 ¿En qué puedo ayudarte?"
                ],
                'en': [
                    "I'm doing great, thanks for asking! 😊 How can I help you today?",
                    "Everything's great here! 🌟 How can I assist you?",
                    "I'm very well! Thanks for asking 🙌 What can I do for you today?",
                    "I'm doing wonderful! Thanks for checking 😄 How can I help?"
                ],
                'pt': [
                    "Estou muito bem, obrigado por perguntar! 😊 Como posso ajudar você hoje?",
                    "Tudo ótimo por aqui! 🌟 Como posso ajudar?",
                    "Estou bem! Obrigado por perguntar 🙌 O que você precisa hoje?",
                    "Estou ótimo! Obrigado por perguntar 😄 Como posso ajudá-lo?"
                ]
            };
            const langResponses = responses[language] || responses['es'];
            return langResponses[Math.floor(Math.random() * langResponses.length)];
        }

        // --- Respuestas para expresiones de bienestar personal ---
        getWellbeingExpressionResponse(language) {
            const responses = {
                'es': [
                    "¡Me alegra saber que estás bien! 😊 ¿En qué puedo ayudarte hoy?",
                    "¡Qué bueno que estés bien! 🌟 ¿Cómo puedo asistirte?",
                    "¡Excelente! Me da gusto escuchar eso 🙌 ¿Qué necesitas?",
                    "¡Genial! 😄 ¿En qué puedo ayudarte hoy?"
                ],
                'en': [
                    "I'm glad to hear you're doing well! 😊 How can I help you today?",
                    "That's great to hear! 🌟 How can I assist you?",
                    "Wonderful! Glad to hear that 🙌 What can I do for you?",
                    "Awesome! 😄 How can I help you today?"
                ],
                'pt': [
                    "Fico feliz em saber que você está bem! 😊 Como posso ajudá-lo hoje?",
                    "Que bom que você está bem! 🌟 Como posso ajudar?",
                    "Excelente! Fico feliz em ouvir isso 🙌 O que você precisa?",
                    "Maravilhoso! 😄 Como posso ajudá-lo hoje?"
                ]
            };
            const langResponses = responses[language] || responses['es'];
            return langResponses[Math.floor(Math.random() * langResponses.length)];
        }

        // --- Respuesta general para saludos ---
        getGreetingResponse(language, message = '') {
            const normalizedMsg = this.normalize(message);

            // Si es pregunta de bienestar
            if (this.isWellbeingGreeting(message, language)) {
                return this.getWellbeingResponse(language);
            }

            // Si es expresión de bienestar personal
            if (this.isWellbeingExpression(message, language)) {
                return this.getWellbeingExpressionResponse(language);
            }

            // Por defecto usar saludo simple
            return this.getSimpleGreetingResponse(language);
        }
    }

    // ==================== DETECTOR DE IDIOMA MEJORADO ====================
    class LanguageDetector {
        constructor() {
            this.userLanguage = this.getCurrentLanguage();
            this.greetingDetector = new GreetingDetector();
            this.travelDetector = new TravelDetector();
        }

        getCurrentLanguage() {
            if (window.translationManager) {
                return window.translationManager.currentLanguage;
            }
            return 'es';
        }

        syncWithMainLanguage() {
            this.userLanguage = this.getCurrentLanguage();
        }

        detectLanguageFromMessage(msg) {
            // Primero verificar si es un saludo para detectar el idioma
            const greetingLang = this.greetingDetector.detectGreetingLanguage(msg);
            if (greetingLang && greetingLang !== 'es') {
                return greetingLang;
            }

            // Si no es saludo o es español, usar el idioma del sistema
            return this.getCurrentLanguage();
        }

        getResponsesByLanguage() {
            const lang = this.userLanguage;

            // Obtener traducciones de paquetes turísticos
            const packTranslations = servicesInfo.paquete_turistico.map(key => {
                return window.translationManager ? window.translationManager.translate(key) : key;
            });

            if (lang === 'en') {
                return {
                    welcome: `Hello! 👋 I'm TUQUI, your assistant from D.W.B. Transfers.\n\nHow can I help you today?`,
                    greeting: (msg) => this.greetingDetector.getGreetingResponse('en', msg),
                    travel: this.travelDetector.getTravelResponse('en'),
                    services: `🌟 All Our Services (round trip):\n\n🏞️ National Services:\n${servicesInfo.nacional.map(s => `• ${s}`).join('\n')}\n\n🌎 International Services:\n${servicesInfo.international.map(s => `• ${s}`).join('\n')}\n\n🎯 Tourist Packages:\n${packTranslations.map(s => `• ${s}`).join('\n')}`,
                    vehicles: `🚗 Our Vehicles:\n\nWe have a Renault Logan 2022, a modern, safe and comfortable vehicle with capacity for up to 4 passengers plus their luggage.\nIdeal for family transfers, tourist trips; national and international.`,
                    contact: `📞 Direct Contact:\n\nFor inquiries, reservations or more information about our services, you can contact us directly through the following means:\n📞 WhatsApp: +54 9 3757 68 1414\n📧 Email: traslados.dwb.iguazu@gmail.com\n📍 Location: Puerto Iguazú, Misiones`,
                    groups: `👥 Groups:\n\nIf your group is larger, we can manage an additional vehicle or one with greater capacity so everyone travels comfortably and safely.\nWe have vehicles with sufficient space ranging from 4 to 50 passengers, we adapt to your needs to ensure efficient and hassle-free transfer.`,
                    prices: `💰 Our Prices:\n\nHere are all our services with their current prices in Argentine pesos (AR):\n\n🏞️ National Services:\n${servicesInfo.nacional.map(s => `• ${s}`).join('\n')}\n\n🌎 International Services:\n${servicesInfo.international.map(s => `• ${s}`).join('\n')}\n\n🎯 Tourist Packages:\n${packTranslations.map(s => `• ${s}`).join('\n')}\n\n💡 All prices are in Argentine pesos (AR) and include our quality service.`,
                    reservations: `📅 **Booking Process**\n\nTo make your reservation, follow these steps:\n\n1. **Contact us** on WhatsApp: 📞 +54 9 3757 68 1414\n2. **Provide** the following information:\n   • Service date\n   • Number of people\n   • Pickup location\n   • Desired destination\n   • Preferred schedule\n3. **We'll confirm** availability and prices\n4. **You'll receive** your booking confirmation\n\n💡 *We recommend booking at least 24 hours in advance, especially during high season.*\n\nWe'll be happy to help you with your booking! 🚗`,
                    goodbye: `Thank you for contacting us! For any consultation, we are at your disposal. Safe travels! 🚗`,
                    packages: `🎯 **Tourist Packages Available**\n\nHere are our special tourist packages:\n\n${packTranslations.map(s => `• ${s}`).join('\n')}\n\n💡 *All prices are in Argentine pesos (AR) and include our quality service.*\n\nWould you like more information about any of these packages?`,
                    confused: `I didn't quite understand. Could you try with other words? For example:\n• "We are 4 people"\n• "I want to go to Iguazu Falls"\n• "Price for Paraguay"\n• "Reservations"\n• "Tourist packages"`
                };
            }

            if (lang === 'pt') {
                return {
                    welcome: `Olá! 👋 Eu sou o TUQUI, seu assistente da D.W.B. Transferências.\n\nComo posso ajudá-lo hoje?`,
                    greeting: (msg) => this.greetingDetector.getGreetingResponse('pt', msg),
                    travel: this.travelDetector.getTravelResponse('pt'),
                    services: `🌟 Todos Os Nossos Serviços (ida e volta):\n\n🏞️ Serviços Nacionais:\n${servicesInfo.nacional.map(s => `• ${s}`).join('\n')}\n\n🌎 Servicios Internacionais:\n${servicesInfo.international.map(s => `• ${s}`).join('\n')}\n\n🎯 Pacotes Turísticos:\n${packTranslations.map(s => `• ${s}`).join('\n')}`,
                    vehicles: `🚗 Nossos Veículos:\n\nTemos um Renault Logan 2022, um veículo moderno, seguro e confortável, com capacidade para até 4 passageiros mais sua bagagem.\nIdeal para traslados familiares, viagens turísticas; nacional e internacional.`,
                    contact: `📞 Contato Direto:\n\nPara consultas, reservas ou mais informações sobre nossos serviços, você pode entrar em contato diretamente conosco através dos seguintes meios:\n📞 WhatsApp: +54 9 3757 68 1414\n📧 Email: traslados.dwb.iguazu@gmail.com\n📍 Localização: Puerto Iguazú, Misiones`,
                    groups: `👥 Grupos:\n\nSe seu grupo for maior, podemos gerenciar um veículo adicional ou um com maior capacidade para que todos viajem confortáveis e seguros.\nContamos com veículos com espaço suficiente que vão desde 4 até 50 passageiros, nos adaptamos às suas necessidades para garantir um traslado eficiente e sem complicações.`,
                    prices: `💰 Nossos Preços:\n\nAqui estão todos os nossos serviços com seus preços atuais em pesos argentinos (AR):\n\n🏞️ Serviços Nacionais:\n${servicesInfo.nacional.map(s => `• ${s}`).join('\n')}\n\n🌎 Serviços Internacionais:\n${servicesInfo.international.map(s => `• ${s}`).join('\n')}\n\n🎯 Pacotes Turísticos:\n${packTranslations.map(s => `• ${s}`).join('\n')}\n\n💡 Todos os preços estão em pesos argentinos (AR) e incluem nosso serviço de qualidade.`,
                    reservations: `📅 **Processo de Reservas**\n\nPara fazer sua reserva, siga estos passos:\n\n1. **Contate-nos** pelo WhatsApp: 📞 +54 9 3757 68 1414\n2. **Forneça** as seguintes informações:\n   • Data do serviço\n   • Número de pessoas\n   • Local de coleta\n   • Destino desejado\n   • Horário preferido\n3. **Confirmaremos** disponibilidade e preços\n4. **Você receberá** a confirmação da sua reserva\n\n💡 *Recomendamos reservar com pelo menos 24 horas de antecedência, especialmente na alta temporada.*\n\nFicaremos felizes em ajudá-lo com sua reserva! 🚗`,
                    goodbye: `Obrigado por entrar em contato! Para qualquer consulta, estamos à disposição. Boa viagem! 🚗`,
                    packages: `🎯 **Pacotes Turísticos Disponíveis**\n\nAqui estão nossos pacotes turísticos especiais:\n\n${packTranslations.map(s => `• ${s}`).join('\n')}\n\n💡 *Todos os preços estão em pesos argentinos (AR) e incluem nosso serviço de qualidade.*\n\nGostaria de mais informações sobre algum desses pacotes?`,
                    confused: `Não consegui entender completamente. Poderia tentar com outras palabras? Por exemplo:\n• "Somos 4 pessoas"\n• "Quero ir às Cataratas"\n• "Preço para Paraguai"\n• "Reservas"\n• "Pacotes turísticos"`
                };
            }

            // Español por defecto
            return {
                welcome: `¡Hola! 👋 Soy TUQUI, tu asistente de Traslados D.W.B.\n\n¿En qué puedo ayudarte hoy?`,
                greeting: (msg) => this.greetingDetector.getGreetingResponse('es', msg),
                travel: this.travelDetector.getTravelResponse('es'),
                services: `🌟 Todos Nuestros Servicios (ida y vuelta):\n\n🏞️ Servicios Nacionales:\n${servicesInfo.nacional.map(s => `• ${s}`).join('\n')}\n\n🌎 Servicios Internacionales:\n${servicesInfo.international.map(s => `• ${s}`).join('\n')}\n\n🎯 Paquetes Turísticos:\n${packTranslations.map(s => `• ${s}`).join('\n')}`,
                vehicles: `🚗 Nuestros Vehículos:\n\nContamos con un Renault Logan 2023, un vehículo moderno, seguro y cómodo, con capacidad para hasta 4 pasajeros más su equipaje.\nIdeal para traslados familiares, viajes turísticos; nacionales e internacionales.`,
                contact: `📞 Contacto Directo:\n\nPara consultas, reservas o más información sobre nuestros servicios, podes comunicarte directamente con nosotros a través de los siguientes medios:\n📞 WhatsApp: +54 9 3757 68 1414\n📧 Email: traslados.dwb.iguazu@gmail.com\n📍 Ubicación: Puerto Iguazú, Misiones`,
                groups: `👥 Grupos:\n\nSi su grupo es más numeroso, podemos gestionar un vehículo adicional o uno de mayor capacidad para que todos viajen cómodos y seguros.\nContamos con vehículos con espacio suficiente que van desde 4 hasta 50 pasajeros, nos adaptamos a tus necesidades para asegurar un traslado eficiente y sin complicaciones.`,
                prices: `💰 Nuestros Precios:\n\nAquí tienes todos nuestros servicios con sus precios actuales en pesos argentinos (AR):\n\n🏞️ Servicios Nacionales:\n${servicesInfo.nacional.map(s => `• ${s}`).join('\n')}\n\n🌎 Servicios Internacionales:\n${servicesInfo.international.map(s => `• ${s}`).join('\n')}\n\n🎯 Paquetes Turísticos:\n${packTranslations.map(s => `• ${s}`).join('\n')}\n\n💡 Todos los precios están en pesos argentinos (AR) e incluyen nuestro servicio de calidad.`,
                reservations: `📅 **Proceso de Reservas**\n\nPara realizar tu reserva, sigue estos pasos:\n\n1. **Contáctanos** por WhatsApp: 📞 +54 9 3757 68 1414\n2. **Proporciona** la siguiente información:\n   • Fecha del servicio\n   • Número de personas\n   • Lugar de recogida\n   • Destino deseado\n   • Horario preferido\n3. **Confirmaremos** disponibilidad y precios\n4. **Recibirás** la confirmación de tu reserva\n\n💡 *Recomendamos reservar con al menos 24 horas de anticipación, especialmente en temporada alta.*\n\n¡Estaremos encantados de ayudarte con tu reserva! 🚗`,
                goodbye: `¡Gracias por contactarnos! Por cualquier consulta, estamos a disposición. ¡Buen viaje! 🚗`,
                packages: `🎯 **Paquetes Turísticos Disponibles**\n\nAquí tienes nuestros paquetes turísticos especiales:\n\n${packTranslations.map(s => `• ${s}`).join('\n')}\n\n💡 *Todos los precios están en pesos argentinos (AR) e incluyen nuestro servicio de calidad.*\n\n¿Te gustaría más información sobre alguno de estos paquetes?`,
                confused: `Lo siento, no entiendo lo que quisiste decir. ¿Podrías intentar con otras palabras? Por ejemplo:\n• "Sobre grupos"\n• "Quiero saber los servicios"\n• "Reservas"\n• "Paquetes turísticos"`
            };
        }

        getResponse(category, message = '') {
            const responses = this.getResponsesByLanguage();
            const response = responses[category];

            if (typeof response === 'function') {
                return response(message);
            }

            return response || responses['confused'];
        }
    }

    // ==================== DETECTOR DE DESPEDIDAS ====================
    class FarewellDetector {
        constructor() {
            this.farewellPatterns = {
                'es': [
                    /\b(gracias|adios|adiós|chau|chao|hasta luego|hasta pronto|nos vemos|bye|ok gracias|perfecto gracias|genial gracias)\b/i,
                    /\b(muchas gracias|ok gracias|perfecto gracias|genial gracias|listo gracias|de acuerdo gracias)\b/i
                ],
                'en': [
                    /\b(thanks|thank you|bye|goodbye|see you|farewell|cheers|ok thanks|perfect thanks|great thanks)\b/i,
                    /\b(thank you very much|ok thanks|perfect thanks|great thanks|all right thanks|ok thank you)\b/i
                ],
                'pt': [
                    /\b(obrigado|obrigada|tchau|adeus|até logo|até breve|flw|valeu|ok obrigado|perfeito obrigado)\b/i,
                    /\b(muito obrigado|muito obrigada|ok obrigado|perfeito obrigado|ótimo obrigado|valeu obrigado)\b/i
                ]
            };
        }

        isFarewell(message, language) {
            const normalized = message.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
            const patterns = this.farewellPatterns[language] || this.farewellPatterns['es'];
            return patterns.some(pattern => pattern.test(normalized));
        }
    }

    // ==================== DETECTOR DE CONSULTAS RÁPIDAS MEJORADO ====================
    class QueryDetector {
        constructor() {
            this.queryPatterns = {
                'services': {
                    'es': ['servicios', 'todos los servicios', 'servicio', 'qué ofrecen', 'qué tienen', 'qué servicios'],
                    'en': ['services', 'all services', 'service', 'what do you offer', 'what do you have', 'what services'],
                    'pt': ['serviços', 'todos os serviços', 'serviço', 'o que oferecem', 'o que têm', 'que serviços']
                },
                'vehicles': {
                    'es': ['vehículos', 'vehículo', 'auto', 'coche', 'carro', 'qué auto tienen', 'qué carro'],
                    'en': ['vehicles', 'vehicle', 'car', 'auto', 'what car do you have', 'which car'],
                    'pt': ['veículos', 'veículo', 'carro', 'auto', 'que carro têm', 'qual carro']
                },
                'contact': {
                    'es': ['contacto', 'contacto directo', 'whatsapp', 'email', 'teléfono', 'número', 'contactar'],
                    'en': ['contact', 'direct contact', 'whatsapp', 'email', 'phone', 'number', 'get in touch'],
                    'pt': ['contato', 'contato direto', 'whatsapp', 'email', 'telefone', 'número', 'entrar em contato']
                },
                'groups': {
                    'es': ['grupos', 'grupo', 'varias personas', 'muchas personas', 'familia grande', 'somos muchos'],
                    'en': ['groups', 'group', 'several people', 'many people', 'large family', 'we are many'],
                    'pt': ['grupos', 'grupo', 'várias pessoas', 'muitas pessoas', 'família grande', 'somos muitos']
                },
                'prices': {
                    'es': ['precios', 'precio', 'cuánto cuesta', 'tarifas', 'valor', 'costo', 'cuánto sale', 'qué precio'],
                    'en': ['prices', 'price', 'how much', 'cost', 'rates', 'how much does it cost', 'what is the price'],
                    'pt': ['preços', 'preço', 'quanto custa', 'valores', 'custo', 'quanto sai', 'qual o preço']
                },
                'reservations': {
                    'es': [
                        'reservas', 'reserva', 'reservar', 'hacer reserva', 'quiero reservar', 'agendar', 'cita',
                        'como reservar', 'cómo reservar', 'realizar reserva', 'hacer una reserva', 'quiero hacer una reserva',
                        'necesito reservar', 'como realizar una reserva', 'cómo realizar una reserva', 'proceso de reserva'
                    ],
                    'en': [
                        'reservations', 'reservation', 'book', 'booking', 'make reservation', 'schedule', 'appointment',
                        'how to book', 'how to make a reservation', 'i want to book', 'i need to book', 'booking process'
                    ],
                    'pt': [
                        'reservas', 'reserva', 'reservar', 'fazer reserva', 'quero reservar', 'agendar', 'marcação',
                        'como reservar', 'fazer uma reserva', 'preciso reservar', 'processo de reserva'
                    ]
                },
                // NUEVO: Detector de paquetes turísticos
                'packages': {
                    'es': ['paquetes', 'paquete', 'packs', 'pack', 'paquetes turísticos', 'paquete turístico', 'ofertas', 'combos'],
                    'en': ['packages', 'package', 'packs', 'pack', 'tourist packages', 'tour package', 'offers', 'deals', 'combos'],
                    'pt': ['pacotes', 'pacote', 'packs', 'pack', 'pacotes turísticos', 'pacote turístico', 'ofertas', 'combos']
                }
            };
        }

        detectQueryType(message, language) {
            const normalized = message.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');

            // VERIFICACIÓN ESPECÍFICA PARA RESERVAS CON PATRONES REGULARES
            const reservationPatterns = {
                'es': [
                    /(?:como|como puedo|como se) (?:hacer|realizar) (?:una |la )?reserva/i,
                    /(?:quiero|necesito|deseo) (?:hacer|realizar) (?:una |la )?reserva/i,
                    /(?:proceso|pasos) (?:para|de) (?:reserva|reservar)/i,
                    /reservas?\s+(?:como|como se hace)/i
                ],
                'en': [
                    /(?:how|how can i) (?:make|do) (?:a |the )?reservation/i,
                    /(?:i want|i need) to (?:make|book) (?:a |the )?reservation/i,
                    /(?:process|steps) (?:for|to) (?:reservation|booking)/i,
                    /reservation\s+(?:how|process)/i
                ],
                'pt': [
                    /(?:como|como posso) (?:fazer|realizar) (?:uma |a )?reserva/i,
                    /(?:quero|preciso) (?:fazer|realizar) (?:uma |a )?reserva/i,
                    /(?:processo|passos) (?:para|de) (?:reserva|reservar)/i,
                    /reservas?\s+(?:como|processo)/i
                ]
            };

            const langPatterns = reservationPatterns[language] || reservationPatterns['es'];
            for (const pattern of langPatterns) {
                if (pattern.test(normalized)) {
                    return 'reservations';
                }
            }

            for (const [queryType, patterns] of Object.entries(this.queryPatterns)) {
                const langPatterns = patterns[language] || patterns['es'];
                for (const pattern of langPatterns) {
                    if (normalized.includes(pattern.toLowerCase())) {
                        return queryType;
                    }
                }
            }

            return null;
        }

        detectQuickQuery(message, language) {
            const normalized = message.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');

            const quickQueryMap = {
                'services': {
                    'es': ['todos los servicios', 'servicios', 'qué servicios tienen'],
                    'en': ['all services', 'services', 'what services do you have'],
                    'pt': ['todos os serviços', 'serviços', 'que serviços têm']
                },
                'vehicles': {
                    'es': ['vehículos', 'qué auto tienen', 'qué carro usan'],
                    'en': ['vehicles', 'what car do you have', 'which vehicle'],
                    'pt': ['veículos', 'que carro têm', 'qual veículo']
                },
                'contact': {
                    'es': ['contacto directo', 'contacto', 'whatsapp', 'teléfono'],
                    'en': ['direct contact', 'contact', 'whatsapp', 'phone'],
                    'pt': ['contato direto', 'contato', 'whatsapp', 'telefone']
                },
                'groups': {
                    'es': ['grupos', 'somos muchos', 'familia grande'],
                    'en': ['groups', 'we are many', 'large family'],
                    'pt': ['grupos', 'somos muitos', 'família grande']
                },
                'prices': {
                    'es': ['precios', 'cuánto cuesta', 'tarifas'],
                    'en': ['prices', 'how much', 'rates'],
                    'pt': ['preços', 'quanto custa', 'valores']
                },
                'reservations': {
                    'es': ['reservas', 'quiero reservar', 'hacer reserva'],
                    'en': ['reservations', 'i want to book', 'make reservation'],
                    'pt': ['reservas', 'quero reservar', 'fazer reserva']
                },
                // NUEVO: Consultas rápidas para paquetes
                'packages': {
                    'es': ['paquetes', 'packs', 'pack', 'paquetes turísticos'],
                    'en': ['packages', 'packs', 'pack', 'tourist packages'],
                    'pt': ['pacotes', 'packs', 'pack', 'pacotes turísticos']
                }
            };

            for (const [queryType, translations] of Object.entries(quickQueryMap)) {
                const terms = translations[language] || translations['es'];
                for (const term of terms) {
                    if (normalized === term.toLowerCase() || normalized.includes(term.toLowerCase())) {
                        return queryType;
                    }
                }
            }

            return null;
        }
    }

    // ==================== INICIALIZACIÓN DE COMPONENTES ====================
    const languageDetector = new LanguageDetector();
    const farewellDetector = new FarewellDetector();
    const queryDetector = new QueryDetector();
    const greetingDetector = new GreetingDetector();
    const travelDetector = new TravelDetector();
    const touristPlaceDetector = new TouristPlaceDetector();
    const compoundQuestionDetector = new CompoundQuestionDetector();

    // ==================== INDICADOR DE ESCRITURA ====================
    typingIndicator.className = 'typing-indicator';
    typingIndicator.innerHTML = '<div class="typing-dots"><span></span><span></span><span></span></div>';
    typingIndicator.style.display = 'none';

    // ==================== CONSULTAS RÁPIDAS ====================
    function getQuickQueries() {
        if (window.translationManager) {
            return [
                {
                    icon: "🌟",
                    text: window.translationManager.translate('chatbot-services'),
                    description: window.translationManager.translate('chatbot-know-services'),
                    type: "services"
                },
                {
                    icon: "🚗",
                    text: window.translationManager.translate('chatbot-vehicles'),
                    description: window.translationManager.translate('chatbot-what-vehicles'),
                    type: "vehicles"
                },
                {
                    icon: "📞",
                    text: window.translationManager.translate('chatbot-contact'),
                    description: window.translationManager.translate('chatbot-whatsapp-email'),
                    type: "contact"
                },
                {
                    icon: "👥",
                    text: window.translationManager.translate('chatbot-groups'),
                    description: window.translationManager.translate('chatbot-large-groups'),
                    type: "groups"
                }
            ];
        }

        return [
            { icon: "💰", text: "Precios", description: "Conocer todos los precios", type: "prices" },
            { icon: "🌟", text: "Todos los servicios", description: "Conocer todos los servicios", type: "services" },
            { icon: "🚗", text: "Vehículos", description: "Qué vehículos tienen", type: "vehicles" },
            { icon: "📞", text: "Contacto directo", description: "WhatsApp y email", type: "contact" },
            { icon: "👥", text: "Grupos", description: "Servicios para grupos grandes", type: "groups" },
        ];
    }

    // ==================== INICIALIZACIÓN UI ====================
    function initializeUI() {
        if (!chatBody) {
            const overlay = chatOverlay || document.createElement('div');
            overlay.id = overlay.id || 'tucanChatOverlay';
            overlay.classList.add('tucan-chat-overlay-fallback');
            if (!chatOverlay) document.body.appendChild(overlay);
            chatOverlay = overlay;

            const bodyDiv = document.createElement('div');
            bodyDiv.id = 'chatOverlayBody';
            bodyDiv.className = 'chat-overlay-body';
            overlay.appendChild(bodyDiv);
            chatBody = bodyDiv;
        }

        if (!chatBody.contains(typingIndicator)) {
            chatBody.appendChild(typingIndicator);
        }

        setupQuickActions();
        setTimeout(() => {
            ensureMessagesContainer();
            scrollToBottom();
        }, 100);
    }

    // ==================== MANEJO DE CONSULTAS RÁPIDAS ====================
    function setupQuickActions() {
        document.addEventListener('click', function (e) {
            const qq = e.target.closest && e.target.closest('.quick-query');
            if (qq) {
                e.preventDefault();
                e.stopPropagation();
                handleQuickQuery(qq);
            }
        });
    }

    function handleQuickQuery(queryElement) {
        let queryType = queryElement.getAttribute('data-type');

        languageDetector.syncWithMainLanguage();

        queryElement.classList.add('clicked');
        setTimeout(() => queryElement.classList.remove('clicked'), 200);

        if (queryType) {
            openChatWithQueryType(queryType);
        } else {
            const queryText = queryElement.querySelector('.query-text')?.textContent || '';
            openChatWithOption(queryText);
        }
    }

    function openChatWithQueryType(queryType) {
        if (!chatOverlay) {
            initializeUI();
        }

        try {
            if (chatOverlay && chatOverlay.classList) {
                chatOverlay.classList.remove('hidden');
                chatOverlay.classList.add('fade-in');
            } else if (chatOverlay) {
                chatOverlay.style.display = 'block';
            }
        } catch (err) {
            if (chatOverlay) chatOverlay.style.display = 'block';
        }

        if (userInput && typeof userInput.focus === 'function') userInput.focus();

        const queryTexts = {
            'services': getQuickQueryUserMessage('services'),
            'vehicles': getQuickQueryUserMessage('vehicles'),
            'contact': getQuickQueryUserMessage('contact'),
            'groups': getQuickQueryUserMessage('groups'),
            'prices': getQuickQueryUserMessage('prices'),
            'reservations': getQuickQueryUserMessage('reservations'),
            'packages': getQuickQueryUserMessage('packages')
        };

        const userMessage = queryTexts[queryType] || queryType;

        setTimeout(() => {
            appendMessage(userMessage, 'user-message');
            if (userInput) userInput.value = '';
            handleUserMessage(userMessage, queryType);
        }, 200);
    }

    function getQuickQueryUserMessage(queryType) {
        const currentLang = languageDetector.getCurrentLanguage();
        const messages = {
            'services': {
                'es': '🌟 Todos los servicios',
                'en': '🌟 All services',
                'pt': '🌟 Todos os serviços'
            },
            'vehicles': {
                'es': '🚗 Vehículos',
                'en': '🚗 Vehicles',
                'pt': '🚗 Veículos'
            },
            'contact': {
                'es': '📞 Contacto directo',
                'en': '📞 Direct contact',
                'pt': '📞 Contato direto'
            },
            'groups': {
                'es': '👥 Grupos',
                'en': '👥 Groups',
                'pt': '👥 Grupos'
            },
            'prices': {
                'es': '💰 Precios',
                'en': '💰 Prices',
                'pt': '💰 Preços'
            },
            'reservations': {
                'es': '📅 Reservas',
                'en': '📅 Reservations',
                'pt': '📅 Reservas'
            },
            // NUEVO: Mensaje para paquetes
            'packages': {
                'es': '🎯 Paquetes turísticos',
                'en': '🎯 Tourist packages',
                'pt': '🎯 Pacotes turísticos'
            }
        };

        return messages[queryType][currentLang] || messages[queryType]['es'];
    }

    function openChatWithOption(option) {
        if (!chatOverlay) {
            initializeUI();
        }

        try {
            if (chatOverlay && chatOverlay.classList) {
                chatOverlay.classList.remove('hidden');
                chatOverlay.classList.add('fade-in');
            } else if (chatOverlay) {
                chatOverlay.style.display = 'block';
            }
        } catch (err) {
            if (chatOverlay) chatOverlay.style.display = 'block';
        }

        if (userInput && typeof userInput.focus === 'function') userInput.focus();

        setTimeout(() => {
            appendMessage(option, 'user-message');
            if (userInput) userInput.value = '';
            handleUserMessage(option);
        }, 200);
    }

    // ==================== PROCESAMIENTO PRINCIPAL DE MENSAJES MEJORADO ====================
    async function handleUserMessage(msg, predefinedType = null) {
        try {
            await showTypingIndicator();

            // VERIFICACIÓN ESPECÍFICA PARA RESERVAS (SOLUCIÓN TEMPORAL)
            const normalizedMsg = msg.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
            if (normalizedMsg.includes('reserva') ||
                normalizedMsg.includes('como reservar') ||
                normalizedMsg.includes('realizar reserva') ||
                normalizedMsg.includes('hacer reserva')) {

                console.log('✅ Reserva detectada específicamente');
                const reservationResponse = languageDetector.getResponse('reservations');
                appendMessage(reservationResponse, 'bot-message');
                resetErrorCount();
                return;
            }

            // 1. Detectar idioma del mensaje (especialmente para saludos)
            const detectedLanguage = languageDetector.detectLanguageFromMessage(msg);
            languageDetector.userLanguage = detectedLanguage;
            conversationContext.userLanguage = detectedLanguage;

            console.log('📝 Mensaje recibido:', msg); // DEBUG
            console.log('🌐 Idioma detectado:', detectedLanguage); // DEBUG

            // 2. Verificar si es una despedida
            if (farewellDetector.isFarewell(msg, detectedLanguage)) {
                const goodbyeResponse = languageDetector.getResponse('goodbye');
                appendMessage(goodbyeResponse, 'bot-message');
                resetErrorCount();

                setTimeout(() => {
                    if (chatOverlay) {
                        chatOverlay.classList.add('fade-out');
                        setTimeout(() => {
                            if (chatOverlay) {
                                chatOverlay.classList.add('hidden');
                                chatOverlay.classList.remove('fade-out', 'fade-in');
                            }
                        }, 300);
                    }
                }, 2000);
                return;
            }

            // 3. VERIFICAR SI ES UNA PREGUNTA COMPUESTA (NUEVA FUNCIONALIDAD)
            if (compoundQuestionDetector.isCompoundQuestion(msg, detectedLanguage)) {
                console.log('🔗 Es pregunta compuesta'); // DEBUG

                const parts = compoundQuestionDetector.splitCompoundQuestion(msg, detectedLanguage);
                if (parts && parts.length > 1) {
                    console.log('📦 Partes de la pregunta compuesta:', parts); // DEBUG

                    const questionTypes = compoundQuestionDetector.detectQuestionTypes(parts, detectedLanguage);
                    const compoundResponse = compoundQuestionDetector.getCompoundResponse(questionTypes, detectedLanguage);

                    // Mostrar introducción
                    appendMessage(compoundResponse.intro, 'bot-message');

                    // Procesar cada parte por separado
                    for (const question of compoundResponse.parts) {
                        await new Promise(resolve => setTimeout(resolve, 800)); // Pausa entre respuestas

                        // Si es un saludo, responder específicamente
                        if (question.type === 'greeting') {
                            const greetingResponse = languageDetector.getResponse('greeting', question.text);
                            appendMessage(greetingResponse, 'bot-message');
                        } else {
                            // Procesar como pregunta normal
                            await processSingleQuestion(question.text, question.type, detectedLanguage);
                        }
                    }

                    resetErrorCount();
                    return;
                }
            }

            // 4. Verificar si es una consulta de lugares turísticos
            if (touristPlaceDetector.isPlaceQuery(msg, detectedLanguage)) {
                console.log('🔍 Es consulta de lugar turístico'); // DEBUG
                const placeName = touristPlaceDetector.extractPlaceName(msg, detectedLanguage);
                console.log('📍 Lugar detectado:', placeName); // DEBUG

                if (placeName) {
                    // Encontró un lugar específico
                    const placeResponse = touristPlaceDetector.getPlaceResponse(placeName, detectedLanguage);
                    appendMessage(placeResponse, 'bot-message');
                } else {
                    // Buscar lugares similares
                    const normalizedMsg = touristPlaceDetector.normalize(msg);
                    const similarPlaces = touristPlaceDetector.getSimilarPlaces(normalizedMsg);

                    if (similarPlaces.length === 1) {
                        // Solo un lugar similar encontrado
                        const placeResponse = touristPlaceDetector.getPlaceResponse(similarPlaces[0], detectedLanguage);
                        appendMessage(placeResponse, 'bot-message');
                    } else if (similarPlaces.length > 1) {
                        // Múltiples lugares similares
                        const multipleResponse = touristPlaceDetector.getMultiplePlacesResponse(similarPlaces, detectedLanguage);
                        appendMessage(multipleResponse, 'bot-message');
                    } else {
                        // No encontró lugares específicos
                        const travelResponse = languageDetector.getResponse('travel');
                        appendMessage(travelResponse, 'bot-message');
                    }
                }
                resetErrorCount();
                return;
            }

            // 5. Verificar si es un saludo o expresión de bienestar
            if (greetingDetector.isGreeting(msg, detectedLanguage)) {
                console.log('👋 Es saludo'); // DEBUG
                const greetingResponse = languageDetector.getResponse('greeting', msg);
                appendMessage(greetingResponse, 'bot-message');
                resetErrorCount();
                return;
            }

            // 6. Verificar si es una consulta de turismo o viajes
            if (travelDetector.isTravelQuery(msg, detectedLanguage)) {
                console.log('🏞️ Es consulta de turismo'); // DEBUG
                const travelResponse = languageDetector.getResponse('travel');
                appendMessage(travelResponse, 'bot-message');
                resetErrorCount();
                return;
            }

            // 7. Procesar como pregunta simple
            await processSingleQuestion(msg, predefinedType, detectedLanguage);

        } catch (err) {
            console.error('Error en handleUserMessage:', err);
            const fallback = languageDetector.getResponse('contact');
            appendMessage(fallback, 'bot-message');
            resetErrorCount();
        }
    }

    // ==================== PROCESAMIENTO DE PREGUNTAS SIMPLES ====================
    async function processSingleQuestion(msg, predefinedType = null, detectedLanguage = 'es') {
        // Determinar el tipo de consulta
        let queryType = predefinedType;
        if (!queryType) {
            queryType = queryDetector.detectQuickQuery(msg, detectedLanguage);
            if (!queryType) {
                queryType = queryDetector.detectQueryType(msg, detectedLanguage);
            }
        }

        console.log('❓ Tipo de consulta detectada:', queryType); // DEBUG

        // Generar respuesta basada en el tipo de consulta
        let response = '';

        if (queryType) {
            response = languageDetector.getResponse(queryType);
        } else {
            errorCount++;
            if (errorCount >= MAX_ERRORS) {
                response = languageDetector.getResponse('contact');
            } else {
                response = languageDetector.getResponse('confused');
            }
        }

        appendMessage(response, 'bot-message');
        resetErrorCount();
    }

    // ==================== INTERFAZ DE CONSULTAS RÁPIDAS ====================
    function createQuickQueriesInterface() {
        const container = document.createElement('div');
        container.className = 'quick-queries-container';
        container.id = 'quickQueries';

        const title = document.createElement('div');
        title.className = 'queries-title';
        title.textContent = window.translationManager ?
            window.translationManager.translate('chatbot-help') : '¿En qué podemos ayudarte?';
        container.appendChild(title);

        const grid = document.createElement('div');
        grid.className = 'queries-grid';

        const quickQueries = getQuickQueries();

        quickQueries.forEach(q => {
            const el = document.createElement('div');
            el.className = 'quick-query';
            el.setAttribute('data-query', q.text);
            el.setAttribute('data-type', q.type);
            el.innerHTML = `
                <div class="query-icon">${q.icon}</div>
                <div class="query-content">
                    <div class="query-text">${q.text}</div>
                    <div class="query-description">${q.description}</div>
                </div>`;
            grid.appendChild(el);
        });

        container.appendChild(grid);
        return container;
    }

    function addQuickQueriesToChat() {
        const messagesContainer = ensureMessagesContainer();
        const existing = messagesContainer.querySelector('#quickQueries');
        if (existing) existing.remove();
        const queriesInterface = createQuickQueriesInterface();
        messagesContainer.insertBefore(queriesInterface, messagesContainer.firstChild);
    }

    // ==================== FUNCIONES UI ====================
    function ensureMessagesContainer() {
        if (!chatBody) initializeUI();
        let container = chatBody.querySelector('.messages-container');
        if (!container) {
            container = document.createElement('div');
            container.className = 'messages-container';
            chatBody.appendChild(container);
            if (!chatBody.contains(typingIndicator)) chatBody.appendChild(typingIndicator);
        }
        return container;
    }

    function scrollToBottom() {
        try {
            const container = chatBody.querySelector('.messages-container');
            if (container) container.scrollTop = container.scrollHeight;
        } catch (e) { /* no hacer nada */ }
    }

    // ==================== EVENTOS PRINCIPALES ====================
    if (chatBtn) {
        chatBtn.addEventListener('click', e => {
            e.preventDefault();
            if (!chatOverlay) initializeUI();

            try {
                if (chatOverlay && chatOverlay.classList) {
                    chatOverlay.classList.remove('hidden');
                    chatOverlay.classList.add('fade-in');
                } else if (chatOverlay) {
                    chatOverlay.style.display = 'block';
                }
            } catch (err) {
                if (chatOverlay) chatOverlay.style.display = 'block';
            }

            if (userInput && typeof userInput.focus === 'function') userInput.focus();

            setTimeout(() => {
                addQuickQueriesToChat();
                if (!hasShownWelcome) {
                    addWelcomeMessage();
                    hasShownWelcome = true;
                }
                scrollToBottom();
            }, 100);
        });
    }

    if (closeOverlayBtn) {
        closeOverlayBtn.addEventListener('click', e => {
            e.preventDefault();
            try {
                if (chatOverlay && chatOverlay.classList) {
                    chatOverlay.classList.add('fade-out');
                    setTimeout(() => {
                        if (chatOverlay) {
                            chatOverlay.classList.add('hidden');
                            chatOverlay.classList.remove('fade-out', 'fade-in');
                        }
                    }, 300);
                    resetErrorCount();
                } else if (chatOverlay) {
                    chatOverlay.style.display = 'none';
                }
            } catch (err) {
                if (chatOverlay) chatOverlay.style.display = 'none';
            }
        });
    }

    // ==================== MANEJO DE ENVÍO DE MENSAJES ====================
    if (userInput) {
        userInput.addEventListener('keydown', e => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleMessage();
            }
        });

        userInput.addEventListener('input', function () {
            this.style.height = 'auto';
            this.style.height = this.scrollHeight + 'px';
        });
    }

    if (sendBtn) {
        sendBtn.addEventListener('click', e => {
            e.preventDefault();
            handleMessage();
        });
    }

    async function handleMessage() {
        if (!userInput) return;
        const msg = (userInput.value || '').trim();
        if (!msg) return;

        appendMessage(msg, 'user-message');
        userInput.value = '';
        userInput.style.height = 'auto';

        await handleUserMessage(msg);
    }

    // ==================== FUNCIONES DE MENSAJE ====================
    function resetErrorCount() { errorCount = 0; }

    async function showTypingIndicator() {
        if (isTyping) return;
        isTyping = true;
        typingIndicator.style.display = 'block';
        scrollToBottom();
        return new Promise(resolve => {
            setTimeout(() => {
                hideTypingIndicator();
                resolve();
            }, 700 + Math.random() * 800);
        });
    }

    function hideTypingIndicator() {
        isTyping = false;
        typingIndicator.style.display = 'none';
    }

    function appendMessage(text, className) {
        if (!chatBody) initializeUI();
        const msgDiv = document.createElement('div');
        msgDiv.className = `message ${className}`;
        let time = '';

        try {
            time = new Date().toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' });
        } catch (e) {
            time = new Date().toLocaleTimeString();
        }

        if (className === 'bot-message') {
            const header = document.createElement('div');
            header.className = 'message-header';
            const avatar = document.createElement('img');
            avatar.src = './images/logos/tuqui.png';
            avatar.alt = 'TUQUI';
            avatar.className = 'tucan-avatar';
            const sender = document.createElement('span');
            sender.className = 'sender-name';
            sender.textContent = 'TUQUI';
            header.appendChild(avatar);
            header.appendChild(sender);
            msgDiv.appendChild(header);
        }

        const textDiv = document.createElement('div');
        textDiv.className = 'message-text';
        const safeText = (text || '').toString()
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\n/g, '<br>');
        textDiv.innerHTML = safeText;
        msgDiv.appendChild(textDiv);

        const timeDiv = document.createElement('div');
        timeDiv.className = 'message-time';
        timeDiv.textContent = time;
        msgDiv.appendChild(timeDiv);

        const container = ensureMessagesContainer();
        container.appendChild(msgDiv);
        scrollToBottom();
    }

    function addWelcomeMessage() {
        languageDetector.syncWithMainLanguage();
        const welcomeMessage = languageDetector.getResponse('welcome');
        appendMessage(welcomeMessage, 'bot-message');
    }

    // ==================== INTEGRACIÓN CON SISTEMA DE TRADUCCIÓN ====================
    if (window.translationManager) {
        languageDetector.userLanguage = window.translationManager.currentLanguage;
    }

    document.addEventListener('languageChanged', function (e) {
        if (languageDetector) {
            languageDetector.userLanguage = e.detail.language;
            if (chatOverlay && !chatOverlay.classList.contains('hidden')) {
                addQuickQueriesToChat();
                if (hasShownWelcome) {
                    const messagesContainer = ensureMessagesContainer();
                    const botMessages = messagesContainer.querySelectorAll('.bot-message');
                    if (botMessages.length > 0) {
                        const welcomeMessage = languageDetector.getResponse('welcome');
                        const firstBotMessage = botMessages[0];
                        const messageText = firstBotMessage.querySelector('.message-text');
                        if (messageText) {
                            messageText.innerHTML = welcomeMessage.replace(/\n/g, '<br>');
                        }
                    }
                }
            }
        }
    });

    // ==================== FUNCIONALIDAD DE CAMBIO DE IDIOMA EN CHATBOT ====================
    function setupChatLanguageToggle() {
        const languageToggle = document.getElementById('chatLanguageToggle');
        const chatInput = document.getElementById('chatOverlayInput');

        if (!languageToggle || !chatInput) return;

        // Crear menú de idiomas
        const languageMenu = document.createElement('div');
        languageMenu.className = 'chat-language-menu';
        languageMenu.innerHTML = `
            <button class="chat-language-option" data-lang="es">
                <img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA5IDYiPjxyZWN0IHdpZHRoPSI5IiBoZWlnaHQ9IjYiIGZpbGw9IiNBQTE1MUIiLz48cmVjdCB3aWR0aD0iOSIgaGVpZ2h0PSIyIiB5PSIyIiBmaWxsPSIjRjFCRjAwIi8+PC9zdmc+" alt="Español" class="chat-language-flag">
                Español
            </button>

            <button class="chat-language-option" data-lang="en">
                <img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA2MCAzMCI+PGNsaXBQYXRoIGlkPSJ0Ij48cGF0aCBkPSJNM CwwIHYzMCBoNjAgdi0zMCB6Ii8+PC9jbGlwUGF0aD48cGF0aCBkPSJNM CwwIHYzMCBoNjAgdi0zMCB6IiBmaWxsPSIjMDEyMTY5Ii8+PHBhdGggZD0iTTAsMCBMNjAsMzAgTTYwLDAgTDAsMzAiIHN0cm9rZT0iI2ZmZiIgc3Ryb2tlLXdpZHRoPSI2Ii8+PHBhdGggZD0iTTAsMCBMNjAsMzAgTTYwLDAgTDAsMzAiIHN0cm9rZT0iI0M4MTAyRSIgc3Ryb2tlLXdpZHRoPSI0Ii8+PHBhdGggZD0iTTMwLDAgdjMwIE0wLDE1IGg2MCIgc3Ryb2tlPSIjZmZmIiBzdHJva2Utd2lkdGg9IjEwIi8+PHBhdGggZD0iTTMwLDAgdjMwIE0wLDE1IGg2MCIgc3Ryb2tlPSIjQzgxMDJFIiBzdHJva2Utd2lkdGg9IjYiLz48L3N2Zz4=" alt="English" class="chat-language-flag">
                English
            </button>

            <button class="chat-language-option" data-lang="pt">
                <img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA3IDUiPjxyZWN0IHdpZHRoPSI3IiBoZWlnaHQ9IjUiIGZpbGw9IiMwMDlDM0IiLz48cG9seWdvbiBwb2ludHM9IjMuNSwwLjYgNiw yLjUgMy41LDQuNCAxLDIuNSIgZmlsbD0iI0ZGREYwMCIvPjxjaXJjbGUgY3g9IjMuNSIgY3k9IjIuNSIgcj0iMSIgZmlsbD0iIzAwMjc3NiIvPjwvc3ZnPg==" alt="Português" class="chat-language-flag">
                Português
            </button>
        `;

        languageToggle.parentElement.appendChild(languageMenu);

        // Actualizar placeholder según idioma actual
        function updateChatInputPlaceholder() {
            const currentLang = window.translationManager ? window.translationManager.currentLanguage : 'es';
            const placeholders = {
                'es': '¿En qué podemos ayudarte?',
                'en': 'How can we help you?',
                'pt': 'Como podemos ajudá-lo?'
            };
            chatInput.placeholder = placeholders[currentLang] || 'How can we help you?';

            // Actualizar opción activa
            languageMenu.querySelectorAll('.chat-language-option').forEach(option => {
                option.classList.toggle('active', option.getAttribute('data-lang') === currentLang);
            });
        }

        // Alternar menú de idiomas
        languageToggle.addEventListener('click', (e) => {
            e.stopPropagation();
            languageMenu.classList.toggle('active');
            languageToggle.classList.toggle('active');
        });

        // Selección de idioma
        languageMenu.addEventListener('click', (e) => {
            const option = e.target.closest('.chat-language-option');
            if (option) {
                const lang = option.getAttribute('data-lang');

                if (window.translationManager) {
                    window.translationManager.changeLanguage(lang);
                }

                // Cerrar menú
                languageMenu.classList.remove('active');
                languageToggle.classList.remove('active');

                // Actualizar interfaz del chatbot
                updateChatbotLanguage(lang);
            }
        });

        // Cerrar menú al hacer clic fuera
        document.addEventListener('click', () => {
            languageMenu.classList.remove('active');
            languageToggle.classList.remove('active');
        });

        // Prevenir que el clic en el menú lo cierre
        languageMenu.addEventListener('click', (e) => {
            e.stopPropagation();
        });

        // Actualizar placeholder cuando cambie el idioma
        document.addEventListener('languageChanged', updateChatInputPlaceholder);

        // Inicializar
        updateChatInputPlaceholder();
    }

    // Función para actualizar el idioma del chatbot
    function updateChatbotLanguage(lang) {
        if (window.languageDetector) {
            window.languageDetector.userLanguage = lang;

            // Actualizar consultas rápidas si están visibles
            const quickQueriesContainer = document.getElementById('quickQueries');
            if (quickQueriesContainer && window.translationManager) {
                window.translationManager.updateChatbotQuickQueries();
            }

            // Si hay mensajes del bot, actualizar el último
            if (window.chatBody) {
                const botMessages = window.chatBody.querySelectorAll('.bot-message');
                if (botMessages.length > 0 && window.hasShownWelcome) {
                    const lastBotMessage = botMessages[botMessages.length - 1];
                    const messageText = lastBotMessage.querySelector('.message-text');
                    if (messageText && window.translationManager) {
                        const welcomeMessage = window.translationManager.translate('chatbot-welcome');
                        messageText.innerHTML = welcomeMessage.replace(/\n/g, '<br>');
                    }
                }
            }
        }
    }

    // ==================== INICIO ====================
    initializeUI();

    // Inicializar el toggle de idioma del chatbot cuando esté listo
    setTimeout(() => {
        setupChatLanguageToggle();
    }, 1000);

    // ==================== PRUEBA DE DETECCIÓN COMPUESTA ====================
    function testCompoundQuestionsDetection() {
        console.log('🧪 Probando detección de preguntas compuestas...');

        const testCases = [
            "hola, que tal? quiero saber sobre los servicios",
            "Hola, quería saber sobre las cataratas y también el precio para grupos",
            "Buenos días, me interesan las ruinas y el duty free",
            "Quiero información sobre Güira Oga y también sobre reservas",
            "Hola, ¿cómo estás? y quería saber los precios de los paquetes turísticos",
            "hola que tal quiero saber sobre servicios",
            "buenos dias necesito informacion sobre precios y reservas"
        ];

        testCases.forEach(testCase => {
            const isCompound = compoundQuestionDetector.isCompoundQuestion(testCase, 'es');
            const parts = compoundQuestionDetector.splitCompoundQuestion(testCase, 'es');
            console.log(`"${testCase}" -> ¿Compuesta? ${isCompound}, Partes:`, parts);
        });
    }

    // Ejecutar prueba cuando el DOM esté listo
    setTimeout(testCompoundQuestionsDetection, 2000);
});