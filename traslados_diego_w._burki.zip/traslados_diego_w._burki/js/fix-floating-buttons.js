// fix-floating-buttons.js - Solución mejorada para scroll y botones flotantes

class FloatingButtonsManager {
    constructor() {
        this.buttons = [
            { id: 'whatsappBtn', zIndex: '10001' },
            { id: 'scrollTopBtn', zIndex: '10000' },
            { id: 'tucanChatBtn', zIndex: '10002' }
        ];
        
        this.chatOverlay = document.getElementById('tucanChatOverlay');
        this.isChatOpen = false;
        
        this.init();
    }
    
    init() {
        this.setupScrollBehavior();
        this.setupChatObserver();
        this.setupScrollTopButton();
        this.initializeButtons();
    }
    
    setupScrollBehavior() {
        // Smooth scroll para enlaces internos
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', (e) => {
                e.preventDefault();
                const target = document.querySelector(anchor.getAttribute('href'));
                if (target) {
                    this.scrollToElement(target);
                }
            });
        });
        
        // Mejorar el scroll general
        this.improveScrollPerformance();
    }
    
    scrollToElement(element) {
        const headerHeight = document.querySelector('header')?.offsetHeight || 0;
        const elementPosition = element.getBoundingClientRect().top + window.pageYOffset;
        const offsetPosition = elementPosition - headerHeight - 20;
        
        window.scrollTo({
            top: offsetPosition,
            behavior: 'smooth'
        });
    }
    
    improveScrollPerformance() {
        // Usar requestAnimationFrame para mejor rendimiento
        let ticking = false;
        
        const updateButtonsOnScroll = () => {
            this.handleScrollTopButton();
            ticking = false;
        };
        
        window.addEventListener('scroll', () => {
            if (!ticking) {
                requestAnimationFrame(updateButtonsOnScroll);
                ticking = true;
            }
        }, { passive: true });
    }
    
    setupScrollTopButton() {
        const scrollTopBtn = document.getElementById('scrollTopBtn');
        if (scrollTopBtn) {
            scrollTopBtn.addEventListener('click', () => {
                this.scrollToTop();
            });
        }
        
        this.handleScrollTopButton();
    }
    
    scrollToTop() {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    }
    
    handleScrollTopButton() {
        const scrollTopBtn = document.getElementById('scrollTopBtn');
        if (!scrollTopBtn) return;
        
        const scrollY = window.scrollY || document.documentElement.scrollTop;
        
        if (scrollY > 300) {
            scrollTopBtn.classList.add('show');
        } else {
            scrollTopBtn.classList.remove('show');
        }
        
        // Ajustar posición en móviles
        this.adjustMobilePositions();
    }
    
    adjustMobilePositions() {
        if (window.innerWidth <= 768) {
            const whatsappBtn = document.getElementById('whatsappBtn');
            const scrollTopBtn = document.getElementById('scrollTopBtn');
            const tucanChatBtn = document.getElementById('tucanChatBtn');
            
            if (whatsappBtn) {
                whatsappBtn.style.bottom = '6rem';
            }
            if (scrollTopBtn) {
                scrollTopBtn.style.bottom = '1.5rem';
            }
            if (tucanChatBtn) {
                tucanChatBtn.style.bottom = '11rem';
            }
        }
    }
    
    setupChatObserver() {
        if (!this.chatOverlay) return;
        
        const observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                if (mutation.attributeName === 'class') {
                    this.isChatOpen = !this.chatOverlay.classList.contains('hidden');
                    this.toggleFloatingButtons();
                }
            });
        });
        
        observer.observe(this.chatOverlay, {
            attributes: true,
            attributeFilter: ['class']
        });
        
        // Estado inicial
        this.isChatOpen = !this.chatOverlay.classList.contains('hidden');
        this.toggleFloatingButtons();
    }
    
    toggleFloatingButtons() {
        if (this.isChatOpen) {
            this.hideFloatingButtons();
        } else {
            this.showFloatingButtons();
        }
    }
    
    hideFloatingButtons() {
        this.buttons.forEach(btnInfo => {
            const btn = document.getElementById(btnInfo.id);
            if (btn) {
                btn.style.cssText = `
                    opacity: 0 !important;
                    visibility: hidden !important;
                    pointer-events: none !important;
                    transform: scale(0.8) !important;
                    transition: all 0.3s ease !important;
                `;
            }
        });
    }
    
    showFloatingButtons() {
        this.buttons.forEach((btnInfo, index) => {
            const btn = document.getElementById(btnInfo.id);
            if (btn) {
                setTimeout(() => {
                    btn.style.cssText = `
                        opacity: 1 !important;
                        visibility: visible !important;
                        pointer-events: auto !important;
                        transform: scale(1) !important;
                        transition: all 0.3s ease 0.${index}s !important;
                        z-index: ${btnInfo.zIndex} !important;
                    `;
                }, index * 100);
            }
        });
    }
    
    initializeButtons() {
        // Posiciones iniciales responsivas
        this.adjustMobilePositions();
        
        // Ajustar en resize
        window.addEventListener('resize', () => {
            this.adjustMobilePositions();
        });
    }
}

// Inicializar cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', () => {
    new FloatingButtonsManager();
});

// Fallback para si el DOM ya está cargado
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        new FloatingButtonsManager();
    });
} else {
    new FloatingButtonsManager();
}