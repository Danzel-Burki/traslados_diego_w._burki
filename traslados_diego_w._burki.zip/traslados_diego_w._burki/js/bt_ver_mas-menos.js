document.addEventListener("DOMContentLoaded", () => {
  const btnMostrarMas = document.getElementById("btn-mostrar-mas");
  const viajesOcultos = document.getElementById("viajes-ocultos");

  if (btnMostrarMas && viajesOcultos) {
    btnMostrarMas.addEventListener("click", () => {
      viajesOcultos.classList.toggle("oculto");
      btnMostrarMas.textContent = viajesOcultos.classList.contains("oculto")
        ? "Ver más viajes"
        : "Ver menos viajes";
    });
  }
});