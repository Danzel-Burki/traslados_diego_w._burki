// chatbot-controls.js - VERSIÓN SIN MODIFICAR SCROLL
document.addEventListener('DOMContentLoaded', function() {
    const whatsappBtn = document.getElementById('whatsappBtn');
    const tucanChatBtn = document.getElementById('tucanChatBtn');
    const scrollTopBtn = document.getElementById('scrollTopBtn');
    const chatOverlay = document.getElementById('tucanChatOverlay');
    const closeBtn = document.getElementById('closeChatOverlay');

    let isChatOpen = false;

    // Ocultar COMPLETAMENTE los botones flotantes
    function hideFloatingButtons() {
        console.log('Ocultando botones flotantes...');
        
        const floatingElements = [whatsappBtn, tucanChatBtn, scrollTopBtn];
        
        floatingElements.forEach(element => {
            if (element) {
                // Ocultar completamente SIN AFECTAR SCROLL
                element.style.display = 'none';
                element.style.visibility = 'hidden';
                element.style.opacity = '0';
                element.style.pointerEvents = 'none';
                
                // Forzar reflow
                element.offsetHeight;
            }
        });
    }

    // Mostrar botones flotantes con animación
    function showFloatingButtons() {
        console.log('Mostrando botones flotantes...');
        
        const floatingElements = [whatsappBtn, tucanChatBtn, scrollTopBtn];
        
        floatingElements.forEach((element, index) => {
            if (element) {
                // Restaurar propiedades de visualización
                element.style.display = 'flex';
                element.style.visibility = 'visible';
                element.style.pointerEvents = 'auto';
                
                // Animación escalonada
                setTimeout(() => {
                    element.style.transition = 'all 0.5s cubic-bezier(0.34, 1.56, 0.64, 1)';
                    element.style.opacity = '1';
                    element.style.transform = 'scale(1)';
                }, index * 150);
                
                // Restaurar transición normal después de la animación
                setTimeout(() => {
                    element.style.transition = 'all 0.3s ease';
                }, 800);
            }
        });
    }

    // Activar modo chat - SOLO OCULTAR BOTONES
    function activateChatMode() {
        if (isChatOpen) return;
        
        console.log('🔴 ACTIVANDO MODO CHAT - Ocultando botones');
        isChatOpen = true;
        
        // Ocultar inmediatamente - SIN MODIFICAR SCROLL
        hideFloatingButtons();
        
        // Solo añadir clase para CSS - NO TOCAR SCROLL
        document.body.classList.add('chatbot-active');
    }

    // Desactivar modo chat - SOLO MOSTRAR BOTONES
    function deactivateChatMode() {
        if (!isChatOpen) return;
        
        console.log('🟢 DESACTIVANDO MODO CHAT - Mostrando botones');
        isChatOpen = false;
        
        // Remover clases del body - NO RESTAURAR SCROLL (porque no lo modificamos)
        document.body.classList.remove('chatbot-active');
        
        // Mostrar botones con animación
        setTimeout(() => {
            showFloatingButtons();
        }, 300);
    }

    // Observar cambios en el estado del chat
    function observeChatbot() {
        if (!chatOverlay) return;

        const observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                if (mutation.attributeName === 'class') {
                    const isHidden = chatOverlay.classList.contains('hidden');
                    
                    if (!isHidden && !isChatOpen) {
                        console.log('🟡 Chat abierto - Ocultando botones');
                        activateChatMode();
                    } else if (isHidden && isChatOpen) {
                        console.log('🟡 Chat cerrado - Mostrando botones');
                        deactivateChatMode();
                    }
                }
            });
        });

        observer.observe(chatOverlay, { 
            attributes: true, 
            attributeFilter: ['class'] 
        });

        // Estado inicial
        if (!chatOverlay.classList.contains('hidden')) {
            activateChatMode();
        }
    }

    // Configurar manejadores de cierre
    function setupCloseHandlers() {
        // Botón cerrar
        if (closeBtn) {
            closeBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                console.log('❌ Clic en botón cerrar');
                deactivateChatMode();
                
                // Cerrar el overlay también
                if (chatOverlay) {
                    chatOverlay.classList.add('hidden');
                }
            });
        }

        // Clic fuera del chat
        if (chatOverlay) {
            chatOverlay.addEventListener('click', function(e) {
                if (e.target === chatOverlay) {
                    console.log('❌ Clic fuera del chat');
                    deactivateChatMode();
                    chatOverlay.classList.add('hidden');
                }
            });
        }

        // Tecla Escape
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && isChatOpen) {
                console.log('❌ Tecla Escape presionada');
                deactivateChatMode();
                if (chatOverlay) {
                    chatOverlay.classList.add('hidden');
                }
            }
        });
    }

    // Botón abrir chat
    if (tucanChatBtn) {
        tucanChatBtn.addEventListener('click', function() {
            console.log('🎯 Botón tucán clickeado - Abriendo chat');
            setTimeout(() => {
                if (chatOverlay) {
                    chatOverlay.classList.remove('hidden');
                }
            }, 50);
        });
    }

    // Inicialización
    function init() {
        console.log('🚀 Inicializando controles del chatbot...');
        observeChatbot();
        setupCloseHandlers();
        
        // Estado inicial seguro
        setTimeout(() => {
            if (chatOverlay && chatOverlay.classList.contains('hidden')) {
                showFloatingButtons();
            }
        }, 500);
    }

    // Iniciar cuando el DOM esté listo
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
});