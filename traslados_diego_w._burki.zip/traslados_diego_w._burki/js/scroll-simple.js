// scroll-simple.js - Versión minimalista y funcional
document.addEventListener('DOMContentLoaded', function() {
    console.log('🔧 Inicializando scroll button...');
    
    const scrollBtn = document.getElementById("scrollTopBtn");
    
    if (!scrollBtn) {
        console.error('❌ No se encontró el botón scrollTopBtn');
        return;
    }

    console.log('✅ Botón encontrado:', scrollBtn);

    // Mostrar/ocultar botón al hacer scroll
    window.addEventListener("scroll", function() {
        console.log('📜 Scroll Y:', window.scrollY);
        if (window.scrollY > 400) {
            scrollBtn.classList.add("show");
            console.log('👁️ Mostrando botón');
        } else {
            scrollBtn.classList.remove("show");
            console.log('🙈 Ocultando botón');
        }
    });

    // Scroll suave al hacer click
    scrollBtn.addEventListener("click", function(e) {
        e.preventDefault();
        console.log('🔼 Haciendo scroll al top');
        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });
    });

    // Estado inicial
    scrollBtn.classList.remove("show");
    console.log('🎯 Scroll button inicializado correctamente');
});