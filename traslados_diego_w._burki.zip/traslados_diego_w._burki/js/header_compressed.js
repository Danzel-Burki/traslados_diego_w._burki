window.addEventListener('scroll', () => {
  const header = document.querySelector('header');
  if (window.scrollY > 50) {  // si bajaste más de 50px
    header.classList.add('header-shrink');
  } else {
    header.classList.remove('header-shrink');
  }
});
