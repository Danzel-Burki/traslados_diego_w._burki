// burger.js - Función corregida con navegación suave
document.addEventListener('DOMContentLoaded', function() {
  const hamburger = document.getElementById('hamburger');
  const navMenu = document.getElementById('nav-menu');
  const body = document.body;
  
  // Variables para controlar el estado
  let menuOpen = false;
  let scrollPosition = 0;
  
  // Crear overlay si no existe
  let overlay = document.querySelector('.nav-overlay');
  if (!overlay) {
    overlay = document.createElement('div');
    overlay.className = 'nav-overlay';
    document.body.appendChild(overlay);
  }
  
  // Función para bloquear el scroll
  function disableScroll() {
    // Guardar la posición actual del scroll
    scrollPosition = window.pageYOffset || document.documentElement.scrollTop;
    
    // Aplicar estilos para bloquear el scroll
    body.style.overflow = 'hidden';
    body.style.position = 'fixed';
    body.style.top = `-${scrollPosition}px`;
    body.style.width = '100%';
    body.style.height = '100vh';
    
    // Prevenir scroll táctil en dispositivos móviles
    document.addEventListener('touchmove', preventTouchScroll, { passive: false });
  }
  
  // Función para habilitar el scroll
  function enableScroll() {
    // Remover estilos de bloqueo
    body.style.removeProperty('overflow');
    body.style.removeProperty('position');
    body.style.removeProperty('top');
    body.style.removeProperty('width');
    body.style.removeProperty('height');
    
    // Restaurar la posición del scroll
    window.scrollTo(0, scrollPosition);
    
    // Remover el event listener de touch
    document.removeEventListener('touchmove', preventTouchScroll);
  }
  
  // Función para prevenir scroll táctil
  function preventTouchScroll(e) {
    e.preventDefault();
  }
  
  // Función para abrir/cerrar el menú
  function toggleMenu() {
    menuOpen = !menuOpen;
    
    if (menuOpen) {
      // Abrir menú y bloquear scroll
      disableScroll();
      hamburger.classList.add('active');
      navMenu.classList.add('active');
      overlay.classList.add('active');
    } else {
      // Cerrar menú y habilitar scroll
      enableScroll();
      hamburger.classList.remove('active');
      navMenu.classList.remove('active');
      overlay.classList.remove('active');
    }
  }
  
  // Función para cerrar menú CON NAVEGACIÓN
  function closeMenu() {
    if (menuOpen) {
      menuOpen = false;
      
      // Primero cerrar el menú visualmente
      hamburger.classList.remove('active');
      navMenu.classList.remove('active');
      overlay.classList.remove('active');
      
      // Esperar un momento para que la navegación ocurra antes de habilitar el scroll
      setTimeout(() => {
        enableScroll();
      }, 100); // 100ms es suficiente para que el clic se procese
    }
  }
  
  // Función para cerrar menú SIN navegación (para overlay, escape, etc.)
  function closeMenuImmediate() {
    if (menuOpen) {
      menuOpen = false;
      enableScroll();
      hamburger.classList.remove('active');
      navMenu.classList.remove('active');
      overlay.classList.remove('active');
    }
  }
  
  // Event listener para el botón del menú
  hamburger.addEventListener('click', function(e) {
    e.stopPropagation();
    toggleMenu();
  });
  
  // Cerrar menú al hacer clic en overlay (sin navegación)
  overlay.addEventListener('click', closeMenuImmediate);
  
  // Cerrar menú al hacer clic en un enlace (CON navegación)
  const navLinks = document.querySelectorAll('.nav-menu a');
  navLinks.forEach(link => {
    link.addEventListener('click', function(e) {
      // Permitir que el enlace funcione normalmente y luego cerrar el menú
      closeMenu();
      
      // Si es un enlace interno (#), hacer scroll suave manualmente
      const href = this.getAttribute('href');
      if (href.startsWith('#')) {
        e.preventDefault();
        const targetId = href.substring(1);
        const targetElement = document.getElementById(targetId);
        
        if (targetElement) {
          // Cerrar menú primero
          closeMenu();
          
          // Esperar a que el menú se cierre y luego hacer scroll
          setTimeout(() => {
            targetElement.scrollIntoView({
              behavior: 'smooth',
              block: 'start'
            });
          }, 150);
        }
      }
    });
  });
  
  // Cerrar menú al hacer clic fuera (sin navegación)
  document.addEventListener('click', function(e) {
    if (menuOpen && !navMenu.contains(e.target) && !hamburger.contains(e.target) && !overlay.contains(e.target)) {
      closeMenuImmediate();
    }
  });
  
  // Cerrar con tecla Escape (sin navegación)
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && menuOpen) {
      closeMenuImmediate();
    }
  });
  
  // Cerrar menú al cambiar el tamaño de la ventana (si se vuelve a tamaño desktop)
  window.addEventListener('resize', function() {
    if (menuOpen && window.innerWidth > 767) {
      closeMenuImmediate();
    }
  });
  
  // Limpiar el estado al recargar la página
  window.addEventListener('beforeunload', function() {
    if (menuOpen) {
      closeMenuImmediate();
    }
  });
});