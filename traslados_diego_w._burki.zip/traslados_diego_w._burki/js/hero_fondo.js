const fondos = [
  'images/fondo/fondo_1.jpg',
  'images/fondo/fondo_2.jpg',
  'images/fondo/fondo_3.jpg',
  'images/fondo/fondo_4.jpg',
  'images/fondo/fondo_5.jpg',
  'images/fondo/fondo_6.jpg',
];

let fondoActual = 0;
const heroBackground = document.getElementById('heroBackground');

let intervaloFondo; // Variable para guardar el setInterval

// Inicializa fondo
heroBackground.style.backgroundImage = `url(${fondos[fondoActual]})`;

// Función para iniciar o reiniciar el intervalo
function iniciarIntervalo() {
  clearInterval(intervaloFondo); // Detiene el anterior si existe
  intervaloFondo = setInterval(cambiarFondoConTransicion, 5000);
}

// Cambio de fondo manual instantáneo y reinicio del contador
function cambiarFondo(direccion) {
  fondoActual = (fondoActual + direccion + fondos.length) % fondos.length;
  heroBackground.style.backgroundImage = `url(${fondos[fondoActual]})`;
  iniciarIntervalo(); // Reinicia el temporizador
}

// Cambio automático con transición
function cambiarFondoConTransicion() {
  fondoActual = (fondoActual + 1) % fondos.length;
  heroBackground.classList.add('fade');
  setTimeout(() => {
    heroBackground.style.backgroundImage = `url(${fondos[fondoActual]})`;
    heroBackground.classList.remove('fade');
  }, 500);
}

// Iniciar intervalo al cargar la página
iniciarIntervalo();
