const translations = {
  es: {
    // ... tus traducciones existentes ...
    "language-notice-title": "¿Hablas otro idioma?",
    "language-notice-message": "Puedes cambiar el idioma del sitio en cualquier momento"
  },
  en: {
    // ... tus traducciones existentes ...
    "language-notice-title": "Do you speak another language?",
    "language-notice-message": "You can change the site language at any time"
  },
  pt: {
    // ... tus traducciones existentes ...
    "language-notice-title": "Você fala outro idioma?",
    "language-notice-message": "Você pode alterar o idioma do site a qualquer momento"
  },
  fr: {
    // ... tus traducciones existentes ...
    "language-notice-title": "Parlez-vous une autre langue ?",
    "language-notice-message": "Vous pouvez changer la langue du site à tout moment"
  },
  de: {
    // ... tus traducciones existentes ...
    "language-notice-title": "Sprechen Sie eine andere Sprache?",
    "language-notice-message": "Sie können die Sprache der Website jederzeit ändern"
  }
};