// translations.js - Sistema de traducción unificado COMPLETO CON INTEGRACIÓN CHATBOT
class TranslationManager {
    constructor() {
        this.currentLanguage = 'es';
        this.translations = {
            'es': {
                // Navegación
                'inicio': 'Inicio',
                'servicios-de-turismo': 'Servicios de turismo',
                'viajes': 'Viajes Realizados',
                'nosotros-modern': 'Nosotros',
                'contactos': 'Contactos',
                
                // Hero section
                'bienvenidos': 'Bienvenidos a',
                'nombre': 'Traslados Diego<span class="rojo">W.</span> Burki',
                'slogan': '"Servicio profesional de transporte turístico en todo el país"',
                
                // Servicios
                'servicio-turismo': 'SERVICIO DE TURISMO',
                'turismo-provincial': 'Turismo Provincial',
                'turismo-internacional': 'Turismo Internacional',
                
                // Lugares turísticos provinciales
                'cataratas-iguazu': 'Cataratas del Iguazú',
                'lugares-turisticos-iguazu': 'Güirá Oga',
                'gruta-india': 'Gruta India',
                'minas-wanda': 'Minas de Wanda',
                'tour-dia': 'Saltos del Moconá',
                
                // Lugares turísticos internacionales
                'cataratas-brasileras': 'Cataratas Brasileras',
                'tour-compras': 'Tour de compras, Ciudad del Este',
                'aeropuerto-internacional': 'Aeropuerto Brasileño (Foz Iguazú)',
                'parque-aves': 'Parque Das Aves',
                'yup-star': 'Yup Star',
                
                // Viajes realizados
                'viajes-realizados': 'VIAJES REALIZADOS',
                'viajes-descripcion': '"Explorá algunos de los destinos en los que hemos brindado nuestros servicios. A lo largo de nuestra trayectoria hemos trasladado personas provenientes de países como Brasil, Austria, Costa Rica, Inglaterra, Francia, Argentina, Puerto Rico, Australia, Perú, Colombia y Chile."',
                'ver-resenas': 'Ver Reseñas',
                'ver-mas-viajes': 'Ver más viajes',
                
                // Nosotros
                'quienes-somos': '¿QUIÉNES SOMOS?',
                'nosotros-descripcion': '<span class="rojo">S</span>omos un servicio de traslados confiable y seguro de ciudad de Puerto Iguazú, Misiones. Nos especializamos en brindar transporte cómodo, puntual y personalizado para turistas que desean conocer la región, como las Cataratas del Iguazú, el Hito Tres Fronteras, y mucho más. ¡Tu viaje comienza con nosotros!',
                
                // Contactos
                'contactos-titulo': 'Contactos',
                'redes-sociales': 'Redes Sociales',
                'medios-pago': 'Medios de Pago',
                'derechos-reservados': 'Todos los derechos reservados.',
                'desarrollado-por': 'Desarrollado por Danzel Blotz Burki',
                
                // Chatbot
                'chatbot-notice': '¿Necesitás ayuda? <br>¡Probá nuestro asistente virtual TUQUI!',
                
                // Descripciones de viajes
                'helisul-brasil': 'Helisul (Brasil)',
                'gruta-india-misiones': 'Gruta India (Misiones ARG)',
                'cell-shop-paraguay': 'Cell Shop (Paraguay)',
                'iguazu-misiones': 'Iguazú (Misiones ARG)',
                
                // Modal de idioma
                'seleccionar-idioma': 'Selecciona tu idioma',
                'idioma-puede-cambiar': 'Puedes cambiar el idioma en cualquier momento desde el menú',
                
                // Notificación de idioma
                'language-notice-title': '¿Hablas otro idioma?',
                'language-notice-message': 'Puedes cambiar el idioma del sitio en cualquier momento',
                
                // Traducciones específicas del chatbot
                'chatbot-services': 'Todos los servicios',
                'chatbot-vehicles': 'Vehículos', 
                'chatbot-contact': 'Contacto directo',
                'chatbot-groups': 'Grupos',
                'chatbot-help': '¿En qué podemos ayudarte?',
                'chatbot-know-services': 'Conocer todos los servicios',
                'chatbot-what-vehicles': 'Qué vehículos tienen',
                'chatbot-whatsapp-email': 'WhatsApp y email',
                'chatbot-large-groups': 'Servicios para grupos grandes',
                
                // Mensajes de respuesta del chatbot
                'chatbot-welcome': `¡Hola! 👋 Soy TUQUI, tu asistente de Traslados D.W.B.\n\n🚗 Nuestro vehículo: Renault Logan 2022 (4 personas + equipaje)\n🌎 Servicios: Traslados, tours a Cataratas, Brasil, Paraguay\n\n¿En qué puedo ayudarte hoy?`,
                'chatbot-services-response': `🌟 Todos Nuestros Servicios:\n\n🏞️ Lugares Turísticos:\n• Cataratas del Iguazú (Argentina y Brasil)\n• Parque das Aves\n• Represa Itaipú\n• Minas de Wanda\n\n🛍️ Tour de Compras:\n• Paraguay (Ciudad del Este)\n• Brasil (Duty Free)\n\n🚗 Traslados:\n• Traslados al aeropuerto\n• Traslados al hotel\n• Rutas personalizadas\n\n¿Qué servicio te interesa?`,
                'chatbot-vehicles-response': `🚗 Nuestro Vehículo:\n\n• Renault Logan 2022\n• Capacidad: 4 personas + equipaje\n• Aire acondicionado\n• Seguro completo\n• Espacio para equipaje\n• Confort para 4 personas\n\nPerfecto para familias pequeñas y grupos.`,
                'chatbot-contact-response': `📞 Contacto Directo:\n\n• WhatsApp: +54 9 3757 68 1414\n• Email: traslados.dwb.iguazu@gmail.com\n• Ubicación: Puerto Iguazú, Misiones\n\n¡Estamos para ayudarte! 🚗`,
                'chatbot-groups-response': `👥 Servicios para Grupos:\n\nPara grupos de hasta 4 personas, nuestro Renault Logan 2022 es perfecto.\n\nSi son más de 4 personas, tenemos otras opciones disponibles.\n\n📞 Contáctanos al: +54 9 3757 68 1414 para coordinar el vehículo adecuado.`,
                'chatbot-pricing-response': `💰 Información de Precios:\n\nLos precios varían según:\n• Destino\n• Cantidad de personas\n\nPara darte el precio exacto, necesito saber:\n• ¿Para cuántas personas?\n• ¿A qué destino?`
            },
            'en': {
                // Navigation
                'inicio': 'Home',
                'servicios-de-turismo': 'Tourism Services',
                'viajes': 'Trips Made',
                'nosotros-modern': 'About Us',
                'contactos': 'Contact',
                
                // Hero section
                'bienvenidos': 'Welcome to',
                'nombre': 'Transfers Diego<span class="rojo">W.</span> Burki',
                'slogan': '"Professional tourist transportation service throughout the country"',
                
                // Services
                'servicio-turismo': 'TOURISM SERVICE',
                'turismo-provincial': 'Provincial Tourism',
                'turismo-internacional': 'International Tourism',
                
                // Provincial tourist places
                'cataratas-iguazu': 'Iguazu Falls',
                'lugares-turisticos-iguazu': 'Güirá Oga',
                'gruta-india': 'India Cave',
                'minas-wanda': 'Wanda Mines',
                'tour-dia': 'Moconá Falls',
                
                // International tourist places
                'cataratas-brasileras': 'Brazilian Falls',
                'tour-compras': 'Shopping Tour, Ciudad del Este',
                'aeropuerto-internacional': 'Brazilian Airport (Foz Iguazú)',
                'parque-aves': 'Parque Das Aves',
                'yup-star': 'Yup Star',
                
                // Trips made
                'viajes-realizados': 'TRIPS MADE',
                'viajes-descripcion': '"Explore some of the destinations where we have provided our services. Throughout our career we have transported people from countries such as Brazil, Austria, Costa Rica, England, France, Argentina, Puerto Rico, Australia, Peru, Colombia and Chile."',
                'ver-resenas': 'See Reviews',
                'ver-mas-viajes': 'See more trips',
                
                // About us
                'quienes-somos': 'WHO ARE WE?',
                'nosotros-descripcion': '<span class="rojo">W</span>e are a reliable and secure transfer service from Puerto Iguazú, Misiones. We specialize in providing comfortable, punctual and personalized transportation for tourists who want to know the region, such as Iguazu Falls, the Three Borders Landmark, and much more. Your journey begins with us!',
                
                // Contact
                'contactos-titulo': 'Contact',
                'redes-sociales': 'Social Media',
                'medios-pago': 'Payment Methods',
                'derechos-reservados': 'All rights reserved.',
                'desarrollado-por': 'Developed by Danzel Blotz Burki',
                
                // Chatbot
                'chatbot-notice': 'Need help? <br>Try our virtual assistant TUQUI!',
                
                // Trip descriptions
                'helisul-brasil': 'Helisul (Brazil)',
                'gruta-india-misiones': 'India Cave (Misiones ARG)',
                'cell-shop-paraguay': 'Cell Shop (Paraguay)',
                'iguazu-misiones': 'Iguazu (Misiones ARG)',
                
                // Language modal
                'seleccionar-idioma': 'Select your language',
                'idioma-puede-cambiar': 'You can change the language at any time from the menu',
                
                // Language notification
                'language-notice-title': 'Do you speak another language?',
                'language-notice-message': 'You can change the site language at any time',
                
                // Chatbot specific translations
                'chatbot-services': 'All services',
                'chatbot-vehicles': 'Vehicles',
                'chatbot-contact': 'Direct contact', 
                'chatbot-groups': 'Groups',
                'chatbot-help': 'How can we help you?',
                'chatbot-know-services': 'Know all services',
                'chatbot-what-vehicles': 'What vehicles do you have',
                'chatbot-whatsapp-email': 'WhatsApp and email',
                'chatbot-large-groups': 'Services for large groups',
                
                // Chatbot response messages
                'chatbot-welcome': `Hello! 👋 I'm TUQUI, your D.W.B. Transfers assistant.\n\n🚗 Our vehicle: Renault Logan 2022 (4 people + luggage)\n🌎 Services: Transfers, tours to Iguazu Falls, Brazil, Paraguay\n\nHow can I help you today?`,
                'chatbot-services-response': `🌟 All Our Services:\n\n🏞️ Tourist Places:\n• Iguazu Falls (Argentina and Brazil)\n• Parque das Aves\n• Itaipu Dam\n• Wanda Mines\n\n🛍️ Shopping Tours:\n• Paraguay (Ciudad del Este)\n• Brazil (Duty Free)\n\n🚗 Transfers:\n• Airport transfers\n• Hotel transfers\n• Custom routes\n\nWhat service interests you?`,
                'chatbot-vehicles-response': `🚗 Our Vehicle:\n\n• Renault Logan 2022\n• Capacity: 4 people + luggage\n• Air conditioning\n• Complete insurance\n• Luggage space\n• Comfort for 4 people\n\nPerfect for small families and groups.`,
                'chatbot-contact-response': `📞 Direct Contact:\n\n• WhatsApp: +54 9 3757 68 1414\n• Email: traslados.dwb.iguazu@gmail.com\n• Location: Puerto Iguazú, Misiones\n\nWe are here to help! 🚗`,
                'chatbot-groups-response': `👥 Group Services:\n\nFor groups of up to 4 people, our Renault Logan 2022 is perfect.\n\nIf there are more than 4 people, we have other options available.\n\n📞 Contact us at: +54 9 3757 68 1414 to coordinate the appropriate vehicle.`,
                'chatbot-pricing-response': `💰 Price Information:\n\nPrices vary according to:\n• Destination\n• Number of people\n\nTo give you the exact price, I need to know:\n• For how many people?\n• To which destination?`
            },
            'pt': {
                // Navegação
                'inicio': 'Início',
                'servicios-de-turismo': 'Serviços de turismo',
                'viajes': 'Viagens Realizadas',
                'nosotros-modern': 'Sobre Nós',
                'contactos': 'Contatos',
                
                // Hero section
                'bienvenidos': 'Bem-vindo a',
                'nombre': 'Transferências Diego<span class="rojo">W.</span> Burki',
                'slogan': '"Serviço profissional de transporte turístico em todo o país"',
                
                // Serviços
                'servicio-turismo': 'SERVIÇO DE TURISMO',
                'turismo-provincial': 'Turismo Provincial',
                'turismo-internacional': 'Turismo Internacionais',
                
                // Lugares turísticos provinciais
                'cataratas-iguazu': 'Cataratas do Iguaçu',
                'lugares-turisticos-iguazu': 'Güirá Oga',
                'gruta-india': 'Gruta Índia',
                'minas-wanda': 'Minas de Wanda',
                'tour-dia': 'Saltos do Moconá',
                
                // Lugares turísticos internacionais
                'cataratas-brasileras': 'Cataratas Brasileiras',
                'tour-compras': 'Tour de compras, Ciudad del Este',
                'aeropuerto-internacional': 'Aeroporto Brasileiro (Foz do Iguaçu)',
                'parque-aves': 'Parque Das Aves',
                'yup-star': 'Yup Star',
                
                // Viagens realizadas
                'viajes-realizados': 'VIAGENS REALIZADAS',
                'viajes-descripcion': '"Explore alguns dos destinos onde prestamos nossos serviços. Ao longo de nossa trajetória transportamos pessoas de países como Brasil, Áustria, Costa Rica, Inglaterra, França, Argentina, Porto Rico, Austrália, Peru, Colômbia e Chile."',
                'ver-resenas': 'Ver Avaliações',
                'ver-mas-viajes': 'Ver mais viagens',
                
                // Sobre nós
                'quienes-somos': 'QUEM SOMOS?',
                'nosotros-descripcion': '<span class="rojo">S</span>omos um serviço de transferência confiável e seguro da cidade de Puerto Iguazú, Misiones. Especializamo-nos em fornecer transporte confortável, pontual e personalizado para turistas que desejam conhecer a região, como as Cataratas do Iguaçu, o Marco das Três Fronteiras e muito mais. Sua viagem começa conosco!',
                
                // Contatos
                'contactos-titulo': 'Contatos',
                'redes-sociales': 'Redes Sociais',
                'medios-pago': 'Formas de Pagamento',
                'derechos-reservados': 'Todos os direitos reservados.',
                'desarrollado-por': 'Desenvolvido por Danzel Blotz Burki',
                
                // Chatbot
                'chatbot-notice': 'Precisa de ajuda? <br>Experimente nosso assistente virtual TUQUI!',
                
                // Descrições de viagens
                'helisul-brasil': 'Helisul (Brasil)',
                'gruta-india-misiones': 'Gruta Índia (Misiones ARG)',
                'cell-shop-paraguay': 'Cell Shop (Paraguai)',
                'iguazu-misiones': 'Iguaçu (Misiones ARG)',
                
                // Modal de idioma
                'seleccionar-idioma': 'Selecione seu idioma',
                'idioma-puede-cambiar': 'Você pode alterar o idioma a qualquer momento no menu',
                
                // Notificação de idioma
                'language-notice-title': 'Você fala outro idioma?',
                'language-notice-message': 'Você pode alterar o idioma do site a qualquer momento',
                
                // Traduções específicas do chatbot
                'chatbot-services': 'Todos os serviços',
                'chatbot-vehicles': 'Veículos',
                'chatbot-contact': 'Contato direto',
                'chatbot-groups': 'Grupos',
                'chatbot-help': 'Como podemos ajudá-lo?',
                'chatbot-know-services': 'Conhecer todos os serviços',
                'chatbot-what-vehicles': 'Quais veículos vocês têm',
                'chatbot-whatsapp-email': 'WhatsApp e email',
                'chatbot-large-groups': 'Serviços para grupos grandes',
                
                // Mensagens de resposta do chatbot
                'chatbot-welcome': `Olá! 👋 Eu sou o TUQUI, seu assistente da D.W.B. Transferências.\n\n🚗 Nosso veículo: Renault Logan 2022 (4 pessoas + bagagem)\n🌎 Serviços: Transferências, passeios para Cataratas, Brasil, Paraguai\n\nComo posso ajudá-lo hoje?`,
                'chatbot-services-response': `🌟 Todos Os Nossos Serviços:\n\n🏞️ Lugares Turísticos:\n• Cataratas do Iguaçu (Argentina e Brasil)\n• Parque das Aves\n• Usina de Itaipu\n• Minas de Wanda\n\n🛍️ Passeios de Compras:\n• Paraguai (Ciudad del Este)\n• Brasil (Duty Free)\n\n🚗 Transferências:\n• Transfer do aeroporto\n• Transfer do hotel\n• Rotas personalizadas\n\nQual serviço lhe interessa?`,
                'chatbot-vehicles-response': `🚗 Nosso Veículo:\n\n• Renault Logan 2022\n• Capacidade: 4 pessoas + bagagem\n• Ar condicionado\n• Seguro completo\n• Espaço para bagagem\n• Conforto para 4 pessoas\n\nPerfeito para famílias pequenas e grupos.`,
                'chatbot-contact-response': `📞 Contato Direto:\n\n• WhatsApp: +54 9 3757 68 1414\n• Email: traslados.dwb.iguazu@gmail.com\n• Localização: Puerto Iguazú, Misiones\n\nEstamos aqui para ajudar! 🚗`,
                'chatbot-groups-response': `👥 Serviços para Grupos:\n\nPara grupos de até 4 pessoas, nosso Renault Logan 2022 é perfeito.\n\nSe forem mais de 4 pessoas, temos outras opções disponíveis.\n\n📞 Entre em contato conosco: +54 9 3757 68 1414 para coordenar o veículo adequado.`,
                'chatbot-pricing-response': `💰 Informação de Preços:\n\nOs preços variam conforme:\n• Destino\n• Quantidade de pessoas\n\nPara dar o preço exato, preciso saber:\n• Para quantas pessoas?\n• Para qual destino?`
            }
        };
        
        this.init();
    }
    
    init() {
        console.log('TranslationManager iniciado');
        
        // Cargar idioma guardado
        const savedLanguage = localStorage.getItem('preferredLanguage');
        if (savedLanguage && this.translations[savedLanguage]) {
            this.currentLanguage = savedLanguage;
        } else {
            // Detectar idioma del navegador
            const browserLang = navigator.language || navigator.userLanguage;
            const detectedLang = browserLang.split('-')[0];
            if (this.translations[detectedLang]) {
                this.currentLanguage = detectedLang;
            }
        }
        
        this.applyTranslations();
        
        setTimeout(() => {
            this.setupLanguageSelector();
            this.setupLanguageNotification();
            this.setupLanguageModal();
            this.setupHeaderLanguageButton();
        }, 100);
        
        if (!savedLanguage) {
            setTimeout(() => {
                this.showLanguageModal();
            }, 2000);
        }
    }
    
    // ==================== SELECTOR DE IDIOMA FLOTANTE ====================
    setupLanguageSelector() {
        const languageSelector = document.getElementById('language-selector');
        const languageToggle = document.getElementById('language-toggle');
        const currentLanguage = document.getElementById('current-language');
        const languageOptions = document.querySelectorAll('.language-option');
        
        if (!languageSelector || !languageToggle) {
            console.warn('Elementos del selector de idioma no encontrados');
            return;
        }
        
        // Actualizar texto del botón
        if (currentLanguage) {
            currentLanguage.textContent = this.currentLanguage.toUpperCase();
        }
        
        // Alternar visibilidad del selector
        languageToggle.addEventListener('click', (e) => {
            e.stopPropagation();
            languageSelector.classList.toggle('active');
            // Ocultar notificación cuando se hace clic en el selector
            this.hideLanguageNotification();
        });
        
        // Cerrar selector al hacer clic fuera
        document.addEventListener('click', () => {
            languageSelector.classList.remove('active');
        });
        
        // Prevenir que el clic en el selector cierre el menú
        languageSelector.addEventListener('click', (e) => {
            e.stopPropagation();
        });
        
        // Manejar selección de idioma
        languageOptions.forEach(option => {
            option.addEventListener('click', (e) => {
                e.preventDefault();
                const selectedLang = option.getAttribute('data-lang');
                this.handleLanguageSelect(selectedLang);
                languageSelector.classList.remove('active');
                this.hideLanguageNotification();
            });
        });
    }
    
    // ==================== NOTIFICACIÓN DE IDIOMA ====================
    setupLanguageNotification() {
        const languageNotification = document.getElementById('language-notification');
        const closeNotificationBtn = document.getElementById('close-language-notification');
        
        if (!languageNotification || !closeNotificationBtn) {
            console.warn('Elementos de notificación de idioma no encontrados');
            return;
        }
        
        // Mostrar notificación después de un tiempo
        this.showLanguageNotification();
        
        // Cerrar notificación
        closeNotificationBtn.addEventListener('click', () => {
            this.hideLanguageNotification();
        });
    }
    
    showLanguageNotification() {
        const languageNotification = document.getElementById('language-notification');
        const languageToggle = document.getElementById('language-toggle');
        const notificationShown = localStorage.getItem('language-notification-shown');
        const userLanguage = navigator.language || navigator.userLanguage;
        
        // Solo mostrar si no se ha mostrado antes y el usuario no está en español
        if (!notificationShown && !userLanguage.startsWith('es')) {
            setTimeout(() => {
                if (languageNotification) {
                    languageNotification.classList.remove('hidden');
                    // Agregar efecto de pulso al botón
                    if (languageToggle) {
                        languageToggle.classList.add('pulse');
                    }
                    
                    // Auto-ocultar después de 10 segundos
                    setTimeout(() => {
                        this.hideLanguageNotification();
                    }, 10000);
                }
            }, 3000); // Mostrar después de 3 segundos
        }
    }
    
    hideLanguageNotification() {
        const languageNotification = document.getElementById('language-notification');
        const languageToggle = document.getElementById('language-toggle');
        
        if (languageNotification) {
            languageNotification.classList.add('hidden');
        }
        if (languageToggle) {
            languageToggle.classList.remove('pulse');
        }
        localStorage.setItem('language-notification-shown', 'true');
    }
    
    // ==================== MODAL DE IDIOMA ====================
    setupLanguageModal() {
        const languageOptions = document.querySelectorAll('.language-option');
        
        languageOptions.forEach(option => {
            option.addEventListener('click', (e) => {
                e.preventDefault();
                const lang = e.currentTarget.getAttribute('data-lang');
                this.handleLanguageSelect(lang);
            });
        });
        
        const modal = document.getElementById('languageModal');
        if (modal) {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    this.hideLanguageModal();
                }
            });
        }
    }
    
    setupHeaderLanguageButton() {
        const languageButton = document.getElementById('languageButton');
        
        if (languageButton) {
            languageButton.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                this.showLanguageModal();
            });
        }
    }
    
    showLanguageModal() {
        const modal = document.getElementById('languageModal');
        if (modal) {
            modal.classList.add('active');
            document.body.style.overflow = 'hidden';
            this.translateLanguageModal();
            this.highlightCurrentLanguage();
        }
    }
    
    hideLanguageModal() {
        const modal = document.getElementById('languageModal');
        if (modal) {
            modal.classList.remove('active');
            document.body.style.overflow = '';
        }
    }
    
    highlightCurrentLanguage() {
        const languageOptions = document.querySelectorAll('.language-option');
        languageOptions.forEach(option => {
            option.classList.remove('active');
            if (option.getAttribute('data-lang') === this.currentLanguage) {
                option.classList.add('active');
            }
        });
    }
    
    translateLanguageModal() {
        const modalTitle = document.querySelector('#languageModal .language-modal-header h3');
        const modalSubtitle = document.querySelector('#languageModal .language-modal-subtitle');
        const modalFooter = document.querySelector('#languageModal .language-modal-footer p');
        
        if (modalTitle) {
            modalTitle.textContent = this.translate('seleccionar-idioma');
        }
        if (modalSubtitle) {
            modalSubtitle.textContent = 'Choose your preferred language';
        }
        if (modalFooter) {
            modalFooter.textContent = this.translate('idioma-puede-cambiar');
        }
    }
    
    // ==================== FUNCIONES PRINCIPALES ====================
    handleLanguageSelect(lang) {
        this.changeLanguage(lang);
        this.hideLanguageModal();
        localStorage.setItem('preferredLanguage', lang);
        
        // Mostrar feedback visual
        this.showLanguageChangeFeedback(lang);
    }
    
    changeLanguage(lang) {
        if (this.translations[lang]) {
            this.currentLanguage = lang;
            this.applyTranslations();
            this.updateChatbotLanguage();
            
            // Actualizar texto del botón flotante
            const currentLanguageElement = document.getElementById('current-language');
            if (currentLanguageElement) {
                currentLanguageElement.textContent = lang.toUpperCase();
            }
            
            console.log(`Idioma cambiado a: ${lang}`);
        }
    }
    
    applyTranslations() {
        const elements = document.querySelectorAll('[data-translate]');
        console.log(`Encontré ${elements.length} elementos para traducir`);
        
        elements.forEach(element => {
            const key = element.getAttribute('data-translate');
            const translation = this.translations[this.currentLanguage][key];
            
            if (translation) {
                if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
                    element.placeholder = translation;
                } else {
                    element.innerHTML = translation;
                }
                console.log(`Traduciendo: ${key} -> ${translation}`);
            } else {
                console.warn(`No se encontró traducción para: ${key} en idioma: ${this.currentLanguage}`);
            }
        });
    }
    
    updateChatbotLanguage() {
        if (window.languageDetector) {
            window.languageDetector.userLanguage = this.currentLanguage;
            
            // Obtener el mensaje de bienvenida traducido
            const welcomeMessage = this.translate('chatbot-welcome');
            
            // Si el chatbot está abierto, actualizar el mensaje de bienvenida
            if (window.hasShownWelcome && window.chatBody) {
                const botMessages = window.chatBody.querySelectorAll('.bot-message');
                if (botMessages.length > 0) {
                    const lastBotMessage = botMessages[botMessages.length - 1];
                    const messageText = lastBotMessage.querySelector('.message-text');
                    if (messageText) {
                        // Reemplazar el contenido con el mensaje traducido
                        messageText.innerHTML = welcomeMessage.replace(/\n/g, '<br>');
                    }
                }
            }
            
            // Actualizar también las consultas rápidas si están visibles
            this.updateChatbotQuickQueries();
            
            // Disparar evento personalizado para notificar el cambio
            const event = new CustomEvent('languageChanged', {
                detail: { 
                    language: this.currentLanguage,
                    welcomeMessage: welcomeMessage 
                }
            });
            document.dispatchEvent(event);
        }
    }
    
    // NUEVA FUNCIÓN: Actualizar las consultas rápidas del chatbot
    updateChatbotQuickQueries() {
        const quickQueriesContainer = document.getElementById('quickQueries');
        if (!quickQueriesContainer) return;
        
        // Actualizar título
        const title = quickQueriesContainer.querySelector('.queries-title');
        if (title) {
            title.textContent = this.translate('chatbot-help');
        }
        
        // Actualizar cada consulta rápida
        const quickQueries = quickQueriesContainer.querySelectorAll('.quick-query');
        const queryData = [
            {
                icon: "🌟",
                textKey: "chatbot-services",
                descriptionKey: "chatbot-know-services"
            },
            {
                icon: "🚗", 
                textKey: "chatbot-vehicles",
                descriptionKey: "chatbot-what-vehicles"
            },
            {
                icon: "📞",
                textKey: "chatbot-contact", 
                descriptionKey: "chatbot-whatsapp-email"
            },
            {
                icon: "👥",
                textKey: "chatbot-groups",
                descriptionKey: "chatbot-large-groups"
            }
        ];
        
        quickQueries.forEach((query, index) => {
            if (index < queryData.length) {
                const data = queryData[index];
                const textElement = query.querySelector('.query-text');
                const descriptionElement = query.querySelector('.query-description');
                
                if (textElement) {
                    textElement.textContent = this.translate(data.textKey);
                }
                if (descriptionElement) {
                    descriptionElement.textContent = this.translate(data.descriptionKey);
                }
                
                // Actualizar también el atributo data-query para mantener la funcionalidad
                query.setAttribute('data-query', this.translate(data.textKey));
            }
        });
    }
    
    translate(key) {
        return this.translations[this.currentLanguage][key] || key;
    }
    
    // ==================== FEEDBACK VISUAL ====================
    showLanguageChangeFeedback(lang) {
        const languageToggle = document.getElementById('language-toggle');
        if (!languageToggle) return;
        
        const originalText = languageToggle.innerHTML;
        const langNames = {
            'es': 'Español',
            'en': 'English', 
            'pt': 'Português',
        };
        
        languageToggle.innerHTML = `<i class="fas fa-check"></i> ${langNames[lang]}`;
        languageToggle.style.background = '#4CAF50';
        languageToggle.style.color = 'white';
        languageToggle.style.borderColor = '#4CAF50';
        
        setTimeout(() => {
            languageToggle.innerHTML = originalText;
            languageToggle.style.background = '';
            languageToggle.style.color = '';
            languageToggle.style.borderColor = '';
        }, 2000);
    }
    
    // Función global para compatibilidad
    translatePage(lang) {
        this.changeLanguage(lang);
    }
}

// Inicializar cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', function() {
    window.translationManager = new TranslationManager();
    
    // Función global para compatibilidad con código existente
    window.translatePage = function(lang) {
        if (window.translationManager) {
            window.translationManager.translatePage(lang);
        }
    };
});

// Función de compatibilidad para detectar idioma del navegador
window.languageDetector = {
    userLanguage: 'es',
    detectLanguage: function() {
        const browserLang = navigator.language || navigator.userLanguage;
        return browserLang.split('-')[0];
    }
};