
document.addEventListener('DOMContentLoaded', function() {
  // Elementos del DOM
  const modal = document.getElementById('modalServicios');
  const modalContent = document.querySelector('.modal-contenido');
  const modalMedia = document.getElementById('modalMediaServicios');
  const modalDesc = document.getElementById('modalDescripcionServicios');
  const closeBtn = document.querySelector('.cerrar');
  const prevBtn = document.querySelector('.anterior');
  const nextBtn = document.querySelector('.siguiente');

  // Datos de los servicios
  const servicios = {
    provincial: {
      images: [
        './images/servicios/servicio_1.jpg',
        './images/servicios/servicio_3.jpg',
        './images/servicios/servicio_5.jpg',
        './images/servicios/servicio_7.jpg',
        './images/servicios/servicio_10.jpg'
      ],
      descriptions: [
        'Cataratas Iguazú - Argentina',
        'Lugares turísticos en Iguazú',
        'Gruta India - Un lugar mágico',
        'Minas de Wanda - Conoce las piedras preciosas',
        'Tour de un día por la provincia'
      ]
    },
    internacional: {
      images: [
        './images/servicios/servicio_2.jpg',
        './images/servicios/servicio_4.jpg',
        './images/servicios/servicio_6.jpg',
        './images/servicios/servicio_8.jpg',
        './images/servicios/servicio_9.jpg'
      ],
      descriptions: [
        'Cataratas Brasileras - Vista desde Brasil',
        'Tour de compras en Ciudad del Este',
        'Aeropuerto Internacional Iguazú - Traslados',
        'Parque Das Aves - Experiencia única',
        'Tour de un día completo internacional'
      ]
    }
  };

  // Variables de estado
  let currentService = null;
  let currentIndex = 0;

  // Abrir modal
  document.querySelectorAll('.carta').forEach(carta => {
    carta.addEventListener('click', function() {
      currentService = this.getAttribute('data-service');
      currentIndex = parseInt(this.getAttribute('data-index'));
      updateModal();
      openModal();
    });
  });

  // Función para abrir el modal centrado
  function openModal() {
    modal.style.display = 'flex'; // Cambiado a flex para mejor centrado
    modal.style.alignItems = 'center';
    modal.style.justifyContent = 'center';
    document.body.style.overflow = 'hidden';
  }

  // Cerrar modal
  closeBtn.addEventListener('click', closeModal);
  
  function closeModal() {
    modal.style.display = 'none';
    document.body.style.overflow = 'auto';
  }

  // Navegación
  prevBtn.addEventListener('click', navigate.bind(null, -1));
  nextBtn.addEventListener('click', navigate.bind(null, 1));

  function navigate(direction) {
    if (!currentService) return;
    
    const service = servicios[currentService];
    currentIndex = (currentIndex + direction + service.images.length) % service.images.length;
    updateModal();
  }

  // Actualizar contenido del modal
  function updateModal() {
    if (!currentService) return;
    
    const service = servicios[currentService];
    modalMedia.innerHTML = `
      <img src="${service.images[currentIndex]}" 
           alt="${service.descriptions[currentIndex]}" 
           class="modal-imagen">
    `;
    modalDesc.textContent = service.descriptions[currentIndex];
  }

  // Cerrar al hacer clic fuera
  modal.addEventListener('click', function(e) {
    if (e.target === modal) closeModal();
  });

  // Cerrar con ESC
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && modal.style.display === 'flex') closeModal();
  });
});

