// burger.js - Función actualizada para el menú hamburguesa con bloqueo de scroll
document.addEventListener('DOMContentLoaded', function() {
  const hamburger = document.getElementById('hamburger');
  const navMenu = document.getElementById('nav-menu');
  const body = document.body;
  const html = document.documentElement;
  
  // Variables para guardar la posición del scroll
  let scrollPosition = 0;
  
  // Crear overlay si no existe
  let overlay = document.querySelector('.nav-overlay');
  if (!overlay) {
    overlay = document.createElement('div');
    overlay.className = 'nav-overlay';
    document.body.appendChild(overlay);
  }
  
  // Almacenar el estado del menú
  let menuOpen = false;
  
  // Función para bloquear el scroll
  function disableScroll() {
    // Guardar la posición actual del scroll
    scrollPosition = window.pageYOffset || document.documentElement.scrollTop;
    
    // Aplicar estilos para bloquear el scroll
    body.style.top = `-${scrollPosition}px`;
    body.classList.add('menu-open');
    
    // Prevenir scroll con touch en dispositivos móviles
    document.addEventListener('touchmove', preventTouchScroll, { passive: false });
  }
  
  // Función para habilitar el scroll
  function enableScroll() {
    // Remover estilos de bloqueo
    body.classList.remove('menu-open');
    body.style.top = '';
    
    // Restaurar la posición del scroll
    window.scrollTo(0, scrollPosition);
    
    // Remover el event listener de touch
    document.removeEventListener('touchmove', preventTouchScroll);
  }
  
  // Función para prevenir scroll táctil
  function preventTouchScroll(e) {
    e.preventDefault();
  }
  
  // Función para abrir/cerrar el menú
  function toggleMenu() {
    menuOpen = !menuOpen;
    
    if (menuOpen) {
      // Abrir menú y bloquear scroll
      disableScroll();
    } else {
      // Cerrar menú y habilitar scroll
      enableScroll();
    }
    
    // Actualizar clases para animación
    hamburger.classList.toggle('active');
    navMenu.classList.toggle('active');
    overlay.classList.toggle('active');
    
    // Almacenar estado en localStorage
    localStorage.setItem('menuState', menuOpen ? 'open' : 'closed');
  }
  
  // Función para cerrar menú (sin toggle)
  function closeMenu() {
    if (menuOpen) {
      menuOpen = false;
      enableScroll();
      hamburger.classList.remove('active');
      navMenu.classList.remove('active');
      overlay.classList.remove('active');
      localStorage.setItem('menuState', 'closed');
    }
  }
  
  // Event listener para el botón del menú
  hamburger.addEventListener('click', function(e) {
    e.stopPropagation();
    toggleMenu();
  });
  
  // Cerrar menú al hacer clic en overlay
  overlay.addEventListener('click', closeMenu);
  
  // Cerrar menú al hacer clic en un enlace
  const navLinks = document.querySelectorAll('.nav-menu a');
  navLinks.forEach(link => {
    link.addEventListener('click', function(e) {
      // Solo cerrar el menú, no prevenir el comportamiento por defecto
      // para permitir la navegación
      closeMenu();
    });
  });
  
  // Cerrar menú al hacer clic fuera
  document.addEventListener('click', function(e) {
    if (menuOpen && !navMenu.contains(e.target) && !hamburger.contains(e.target)) {
      closeMenu();
    }
  });
  
  // Cerrar con tecla Escape
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && menuOpen) {
      closeMenu();
    }
  });
  
  // Cerrar menú al cambiar el tamaño de la ventana (si se vuelve a tamaño desktop)
  window.addEventListener('resize', function() {
    if (menuOpen && window.innerWidth > 767) {
      closeMenu();
    }
  });
  
  // Verificar estado anterior del menú al cargar la página
  const savedMenuState = localStorage.getItem('menuState');
  if (savedMenuState === 'open') {
    // No abrimos automáticamente al cargar para mejor UX
  }
  
  // Resto del código para almacenar scroll (mantener igual)
  const sectionIds = ['inicio', 'servicios-de-turismo', 'viajes', 'nosotros-modern', 'contactos'];
  
  sectionIds.forEach(id => {
    const section = document.getElementById(id);
    if (section) {
      const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            localStorage.setItem('currentSection', id);
            const scrollPosition = window.pageYOffset;
            localStorage.setItem(`${id}_scrollPosition`, scrollPosition);
          }
        });
      }, { threshold: 0.5 });
      
      observer.observe(section);
    }
  });
  
  // Restaurar posición de scroll al cargar la página
  window.addEventListener('load', function() {
    const currentSection = localStorage.getItem('currentSection');
    if (currentSection) {
      const savedPosition = localStorage.getItem(`${currentSection}_scrollPosition`);
      if (savedPosition) {
        setTimeout(() => {
          window.scrollTo(0, parseInt(savedPosition));
        }, 100);
      }
    }
  });
  
  // Limpiar el estado del menú al recargar la página para mejor UX
  window.addEventListener('beforeunload', function() {
    if (menuOpen) {
      localStorage.setItem('menuState', 'closed');
    }
  });
});