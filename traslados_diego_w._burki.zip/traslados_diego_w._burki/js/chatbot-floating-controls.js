// reset-floating-buttons.js
function resetFloatingButtons() {
    const floatingButtons = [
        'whatsappBtn',
        'scrollTopBtn', 
        'tucanChatBtn'
    ];
    
    floatingButtons.forEach(btnId => {
        const btn = document.getElementById(btnId);
        if (btn) {
            // Reset completo de estilos
            btn.style.transform = '';
            btn.style.opacity = '';
            btn.style.transition = '';
            btn.style.pointerEvents = '';
            btn.style.zIndex = '';
            
            // Forzar reflow
            btn.offsetHeight;
        }
    });
    
    // Remover clases del body
    document.body.classList.remove('chatbot-active');
    document.documentElement.classList.remove('chatbot-active');
    
    // Restaurar scroll
    document.body.style.overflow = '';
    document.documentElement.style.overflow = '';
}

// Ejecutar reset cuando la página se carga/recarga
document.addEventListener('DOMContentLoaded', resetFloatingButtons);
window.addEventListener('load', resetFloatingButtons);
window.addEventListener('beforeunload', resetFloatingButtons);

// Reset también al hacer resize (útil para cambios de orientación en móviles)
window.addEventListener('resize', function() {
    setTimeout(resetFloatingButtons, 100);
});