// ==================== GESTIÓN MEJORADA DEL AVISO CHATBOT ====================
document.addEventListener("DOMContentLoaded", function() {
  const chatNotice = document.getElementById("tucanChatNotice");
  const chatBtn = document.getElementById("tucanChatBtn");
  const closeChatBtn = document.getElementById("closeChatOverlay");
  
  if (!chatNotice) return;

  // Estado del aviso
  let noticeDismissed = localStorage.getItem('chatbotNoticeDismissed') === 'true';
  
  // Inicializar aviso
  function initChatNotice() {
    if (noticeDismissed) {
      chatNotice.classList.add('oculto');
      return;
    }
    
    // Mostrar aviso después de un delay en móvil
    if (window.innerWidth < 768) {
      setTimeout(() => {
        if (!noticeDismissed) {
          chatNotice.classList.remove('oculto');
        }
      }, 2000);
    } else {
      chatNotice.classList.remove('oculto');
    }
  }

  // Cerrar aviso permanentemente
  function dismissNotice() {
    chatNotice.classList.add('oculto');
    noticeDismissed = true;
    localStorage.setItem('chatbotNoticeDismissed', 'true');
  }

  // Botón de cerrar en el aviso
  const noticeCloseBtn = chatNotice.querySelector('button');
  if (noticeCloseBtn) {
    noticeCloseBtn.addEventListener('click', function(e) {
      e.stopPropagation();
      dismissNotice();
    });
  }

  // Cerrar al hacer clic en el aviso (cualquier parte)
  chatNotice.addEventListener('click', function(e) {
    // Solo cerrar si no se hizo clic en el botón del chatbot
    if (!e.target.closest('#tucanChatBtn')) {
      dismissNotice();
    }
  });

  // Cerrar al abrir el chatbot
  if (chatBtn) {
    chatBtn.addEventListener('click', function() {
      dismissNotice();
    });
  }

  // Cerrar al abrir el chat overlay
  if (closeChatBtn) {
    closeChatBtn.addEventListener('click', function() {
      dismissNotice();
    });
  }

  // También cerrar cuando se envía un mensaje en el chat
  document.addEventListener('chatOpened', function() {
    dismissNotice();
  });

  // Inicializar
  initChatNotice();

  // Reset en resize para testing (opcional)
  window.addEventListener('resize', function() {
    if (window.innerWidth < 768 && !noticeDismissed) {
      chatNotice.classList.remove('oculto');
    }
  });
});

// ==================== PROTECCIÓN CONTRA DEFORMACIÓN ====================
document.addEventListener('DOMContentLoaded', function() {
  const whatsappBtn = document.getElementById('whatsappBtn');
  const chatOverlay = document.getElementById('tucanChatOverlay');
  
  if (!whatsappBtn) return;

  // Forzar escala normal del WhatsApp
  function protectWhatsAppButton() {
    whatsappBtn.style.transform = 'scale(1)';
    whatsappBtn.style.webkitTransform = 'scale(1)';
    
    // Proteger también los hijos
    const children = whatsappBtn.querySelectorAll('*');
    children.forEach(child => {
      child.style.transform = 'none';
      child.style.webkitTransform = 'none';
    });
  }

  // Aplicar protección periódicamente
  setInterval(protectWhatsAppButton, 100);
  
  // Proteger en eventos específicos
  ['click', 'touchstart', 'mousedown', 'mouseenter'].forEach(event => {
    document.addEventListener(event, function(e) {
      if (e.target.closest('#tucanChatBtn') || 
          e.target.closest('#tucanChatOverlay') ||
          e.target.closest('.chat-notice')) {
        setTimeout(protectWhatsAppButton, 50);
      }
    });
  });

  // Proteger cuando se abre/cierra el chat
  if (chatOverlay) {
    const observer = new MutationObserver(function(mutations) {
      mutations.forEach(function(mutation) {
        if (mutation.attributeName === 'class') {
          setTimeout(protectWhatsAppButton, 50);
        }
      });
    });
    
    observer.observe(chatOverlay, { attributes: true });
  }
});